using Microsoft.AspNetCore.Mvc;

namespace FFoodsStore.Controllers
{
    public class CartViewController : Controller
    {
        public IActionResult Index()
        {
            return View(); // Trả về View của giỏ hàng
        }
    }
}
