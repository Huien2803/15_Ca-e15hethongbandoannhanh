using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.Models.Dtos;
using System.Linq;
using static FFoodsStore.Models.OrderStatus;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CartController : ControllerBase
    {
        private readonly StoreDbContext _db;
        public CartController(StoreDbContext db) => _db = db;

        // GET: api/cart/by-account/1
        [HttpGet("by-account/{accountId}")]
        public async Task<IActionResult> GetCart(int accountId)
        {
            // Truy vấn tất cả sản phẩm trong giỏ của tài khoản
            var items = await _db.Carts
                .Include(c => c.ProductDetail!)
                    .ThenInclude(pd => pd.Product!)
                        .ThenInclude(p => p.ProductImages)
                .Include(c => c.ProductDetail!)
                    .ThenInclude(pd => pd.ProductSize) // Thêm size sản phẩm
                .Where(c => c.AccountId == accountId)
                .ToListAsync();

            var total = items.Sum(i => (i.ProductDetail?.Price ?? 0m) * (i.Quantity ?? 0));
            var count = items.Sum(i => i.Quantity ?? 0);

            return Ok(new
            {
                total,
                count,
                items = items.Select(i => new
                {
                    i.ID,
                    i.AccountId,
                    i.ProductDetailId,
                    i.Quantity,
                    productDetail = i.ProductDetail == null ? null : new
                    {
                        i.ProductDetail.ID,
                        i.ProductDetail.ProductID,
                        i.ProductDetail.ProductSizeID,
                        i.ProductDetail.Price,
                        productSize = i.ProductDetail.ProductSize == null ? null : new
                        {
                            i.ProductDetail.ProductSize.SizeName, // Lấy size của sản phẩm
                            i.ProductDetail.ProductSize.SizeCode
                        },
                        product = i.ProductDetail.Product == null ? null : new
                        {
                            i.ProductDetail.Product.ID,
                            i.ProductDetail.Product.ProductName,
                            i.ProductDetail.Product.ProductCode,
                            productImages = i.ProductDetail.Product.ProductImages?
                                .Where(img => img.IsDelete != true)
                                .Select(img => new { img.ImageUrl, img.ImageName })
                        }
                    }
                })
            });
        }

        // POST: api/cart/add
        [HttpPost("add")]
        public async Task<IActionResult> Add([FromBody] CartDto dto)
        {
            var exist = await _db.Carts
                .FirstOrDefaultAsync(x => x.AccountId == dto.AccountId && x.ProductDetailId == dto.ProductDetailId);

            if (exist == null)
            {
                _db.Carts.Add(new Cart
                {
                    AccountId = dto.AccountId,
                    ProductDetailId = dto.ProductDetailId,
                    Quantity = 1,
                    CreatedDate = DateTime.Now
                });
            }
            else
            {
                exist.Quantity = (exist.Quantity ?? 0) + 1;
                exist.UpdatedDate = DateTime.Now;
            }

            await _db.SaveChangesAsync();

            var count = await _db.Carts.Where(c => c.AccountId == dto.AccountId)
                                       .SumAsync(c => c.Quantity ?? 0);

            return Ok(new { totalItems = count });
        }

        // PUT: api/cart/update-qty/5
        [HttpPut("update-qty/{id}")]
        public async Task<IActionResult> UpdateQty(int id, [FromQuery] int qty)
        {
            var item = await _db.Carts.FindAsync(id);
            if (item == null) return NotFound();
            if (qty < 1) qty = 1;

            item.Quantity = qty;
            item.UpdatedDate = DateTime.Now;
            await _db.SaveChangesAsync();
            return Ok();
        }

        // DELETE: api/cart/delete/5
        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _db.Carts.FindAsync(id);
            if (item == null) return NotFound();

            _db.Carts.Remove(item);
            await _db.SaveChangesAsync();
            return Ok();
        }

        // POST: api/cart/checkout
        [HttpPost("checkout")]
        public async Task<IActionResult> Checkout([FromBody] CheckoutDto dto)
        {
            try
            {
                // ✅ VALIDATION 1: User must be logged in
                if (dto.AccountId <= 0)
                {
                    return Unauthorized(new { message = "Vui lòng đăng nhập để thanh toán!" });
                }

                // ✅ VALIDATION 2: Required fields
                if (string.IsNullOrWhiteSpace(dto.CustomerName))
                {
                    return BadRequest(new { message = "Vui lòng nhập họ và tên!" });
                }
                if (string.IsNullOrWhiteSpace(dto.PhoneNumber))
                {
                    return BadRequest(new { message = "Vui lòng nhập số điện thoại!" });
                }
                if (string.IsNullOrWhiteSpace(dto.Address))
                {
                    return BadRequest(new { message = "Vui lòng nhập địa chỉ giao hàng!" });
                }

                // ✅ VALIDATION 3: Load cart items with full data
                var cartItems = await _db.Carts
                    .Include(c => c.ProductDetail)
                        .ThenInclude(pd => pd.Product)
                    .Include(c => c.ProductDetail)
                        .ThenInclude(pd => pd.ProductSize)
                    .Where(c => c.AccountId == dto.AccountId)
                    .ToListAsync();

                // ✅ VALIDATION 4: Cart must not be empty
                if (cartItems == null || !cartItems.Any())
                {
                    return BadRequest(new { message = "Giỏ hàng trống! Vui lòng thêm sản phẩm vào giỏ hàng trước khi thanh toán." });
                }

                // ✅ VALIDATION 5: Validate each cart item (price, size, quantity)
                decimal calculatedTotal = 0;
                var validationErrors = new List<string>();

                foreach (var cartItem in cartItems)
                {
                    // Check ProductDetail exists
                    if (cartItem.ProductDetail == null)
                    {
                        validationErrors.Add($"Sản phẩm ID {cartItem.ProductDetailId} không tồn tại hoặc đã bị xóa.");
                        continue;
                    }

                    // ✅ VALIDATION 6: Validate price
                    var price = cartItem.ProductDetail.Price ?? 0;
                    if (price <= 0)
                    {
                        validationErrors.Add($"Giá sản phẩm '{cartItem.ProductDetail.Product?.ProductName ?? "N/A"}' không hợp lệ.");
                        continue;
                    }

                    // ✅ VALIDATION 7: Validate quantity
                    var quantity = cartItem.Quantity ?? 0;
                    if (quantity <= 0)
                    {
                        validationErrors.Add($"Số lượng sản phẩm '{cartItem.ProductDetail.Product?.ProductName ?? "N/A"}' không hợp lệ.");
                        continue;
                    }

                    // ✅ VALIDATION 8: Validate size (ProductSize must exist)
                    if (cartItem.ProductDetail.ProductSizeID == null || cartItem.ProductDetail.ProductSize == null)
                    {
                        validationErrors.Add($"Size sản phẩm '{cartItem.ProductDetail.Product?.ProductName ?? "N/A"}' không hợp lệ.");
                        continue;
                    }

                    // Calculate subtotal
                    var subtotal = price * quantity;
                    calculatedTotal += subtotal;
                }

                // Return validation errors if any
                if (validationErrors.Any())
                {
                    return BadRequest(new 
                    { 
                        message = "Giỏ hàng có lỗi. Vui lòng kiểm tra lại.",
                        errors = validationErrors
                    });
                }

                // ✅ VALIDATION 9: Total must be greater than 0
                if (calculatedTotal <= 0)
                {
                    return BadRequest(new { message = "Tổng tiền đơn hàng không hợp lệ!" });
                }

                // Create order code
                var orderCode = "ORD" + DateTime.Now.ToString("yyyyMMddHHmmss") + dto.AccountId;

                // Normalize payment method
                var paymentMethod = (dto.PaymentMethod ?? "cod").Trim().ToLower();
                if (paymentMethod != "cod" && paymentMethod != "bank")
                {
                    paymentMethod = "cod"; // Default to COD if invalid
                }
                
                // Create order
                var order = new Order
                {
                    AccountID = dto.AccountId,
                    OrderCode = orderCode,
                    CustomerName = dto.CustomerName.Trim(),
                    PhoneNumber = dto.PhoneNumber.Trim(),
                    Address = dto.Address.Trim(),
                    PaymentMethod = paymentMethod,
                    Status = (int)OrderStatus.Pending, // Pending: Chờ xác nhận
                    CreateDate = DateTime.Now,
                    CreateBy = dto.AccountId.ToString(),
                    IsDeleted = false
                };

                _db.Orders.Add(order);
                await _db.SaveChangesAsync();

                // Create order details from cart items
                foreach (var cartItem in cartItems)
                {
                    if (cartItem.ProductDetail == null) continue;

                    var price = cartItem.ProductDetail.Price ?? 0;
                    var quantity = cartItem.Quantity ?? 0;
                    var totalMoney = price * quantity;

                    var orderDetail = new OrderDetail
                    {
                        OrderID = order.ID,
                        ProductDetailID = cartItem.ProductDetailId,
                        Quantity = quantity,
                        TotalMoney = totalMoney,
                        CreatedDate = DateTime.Now,
                        CreatedBy = dto.AccountId.ToString(),
                        IsDelete = false
                    };

                    _db.OrderDetails.Add(orderDetail);
                }

                await _db.SaveChangesAsync();

                // ✅ VALIDATION 10: Verify total calculation matches order details
                var orderTotalFromDetails = await _db.OrderDetails
                    .Where(od => od.OrderID == order.ID && (od.IsDelete == null || od.IsDelete == false))
                    .SumAsync(od => od.TotalMoney ?? 0);

                // Clear cart after successful order creation
                _db.Carts.RemoveRange(cartItems);
                await _db.SaveChangesAsync();

                // Return success response with redirect URL
                return Ok(new
                {
                    success = true,
                    orderId = order.ID,
                    orderCode = order.OrderCode,
                    total = orderTotalFromDetails,
                    redirectUrl = $"/Checkout/Success/{order.ID}",
                    message = "Thanh toán thành công!"
                });
            }
            catch (DbUpdateException ex)
            {
                var innerException = ex.InnerException?.Message ?? ex.Message;
                Console.WriteLine("=== DATABASE ERROR IN CHECKOUT ===");
                Console.WriteLine("Message: " + ex.Message);
                Console.WriteLine("Inner Exception: " + innerException);
                
                return StatusCode(500, new 
                { 
                    message = "Lỗi khi lưu đơn hàng. Vui lòng thử lại hoặc kiểm tra database.",
                    error = "Database update failed"
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in checkout: {ex.Message}");
                Console.WriteLine($"Stack trace: {ex.StackTrace}");
                
                return StatusCode(500, new 
                { 
                    message = "Có lỗi xảy ra khi thanh toán. Vui lòng thử lại sau.",
                    error = ex.Message
                });
            }
        }
    }
}
