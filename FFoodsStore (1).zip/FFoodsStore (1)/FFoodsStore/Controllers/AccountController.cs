using Microsoft.AspNetCore.Mvc;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.Models.Dtos;
using Microsoft.EntityFrameworkCore;

namespace FFoodsStore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly StoreDbContext _context;

        public AccountController(StoreDbContext context)
        {
            _context = context;
        }

        // Bỏ hash password - sử dụng password plain text
        // private string HashPassword(string password) - Đã bỏ

        // ========== ĐĂNG KÝ ==========
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto dto)
        {
            try
            {
                // Kiểm tra ModelState validation
                if (!ModelState.IsValid)
                {
                    var errors = ModelState.Values
                        .SelectMany(v => v.Errors)
                        .Select(e => e.ErrorMessage)
                        .ToList();
                    Console.WriteLine($"[REGISTER] ModelState invalid: {string.Join(", ", errors)}");
                    return BadRequest(string.Join(", ", errors));
                }

                // Kiểm tra dữ liệu đầu vào
                if (dto == null || string.IsNullOrWhiteSpace(dto.Email) || string.IsNullOrWhiteSpace(dto.Password))
                {
                    Console.WriteLine("[REGISTER] Missing required fields");
                    return BadRequest("Vui lòng điền đầy đủ thông tin!");
                }

                // Kiểm tra email format
                if (!dto.Email.Contains("@") || !dto.Email.Contains("."))
                {
                    Console.WriteLine($"[REGISTER] Invalid email format: {dto.Email}");
                    return BadRequest("Email không hợp lệ!");
                }

                // Kiểm tra password length
                if (dto.Password.Length < 6)
                {
                    Console.WriteLine("[REGISTER] Password too short");
                    return BadRequest("Mật khẩu phải có ít nhất 6 ký tự!");
                }

                // Trim và normalize email
                var normalizedEmail = dto.Email.Trim().ToLowerInvariant();

                // Kiểm tra email đã tồn tại chưa
                var existingAccount = await _context.Accounts
                    .FirstOrDefaultAsync(x => x.Email.ToLower() == normalizedEmail && !x.IsDelete);
                
                if (existingAccount != null)
                {
                    Console.WriteLine($"[REGISTER] Email already exists: {normalizedEmail}");
                    return BadRequest("Email đã tồn tại.");
                }

                // Tạo tài khoản mới (password plain text, không hash)
                var now = DateTime.Now;
                var newAccount = new Account
                {
                    Email = normalizedEmail,
                    Password = dto.Password, // Lưu password plain text
                    FullName = !string.IsNullOrWhiteSpace(dto.FullName) ? dto.FullName.Trim() : null,
                    PhoneNumber = !string.IsNullOrWhiteSpace(dto.PhoneNumber) ? dto.PhoneNumber.Trim() : null,
                    Role = 0, // Mặc định user
                    IsActive = 1,
                    IsDelete = false,
                    CreatedDate = now,
                    UpdatedDate = now
                };

                Console.WriteLine($"[REGISTER] Creating new account: Email={normalizedEmail}, FullName={newAccount.FullName}, Role={newAccount.Role}");

                _context.Accounts.Add(newAccount);
                int rowsAffected = await _context.SaveChangesAsync();

                Console.WriteLine($"[REGISTER] SaveChangesAsync completed. Rows affected: {rowsAffected}, Account ID: {newAccount.ID}");

                // Verify account was saved by querying it back
                var savedAccount = await _context.Accounts
                    .FirstOrDefaultAsync(x => x.ID == newAccount.ID && !x.IsDelete);

                if (savedAccount == null)
                {
                    Console.WriteLine($"[REGISTER] ERROR: Account was not saved! ID: {newAccount.ID}");
                    return StatusCode(500, "Có lỗi xảy ra khi lưu tài khoản. Vui lòng thử lại!");
                }

                Console.WriteLine($"[REGISTER] Success! Account saved: ID={savedAccount.ID}, Email={savedAccount.Email}, Password stored: {(string.IsNullOrEmpty(savedAccount.Password) ? "EMPTY" : "OK")}");

                return Ok(new
                {
                    message = "Đăng ký thành công!",
                    userId = savedAccount.ID,
                    email = savedAccount.Email
                });
            }
            catch (DbUpdateException ex)
            {
                // Lỗi database (ví dụ: constraint violation, unique key violation)
                Console.WriteLine($"[REGISTER] DbUpdateException: {ex.Message}");
                Console.WriteLine($"[REGISTER] InnerException: {ex.InnerException?.Message}");
                
                var errorMessage = ex.InnerException?.Message ?? ex.Message;
                if (errorMessage.Contains("UNIQUE") || errorMessage.Contains("duplicate"))
                {
                    return BadRequest("Email đã tồn tại.");
                }
                
                return BadRequest($"Lỗi khi lưu dữ liệu: {errorMessage}");
            }
            catch (Exception ex)
            {
                // Lỗi khác
                Console.WriteLine($"[REGISTER] Exception: {ex.Message}");
                Console.WriteLine($"[REGISTER] StackTrace: {ex.StackTrace}");
                return StatusCode(500, $"Lỗi server: {ex.Message}");
            }
        }

        // ========== ĐĂNG NHẬP ==========
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Account model)
        {
            try
            {
                // Validation
                if (model == null || string.IsNullOrWhiteSpace(model.Email) || string.IsNullOrWhiteSpace(model.Password))
                {
                    Console.WriteLine("[LOGIN] Missing email or password");
                    return BadRequest("Vui lòng điền đầy đủ email và mật khẩu!");
                }

                // Normalize email (lowercase)
                var normalizedEmail = model.Email.Trim().ToLowerInvariant();
                Console.WriteLine($"[LOGIN] Attempting login for: {normalizedEmail}");

                // Tìm user bằng email (case-insensitive)
                var user = await _context.Accounts
                    .FirstOrDefaultAsync(x => x.Email.ToLower() == normalizedEmail && !x.IsDelete);

                if (user == null)
                {
                    Console.WriteLine($"[LOGIN] User not found: {normalizedEmail}");
                    return NotFound("Tài khoản không tồn tại.");
                }

                if (user.IsActive == 0)
                {
                    Console.WriteLine($"[LOGIN] Account is inactive: {normalizedEmail}");
                    return Unauthorized("Tài khoản đã bị khóa.");
                }

                // So sánh password plain text (không hash)
                var providedPassword = model.Password;
                var storedPassword = user.Password;
                
                Console.WriteLine($"[LOGIN] Password comparison: Provided length={providedPassword?.Length ?? 0}, Stored length={storedPassword?.Length ?? 0}");
                
                if (storedPassword != providedPassword)
                {
                    Console.WriteLine($"[LOGIN] Password mismatch for: {normalizedEmail}");
                    return Unauthorized("Mật khẩu không đúng.");
                }

                Console.WriteLine($"[LOGIN] Success! User ID: {user.ID}, Email: {user.Email}, Role: {user.Role}");

                // ĐÚNG ROUTE
                string redirectUrl = user.Role == 1
                    ? "/Admin/Dashboard"
                    : "/Home/Index";

                return Ok(new
                {
                    message = "Đăng nhập thành công!",
                    redirectUrl = redirectUrl,
                    user = new
                    {   
                        id = user.ID,
                        fullName = user.FullName,
                        email = user.Email,
                        role = user.Role,
                        avatarUrl = user.AvatarUrl
                    }
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[LOGIN] Exception: {ex.Message}");
                Console.WriteLine($"[LOGIN] StackTrace: {ex.StackTrace}");
                return StatusCode(500, $"Lỗi server: {ex.Message}");
            }
        }


    }
}
