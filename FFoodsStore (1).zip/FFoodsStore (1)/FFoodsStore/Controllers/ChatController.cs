using Microsoft.AspNetCore.Mvc;
using FFoodsStore.Data;
using System;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ChatController : ControllerBase
    {
        private readonly StoreDbContext _context;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;

        public ChatController(
            StoreDbContext context, 
            IHttpClientFactory httpClientFactory,
            IConfiguration configuration)
        {
            _context = context;
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }

        // API endpoint để nhận và xử lý tin nhắn từ chat box
        [HttpPost("message")]
        public async Task<IActionResult> SendMessage([FromBody] ChatMessageRequest request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request.Message))
                {
                    return BadRequest(new { error = "Tin nhắn không được để trống!" });
                }

                var userMessage = request.Message.Trim();
                var response = await GenerateAIResponse(userMessage);

                // Lưu lịch sử chat vào database (tùy chọn)
                // await SaveChatHistory(request.UserId, userMessage, response);

                return Ok(new ChatMessageResponse
                {
                    Message = response,
                    Timestamp = DateTime.Now
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Đã xảy ra lỗi khi xử lý tin nhắn: " + ex.Message });
            }
        }

        // Tạo phản hồi từ AI
        private async Task<string> GenerateAIResponse(string userMessage)
        {
            // Kiểm tra xem có cấu hình OpenAI API không
            var openAiApiKey = _configuration["OpenAI:ApiKey"];
            
            if (!string.IsNullOrEmpty(openAiApiKey))
            {
                // Sử dụng OpenAI API
                return await GenerateOpenAIResponse(userMessage, openAiApiKey);
            }
            else
            {
                // Fallback: Sử dụng rule-based responses
                return GenerateRuleBasedResponse(userMessage);
            }
        }

        // Phản hồi dựa trên OpenAI API
        private async Task<string> GenerateOpenAIResponse(string userMessage, string apiKey)
        {
            try
            {
                var client = _httpClientFactory.CreateClient();
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");

                var requestBody = new
                {
                    model = "gpt-3.5-turbo",
                    messages = new[]
                    {
                        new { role = "system", content = "Bạn là trợ lý ảo của cửa hàng thức ăn nhanh FastFood. Hãy trả lời một cách thân thiện và hữu ích về menu, đặt hàng, khuyến mãi và các câu hỏi khác. Luôn trả lời bằng tiếng Việt." },
                        new { role = "user", content = userMessage }
                    },
                    max_tokens = 200,
                    temperature = 0.7
                };

                var jsonContent = JsonSerializer.Serialize(requestBody);
                var httpContent = new StringContent(jsonContent, System.Text.Encoding.UTF8, "application/json");
                
                var response = await client.PostAsync(
                    "https://api.openai.com/v1/chat/completions",
                    httpContent
                );

                if (response.IsSuccessStatusCode)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    var result = JsonSerializer.Deserialize<OpenAIResponse>(jsonString, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });
                    return result?.choices?.FirstOrDefault()?.message?.content ?? "Xin lỗi, tôi không thể trả lời câu hỏi này.";
                }
                else
                {
                    // Fallback nếu OpenAI API fail
                    return GenerateRuleBasedResponse(userMessage);
                }
            }
            catch
            {
                // Fallback nếu có lỗi
                return GenerateRuleBasedResponse(userMessage);
            }
        }

        // Phản hồi dựa trên quy tắc (không cần API key)
        private string GenerateRuleBasedResponse(string userMessage)
        {
            var lowerMessage = userMessage.ToLower();

            // Chào hỏi
            if (lowerMessage.Contains("chào") || lowerMessage.Contains("hello") || lowerMessage.Contains("xin chào"))
            {
                return "Xin chào! 👋 Tôi là trợ lý ảo của FastFood. Tôi có thể giúp bạn:\n" +
                       "• Tìm hiểu về menu 🍔\n" +
                       "• Hướng dẫn đặt hàng 🛒\n" +
                       "• Xem khuyến mãi 🎉\n" +
                       "• Liên hệ hỗ trợ 📞\n\n" +
                       "Bạn cần hỗ trợ gì hôm nay?";
            }

            // Menu
            if (lowerMessage.Contains("menu") || lowerMessage.Contains("món") || lowerMessage.Contains("đồ ăn"))
            {
                return "Chúng tôi có nhiều món ngon cho bạn:\n" +
                       "🍔 Burger - Burger thơm ngon, giòn tan\n" +
                       "🍕 Pizza - Pizza đa dạng topping\n" +
                       "🍗 Gà rán - Gà giòn cay, đậm đà\n" +
                       "🥤 Đồ uống - Nước ngọt, cà phê, trà sữa\n\n" +
                       "Bạn có thể xem chi tiết menu tại trang <a href='/Menu'>Thực đơn</a> nhé! 😊";
            }

            // Đặt hàng
            if (lowerMessage.Contains("đặt hàng") || lowerMessage.Contains("đặt món") || lowerMessage.Contains("mua"))
            {
                return "Để đặt hàng, bạn có thể:\n" +
                       "1️⃣ Xem menu tại <a href='/Menu'>Thực đơn</a>\n" +
                       "2️⃣ Thêm món vào giỏ hàng 🛒\n" +
                       "3️⃣ Thanh toán tại trang checkout\n\n" +
                       "Bạn cần đăng nhập để đặt hàng. <a href='/AccountView/Login'>Đăng nhập ngay</a> nhé! 😊";
            }

            // Khuyến mãi
            if (lowerMessage.Contains("khuyến mãi") || lowerMessage.Contains("giảm giá") || lowerMessage.Contains("promotion"))
            {
                return "Hiện tại chúng tôi có nhiều khuyến mãi hấp dẫn:\n" +
                       "🎉 Giảm đến 50% cho combo burger, pizza, gà rán & đồ uống\n" +
                       "🎁 Giảm 20% đơn đầu tiên cho khách hàng mới\n\n" +
                       "Xem chi tiết tại trang <a href='/Promotion'>Khuyến mãi</a> nhé! 😊";
            }

            // Giờ mở cửa
            if (lowerMessage.Contains("giờ mở") || lowerMessage.Contains("mở cửa") || lowerMessage.Contains("thời gian"))
            {
                return "⏰ Giờ mở cửa:\n" +
                       "• Thứ 2 - Chủ nhật: 8:00 - 22:00\n" +
                       "• Nghỉ lễ: 9:00 - 21:00\n\n" +
                       "Bạn có thể đặt hàng online bất cứ lúc nào! 😊";
            }

            // Địa chỉ / Liên hệ
            if (lowerMessage.Contains("địa chỉ") || lowerMessage.Contains("liên hệ") || lowerMessage.Contains("contact") || lowerMessage.Contains("địa điểm"))
            {
                return "📞 Liên hệ với chúng tôi:\n" +
                       "• Hotline: 0123 456 789\n" +
                       "• Email: contact@fastfood.com\n" +
                       "• Địa chỉ: 123 Đường ABC, Quận XYZ, TP.HCM\n\n" +
                       "Hoặc để lại tin nhắn tại trang <a href='/Contact'>Liên hệ</a> nhé! 😊";
            }

            // Giá
            if (lowerMessage.Contains("giá") || lowerMessage.Contains("price") || lowerMessage.Contains("bao nhiêu"))
            {
                return "💰 Giá cả rất hợp lý:\n" +
                       "• Burger: từ 50.000đ\n" +
                       "• Pizza: từ 150.000đ\n" +
                       "• Gà rán: từ 80.000đ\n" +
                       "• Combo: từ 120.000đ\n\n" +
                       "Xem chi tiết giá tại <a href='/Menu'>Thực đơn</a> nhé! 😊";
            }

            // Cảm ơn
            if (lowerMessage.Contains("cảm ơn") || lowerMessage.Contains("thanks") || lowerMessage.Contains("thank you"))
            {
                return "Cảm ơn bạn đã liên hệ! 😊\n" +
                       "Nếu cần thêm thông tin, cứ hỏi tôi nhé!\n" +
                       "Chúc bạn có một ngày tuyệt vời! 🌟";
            }

            // Câu hỏi mặc định
            return "Xin chào! 😊 Tôi là trợ lý ảo của FastFood.\n\n" +
                   "Tôi có thể giúp bạn:\n" +
                   "• Tìm hiểu về menu và món ăn 🍔\n" +
                   "• Hướng dẫn đặt hàng 🛒\n" +
                   "• Thông tin khuyến mãi 🎉\n" +
                   "• Giờ mở cửa và liên hệ 📞\n\n" +
                   "Bạn muốn biết gì nào? 😊";
        }

        // Models
        public class ChatMessageRequest
        {
            public string Message { get; set; } = string.Empty;
            public int? UserId { get; set; }
        }

        public class ChatMessageResponse
        {
            public string Message { get; set; } = string.Empty;
            public DateTime Timestamp { get; set; }
        }

        private class OpenAIResponse
        {
            public List<OpenAIChoice>? choices { get; set; }
        }

        private class OpenAIChoice
        {
            public OpenAIMessage? message { get; set; }
        }

        private class OpenAIMessage
        {
            public string? content { get; set; }
        }
    }
}

