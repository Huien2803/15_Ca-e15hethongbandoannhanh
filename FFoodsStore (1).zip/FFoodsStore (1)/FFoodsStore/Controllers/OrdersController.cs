using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;

namespace FFoodsStore.Controllers
{
    public class OrdersController : Controller
    {
        private readonly StoreDbContext _db;
        public OrdersController(StoreDbContext db) => _db = db;

        // GET: /Orders
        public IActionResult Index()
        {
            return View();
        }
    }
}

