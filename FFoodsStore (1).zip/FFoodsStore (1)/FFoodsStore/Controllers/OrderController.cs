using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using System.Linq;
using static FFoodsStore.Models.OrderStatusHelper;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly StoreDbContext _db;
        public OrderController(StoreDbContext db) => _db = db;

        // GET: api/order/by-account/1
        [HttpGet("by-account/{accountId}")]
        public async Task<IActionResult> GetOrders(int accountId)
        {
            var orders = await _db.Orders
                .Where(o => o.AccountID == accountId && (o.IsDeleted == null || o.IsDeleted == false))
                .OrderByDescending(o => o.CreateDate)
                .Select(o => new
                {
                    id = o.ID,
                    orderCode = o.OrderCode ?? "",
                    customerName = o.CustomerName ?? "",
                    phoneNumber = o.PhoneNumber ?? "",
                    address = o.Address ?? "",
                    status = o.Status ?? 1,
                    statusName = OrderStatusHelper.GetStatusName(o.Status),
                    createDate = o.CreateDate,
                    total = _db.OrderDetails
                        .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                        .Sum(od => od.TotalMoney ?? 0)
                })
                .ToListAsync();

            return Ok(new { orders });
        }

        // GET: api/order/{orderId}
        [HttpGet("{orderId}")]
        public async Task<IActionResult> GetOrder(int orderId)
        {
            var order = await _db.Orders
                .Where(o => o.ID == orderId && (o.IsDeleted == null || o.IsDeleted == false))
                .Select(o => new
                {
                    id = o.ID,
                    orderCode = o.OrderCode ?? "",
                    customerName = o.CustomerName ?? "",
                    phoneNumber = o.PhoneNumber ?? "",
                    address = o.Address ?? "",
                    paymentMethod = o.PaymentMethod ?? "cod",
                    status = o.Status ?? 1,
                    statusName = OrderStatusHelper.GetStatusName(o.Status),
                    createDate = o.CreateDate,
                    total = _db.OrderDetails
                        .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                        .Sum(od => od.TotalMoney ?? 0)
                })
                .FirstOrDefaultAsync();

            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            return Ok(new { order });
        }

        // GET: api/order/{orderId}/details
        [HttpGet("{orderId}/details")]
        public async Task<IActionResult> GetOrderDetails(int orderId)
        {
            var details = await _db.OrderDetails
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.Product!)
                        .ThenInclude(p => p.ProductImages)
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.ProductSize)
                .Where(od => od.OrderID == orderId && (od.IsDelete == null || od.IsDelete == false))
                .Select(od => new
                {
                    id = od.ID,
                    quantity = od.Quantity ?? 0,
                    totalMoney = od.TotalMoney ?? 0,
                    productDetail = od.ProductDetail == null ? null : new
                    {
                        id = od.ProductDetail.ID,
                        productId = od.ProductDetail.ProductID,
                        price = od.ProductDetail.Price ?? 0,
                        productSize = od.ProductDetail.ProductSize == null ? null : new
                        {
                            id = od.ProductDetail.ProductSize.ID,
                            sizeName = od.ProductDetail.ProductSize.SizeName ?? "",
                            sizeCode = od.ProductDetail.ProductSize.SizeCode ?? ""
                        },
                        product = od.ProductDetail.Product == null ? null : new
                        {
                            id = od.ProductDetail.Product.ID,
                            productName = od.ProductDetail.Product.ProductName ?? "",
                            productCode = od.ProductDetail.Product.ProductCode ?? "",
                            productImages = (od.ProductDetail.Product.ProductImages != null 
                                ? od.ProductDetail.Product.ProductImages
                                    .Where(img => img.IsDelete != true)
                                    .Select(img => new { 
                                        imageUrl = img.ImageUrl ?? "",
                                        imageName = img.ImageName ?? ""
                                    })
                                : Enumerable.Empty<object>())
                                .ToList()
                        }
                    }
                })
                .ToListAsync();

            return Ok(new { items = details });
        }

    }
}

