using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using static FFoodsStore.Models.OrderStatus;
using static FFoodsStore.Models.OrderStatusHelper;

namespace FFoodsStore.Controllers
{
    public class AdminController : Controller
    {
        private readonly StoreDbContext _context;

        public AdminController(StoreDbContext context)
        {
            _context = context;
        }

        // ========== DASHBOARD ==========
        public async Task<IActionResult> Dashboard()
        {
            // Tính tổng doanh thu từ OrderDetails - CHỈ tính đơn hàng Completed
            var completedOrderIds = await _context.Orders
                .Where(o => o.Status == (int)OrderStatus.Completed && (!o.IsDeleted.HasValue || !o.IsDeleted.Value))
                .Select(o => o.ID)
                .ToListAsync();
            
            var totalRevenue = await _context.OrderDetails
                .Where(od => od.OrderID.HasValue && completedOrderIds.Contains(od.OrderID.Value))
                .SumAsync(od => od.TotalMoney ?? 0);

            // Thống kê tổng quan
            var stats = new
            {
                TotalOrders = await _context.Orders.CountAsync(o => !o.IsDeleted.HasValue || !o.IsDeleted.Value),
                PendingOrders = await _context.Orders.CountAsync(o => o.Status == (int)OrderStatus.Pending && (!o.IsDeleted.HasValue || !o.IsDeleted.Value)),
                SuccessOrders = await _context.Orders.CountAsync(o => o.Status == (int)OrderStatus.Completed && (!o.IsDeleted.HasValue || !o.IsDeleted.Value)),
                FailedOrders = await _context.Orders.CountAsync(o => o.Status == (int)OrderStatus.Failed && (!o.IsDeleted.HasValue || !o.IsDeleted.Value)),
                TotalRevenue = totalRevenue,
                TotalProducts = await _context.Products.CountAsync(),
                TotalUsers = await _context.Accounts.CountAsync(a => a.Role == 0 && !a.IsDelete),
                TotalContacts = await _context.Contact.CountAsync(c => !c.IsDelete.HasValue || !c.IsDelete.Value),
                UnreadContacts = await _context.Contact.CountAsync(c => c.Status == 0 && (!c.IsDelete.HasValue || !c.IsDelete.Value)),
                ActivePromotions = await _context.Promotion.CountAsync(p => p.IsActive && !p.IsDeleted)
            };

            // Đơn hàng gần đây với tổng tiền
            var recentOrdersList = await _context.Orders
                .Where(o => !o.IsDeleted.HasValue || !o.IsDeleted.Value)
                .OrderByDescending(o => o.CreateDate)
                .Take(10)
                .Select(o => new
                {
                    o.ID,
                    o.OrderCode,
                    o.CustomerName,
                    o.PhoneNumber,
                    o.Status,
                    o.CreateDate
                })
                .ToListAsync();

            // Tính tổng tiền cho mỗi đơn hàng
            var recentOrders = recentOrdersList.Select(o => new
            {
                o.ID,
                o.OrderCode,
                o.CustomerName,
                o.PhoneNumber,
                TotalMoney = _context.OrderDetails
                    .Where(od => od.OrderID == o.ID)
                    .Sum(od => od.TotalMoney ?? 0),
                o.Status,
                o.CreateDate
            }).ToList();

            // Liên hệ chưa đọc
            var unreadContacts = await _context.Contact
                .Where(c => c.Status == 0 && (!c.IsDelete.HasValue || !c.IsDelete.Value))
                .OrderByDescending(c => c.CreatedDate)
                .Take(5)
                .ToListAsync();

            ViewBag.Stats = stats;
            ViewBag.RecentOrders = recentOrders;
            ViewBag.UnreadContacts = unreadContacts;

            return View();
        }

        // ========== QUẢN LÝ ĐƠN HÀNG ==========
        public async Task<IActionResult> Orders()
        {
            var orders = await _context.Orders
                .Where(o => !o.IsDeleted.HasValue || !o.IsDeleted.Value)
                .OrderByDescending(o => o.CreateDate)
                .ToListAsync();

            // Tính tổng tiền cho mỗi đơn hàng
            var orderTotals = new Dictionary<int, decimal>();
            foreach (var order in orders)
            {
                var totalMoney = await _context.OrderDetails
                    .Where(od => od.OrderID == order.ID)
                    .SumAsync(od => od.TotalMoney ?? 0);
                orderTotals[order.ID] = totalMoney;
            }

            ViewBag.OrderTotals = orderTotals;
            return View(orders);
        }

        [HttpGet]
        public async Task<IActionResult> OrderDetail(int id)
        {
            var order = await _context.Orders
                .FirstOrDefaultAsync(o => o.ID == id && (!o.IsDeleted.HasValue || !o.IsDeleted.Value));

            if (order == null)
            {
                return NotFound();
            }

            // Lấy OrderDetails riêng
            var orderDetails = await _context.OrderDetails
                .Include(od => od.ProductDetail)
                    .ThenInclude(pd => pd.Product)
                .Where(od => od.OrderID == id && (!od.IsDelete.HasValue || !od.IsDelete.Value))
                .ToListAsync();

            // Tính tổng tiền
            var totalMoney = orderDetails.Sum(od => od.TotalMoney ?? 0);
            
            ViewBag.TotalMoney = totalMoney;
            ViewBag.OrderDetails = orderDetails;

            return View(order);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateOrderStatus(int id, int status)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound();
            }

            order.Status = status;
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Cập nhật trạng thái đơn hàng thành công!";
            return RedirectToAction(nameof(OrderDetail), new { id });
        }

        // ========== MARK ORDER AS FAILED ==========
        [HttpPost]
        public async Task<IActionResult> MarkAsFailed(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                TempData["ErrorMessage"] = "Không tìm thấy đơn hàng!";
                return RedirectToAction(nameof(Orders));
            }

            // Update status to Failed
            order.Status = (int)OrderStatus.Failed;
            order.UpdatedDate = DateTime.Now;
            order.ReasonCancel = "Khách không nhận hàng";
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Đã đánh dấu đơn hàng là thất bại!";
            return RedirectToAction(nameof(OrderDetail), new { id });
        }

        // ========== QUẢN LÝ SẢN PHẨM ==========
        public IActionResult Products()
        {
            // Redirect đến ProductAdmin controller
            return RedirectToAction("Index", "ProductAdmin");
        }

        // ========== QUẢN LÝ LIÊN HỆ ==========
        public async Task<IActionResult> Contacts()
        {
            var contacts = await _context.Contact
                .Where(c => !c.IsDelete.HasValue || !c.IsDelete.Value)
                .OrderByDescending(c => c.CreatedDate)
                .ToListAsync();

            return View(contacts);
        }

        [HttpGet]
        public async Task<IActionResult> ContactDetail(int id)
        {
            var contact = await _context.Contact.FindAsync(id);
            if (contact == null)
            {
                return NotFound();
            }

            // Đánh dấu đã đọc nếu chưa đọc
            if (contact.Status == 0)
            {
                contact.Status = 1;
                contact.UpdatedDate = DateTime.Now;
                await _context.SaveChangesAsync();
            }

            return View(contact);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateContactStatus(int id, int status)
        {
            var contact = await _context.Contact.FindAsync(id);
            if (contact == null)
            {
                return NotFound();
            }

            contact.Status = status;
            contact.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Cập nhật trạng thái liên hệ thành công!";
            return RedirectToAction(nameof(ContactDetail), new { id });
        }

        [HttpPost]
        public async Task<IActionResult> DeleteContact(int id)
        {
            var contact = await _context.Contact.FindAsync(id);
            if (contact == null)
            {
                return NotFound();
            }

            contact.IsDelete = true;
            contact.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Xóa liên hệ thành công!";
            return RedirectToAction(nameof(Contacts));
        }

        // ========== QUẢN LÝ TÀI KHOẢN ==========
        public async Task<IActionResult> Accounts()
        {
            // Load ALL accounts (Admin + Staff + User) - no role filter
            var accounts = await _context.Accounts
                .Where(a => !a.IsDelete)
                .OrderByDescending(a => a.CreatedDate)
                .ToListAsync();

            return View(accounts);
        }

        [HttpPost]
        public async Task<IActionResult> ToggleAccountStatus(int id)
        {
            var account = await _context.Accounts.FindAsync(id);
            if (account == null)
            {
                return NotFound();
            }

            account.IsActive = account.IsActive == 1 ? 0 : 1;
            account.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = account.IsActive == 1 
                ? "Kích hoạt tài khoản thành công!" 
                : "Vô hiệu hóa tài khoản thành công!";

            return RedirectToAction(nameof(Accounts));
        }

        // ========== QUẢN LÝ KHUYẾN MÃI ==========
        public async Task<IActionResult> Promotions()
        {
            var promotions = await _context.Promotion
                .Where(p => !p.IsDeleted)
                .OrderByDescending(p => p.CreatedDate)
                .ToListAsync();

            return View(promotions);
        }

        // ========== HELPER METHODS ==========
        private Account? GetCurrentUser()
        {
            // Lấy user từ session hoặc từ request
            // Hiện tại dùng localStorage ở client side, nên có thể check qua API
            // Tạm thời return null, sẽ check ở client side hoặc dùng middleware
            return null;
        }
    }
}

