using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using System.Linq;
using Microsoft.AspNetCore.Hosting;

namespace FFoodsStore.Controllers
{
    public class ProductAdminController : Controller
    {
        private readonly StoreDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public ProductAdminController(StoreDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        // ========== DANH SÁCH SẢN PHẨM ==========
        public async Task<IActionResult> Index()
        {
            // Chỉ admin mới được truy cập
            if (!IsAdmin())
            {
                TempData["ErrorMessage"] = "Bạn không có quyền truy cập trang này!";
                return RedirectToAction("Index", "Home");
            }

            var products = await _context.Products
                .Include(p => p.ProductType)
                .Include(p => p.ProductImages)
                .Where(p => p.IsDeleted == null || p.IsDeleted == false)
                .OrderByDescending(p => p.CreatedDate)
                .ToListAsync();

            return View(products);
        }

        // ========== THÊM SẢN PHẨM ==========
        [HttpGet]
        public IActionResult Create()
        {
            // Chỉ admin mới được truy cập
            if (!IsAdmin())
            {
                TempData["ErrorMessage"] = "Bạn không có quyền thêm sản phẩm!";
                return RedirectToAction("Index", "Home");
            }

            LoadProductTypes();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product model, IFormFileCollection productImages)
        {
            // Chỉ admin mới được tạo
            if (!IsAdmin())
            {
                TempData["ErrorMessage"] = "Bạn không có quyền thêm sản phẩm!";
                return RedirectToAction("Index", "Home");
            }

            if (ModelState.IsValid)
            {
                model.CreatedDate = DateTime.Now;
                model.IsDeleted = false;
                // IsActive sẽ được bind từ form checkbox
                if (model.IsActive == null)
                {
                    model.IsActive = false;
                }

                _context.Products.Add(model);
                await _context.SaveChangesAsync();

                // Xử lý upload ảnh sản phẩm
                if (productImages != null && productImages.Count > 0)
                {
                    var uploadsFolder = Path.Combine(_environment.WebRootPath, "images", "products");
                    
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
                    
                    foreach (var imageFile in productImages)
                    {
                        if (imageFile != null && imageFile.Length > 0)
                        {
                            var fileExtension = Path.GetExtension(imageFile.FileName).ToLowerInvariant();
                            
                            if (!allowedExtensions.Contains(fileExtension))
                            {
                                continue; // Bỏ qua file không hợp lệ
                            }

                            if (imageFile.Length > 10 * 1024 * 1024) // 10MB
                            {
                                continue; // Bỏ qua file quá lớn
                            }

                            var fileName = $"product_{model.ID}_{DateTime.Now.Ticks}_{Guid.NewGuid().ToString("N").Substring(0, 8)}{fileExtension}";
                            var filePath = Path.Combine(uploadsFolder, fileName);

                            using (var stream = new FileStream(filePath, FileMode.Create))
                            {
                                await imageFile.CopyToAsync(stream);
                            }

                            var productImage = new ProductImage
                            {
                                ProductID = model.ID,
                                ImageUrl = $"/images/products/{fileName}",
                                ImageName = imageFile.FileName,
                                CreatedDate = DateTime.Now,
                                IsDelete = false
                            };

                            _context.ProductImages.Add(productImage);
                        }
                    }
                    
                    await _context.SaveChangesAsync();
                }

                TempData["SuccessMessage"] = "Thêm sản phẩm thành công!";
                return RedirectToAction(nameof(Index));
            }

            LoadProductTypes();
            return View(model);
        }

        // ========== SỬA SẢN PHẨM ==========
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            // Chỉ admin mới được truy cập
            if (!IsAdmin())
            {
                TempData["ErrorMessage"] = "Bạn không có quyền sửa sản phẩm!";
                return RedirectToAction("Index", "Home");
            }

            var product = await _context.Products
                .Include(p => p.ProductType)
                .Include(p => p.ProductImages)
                .Include(p => p.ProductDetails)
                .FirstOrDefaultAsync(p => p.ID == id && (p.IsDeleted == null || p.IsDeleted == false));

            if (product == null)
            {
                return NotFound();
            }

            LoadProductTypes();
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Product model, IFormFileCollection productImages)
        {
            // Chỉ admin mới được sửa
            if (!IsAdmin())
            {
                TempData["ErrorMessage"] = "Bạn không có quyền sửa sản phẩm!";
                return RedirectToAction("Index", "Home");
            }

            if (ModelState.IsValid)
            {
                var existing = await _context.Products
                    .Include(p => p.ProductImages)
                    .FirstOrDefaultAsync(p => p.ID == model.ID);
                    
                if (existing == null)
                {
                    return NotFound();
                }

                existing.ProductCode = model.ProductCode;
                existing.ProductName = model.ProductName;
                existing.Description = model.Description;
                existing.ProductTypeID = model.ProductTypeID;
                // Handle nullable boolean from checkbox
                existing.IsActive = model.IsActive ?? false;
                existing.Ingredients = model.Ingredients;
                existing.Flavor = model.Flavor;
                existing.UpdatedDate = DateTime.Now;

                await _context.SaveChangesAsync();

                // Xử lý upload ảnh sản phẩm mới
                if (productImages != null && productImages.Count > 0)
                {
                    var uploadsFolder = Path.Combine(_environment.WebRootPath, "images", "products");
                    
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
                    
                    foreach (var imageFile in productImages)
                    {
                        if (imageFile != null && imageFile.Length > 0)
                        {
                            var fileExtension = Path.GetExtension(imageFile.FileName).ToLowerInvariant();
                            
                            if (!allowedExtensions.Contains(fileExtension))
                            {
                                continue; // Bỏ qua file không hợp lệ
                            }

                            if (imageFile.Length > 10 * 1024 * 1024) // 10MB
                            {
                                continue; // Bỏ qua file quá lớn
                            }

                            var fileName = $"product_{existing.ID}_{DateTime.Now.Ticks}_{Guid.NewGuid().ToString("N").Substring(0, 8)}{fileExtension}";
                            var filePath = Path.Combine(uploadsFolder, fileName);

                            using (var stream = new FileStream(filePath, FileMode.Create))
                            {
                                await imageFile.CopyToAsync(stream);
                            }

                            var productImage = new ProductImage
                            {
                                ProductID = existing.ID,
                                ImageUrl = $"/images/products/{fileName}",
                                ImageName = imageFile.FileName,
                                CreatedDate = DateTime.Now,
                                IsDelete = false
                            };

                            _context.ProductImages.Add(productImage);
                        }
                    }
                    
                    await _context.SaveChangesAsync();
                }

                TempData["SuccessMessage"] = "Cập nhật sản phẩm thành công!";
                return RedirectToAction(nameof(Index));
            }

            LoadProductTypes();
            return View(model);
        }

        // ========== XÓA SẢN PHẨM (SOFT DELETE) ==========
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            // Chỉ admin mới được xóa
            if (!IsAdmin())
            {
                TempData["ErrorMessage"] = "Bạn không có quyền xóa sản phẩm!";
                return RedirectToAction("Index", "Home");
            }

            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            // Soft delete
            product.IsDeleted = true;
            product.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Xóa sản phẩm thành công!";
            return RedirectToAction(nameof(Index));
        }

        // ========== XÓA ẢNH SẢN PHẨM ==========
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteImage(int imageId)
        {
            // Chỉ admin mới được xóa
            if (!IsAdmin())
            {
                return Json(new { success = false, message = "Bạn không có quyền xóa ảnh!" });
            }

            var image = await _context.ProductImages.FindAsync(imageId);
            if (image == null)
            {
                return Json(new { success = false, message = "Không tìm thấy ảnh!" });
            }

            // Xóa file vật lý
            if (!string.IsNullOrEmpty(image.ImageUrl))
            {
                var filePath = Path.Combine(_environment.WebRootPath, image.ImageUrl.TrimStart('/'));
                if (System.IO.File.Exists(filePath))
                {
                    try
                    {
                        System.IO.File.Delete(filePath);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"[PRODUCT] Error deleting image file: {ex.Message}");
                    }
                }
            }

            // Soft delete
            image.IsDelete = true;
            image.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Json(new { success = true, message = "Xóa ảnh thành công!" });
        }

        // ========== HELPER METHODS ==========
        private void LoadProductTypes()
        {
            var productTypes = _context.ProductTypes
                .Where(pt => pt.IsDelete == null || pt.IsDelete == false)
                .OrderBy(pt => pt.TypeName)
                .ToList();

            ViewBag.ProductTypes = new SelectList(productTypes, "ID", "TypeName");
        }

        private bool IsAdmin()
        {
            // Kiểm tra user từ localStorage qua JavaScript
            // Validation thực tế sẽ ở client-side
            // Tạm thời return true, sẽ được validate ở client-side
            return true;
        }
    }
}

