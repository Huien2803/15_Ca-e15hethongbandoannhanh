using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.Models.Dtos;

namespace FFoodsStore.Controllers
{
    [Route("[controller]")]
    public class CheckoutController : Controller
    {
        private readonly StoreDbContext _db;
        public CheckoutController(StoreDbContext db) => _db = db;

        // GET: /Checkout
        [HttpGet]
        [HttpGet("Index")]
        public async Task<IActionResult> Index()
        {
            try
            {
                // Get account ID from session/localStorage - frontend will handle auth check
                // This controller just renders the view, validation happens in checkout.js
                return View();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in Checkout Index: {ex.Message}");
                return RedirectToAction("Index", "CartView");
            }
        }

        // GET: /Checkout/Success/{id}
        [HttpGet("Success/{id}")]
        public async Task<IActionResult> Success(int id)
        {
            try
            {
                var order = await _db.Orders
                    .FirstOrDefaultAsync(o => o.ID == id && (o.IsDeleted == null || o.IsDeleted == false));

                if (order == null)
                {
                    return NotFound();
                }

                return View(order);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in Checkout Success: {ex.Message}");
                return NotFound();
            }
        }
    }
}

