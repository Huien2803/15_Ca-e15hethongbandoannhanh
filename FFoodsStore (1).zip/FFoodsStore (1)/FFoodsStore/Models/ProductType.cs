﻿using System;
using System.Collections.Generic;

namespace FFoodsStore.Models
{
    public class ProductType
    {
        public int ID { get; set; }
        public string? TypeCode { get; set; }
        public string? TypeName { get; set; }
        public int? GroupTypeID { get; set; }
        public string? Description { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string? UpdatedBy { get; set; }
        public bool? IsDelete { get; set; }

        // 🔗 Navigation
        public virtual ICollection<Product>? Products { get; set; }
    }
}
