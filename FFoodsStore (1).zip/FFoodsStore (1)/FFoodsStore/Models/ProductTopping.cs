﻿using System;
using System.Collections.Generic;

namespace FFoodsStore.Models;

public partial class ProductTopping
{
    public int ID { get; set; }

    public int? ToppingID { get; set; }

    public int? ProductID { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string? UpdatedBy { get; set; }
}
