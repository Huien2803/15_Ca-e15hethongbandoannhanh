using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FFoodsStore.Models
{
    [Table("Promotion")] // ⚠️ Bắt buộc, vì database của bạn là [Promotion] (không có "s")
    public class Promotion
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(250)]
        [Display(Name = "Tên chương trình")]
        public string Name { get; set; } = string.Empty;

        [StringLength(50)]
        [Display(Name = "Mã khuyến mãi (Code)")]
        public string Code { get; set; } = string.Empty;

        [Display(Name = "Loại khuyến mãi")] // 1: %, 2: tiền mặt, 3: khác
        public int Type { get; set; }

        [Display(Name = "Giá trị giảm")]
        public decimal Value { get; set; }

        [Display(Name = "Giảm tối đa")]
        public decimal? MaxDiscount { get; set; }

        [Display(Name = "Đơn tối thiểu")]
        public decimal? MinOrderValue { get; set; }

        [Display(Name = "Ngày bắt đầu")]
        public DateTime StartDate { get; set; }

        [Display(Name = "Ngày kết thúc")]
        public DateTime EndDate { get; set; }

        [Display(Name = "Hoạt động")]
        public bool IsActive { get; set; } = true;

        [Display(Name = "Ảnh banner")]
        public string? BannerUrl { get; set; }

        [Display(Name = "Mô tả")]
        public string? Description { get; set; }

        [Display(Name = "Ngày tạo")]
        public DateTime? CreatedDate { get; set; } = DateTime.Now;

        [Display(Name = "Người tạo")]
        public string? CreatedBy { get; set; }

        [Display(Name = "Ngày cập nhật")]
        public DateTime? UpdatedDate { get; set; }

        [Display(Name = "Người cập nhật")]
        public string? UpdatedBy { get; set; }

        [Display(Name = "Đã xóa")]
        public bool IsDeleted { get; set; } = false;
    }
}
