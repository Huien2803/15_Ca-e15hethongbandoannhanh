namespace FFoodsStore.Models.Dtos
{
    public class UpdateStatusDto
    {
        public int Status { get; set; }
    }
}




