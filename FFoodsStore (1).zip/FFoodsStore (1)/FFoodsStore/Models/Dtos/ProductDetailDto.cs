namespace FFoodsStore.Models.Dtos
{
    /// <summary>
    /// DTO for product detail information including size and price
    /// </summary>
    public class ProductDetailDto
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public int SizeId { get; set; }
        public string SizeName { get; set; } = "";
        public decimal Price { get; set; }
    }
}
