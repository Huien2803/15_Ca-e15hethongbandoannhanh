﻿using System;
using System.Collections.Generic;

namespace FFoodsStore.Models;

public partial class Cart
{
    public int ID { get; set; }

    public int? AccountId { get; set; }

    public int? ProductDetailId { get; set; }

    public int? Quantity { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public virtual Account? Account { get; set; }
    public virtual ProductDetail? ProductDetail { get; set; }
    public virtual ICollection<CartTopping>? CartToppings { get; set; }
}
