﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace FFoodsStore.Models
{
    public class ProductDetail
    {
        public int ID { get; set; }
        public int? ProductID { get; set; }
        public int? ProductSizeID { get; set; }
        public decimal? Price { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string? UpdatedBy { get; set; }
        public bool? IsDelete { get; set; }

        [ForeignKey("ProductID")]
        public virtual Product? Product { get; set; }

        [ForeignKey("ProductSizeID")]
        public virtual ProductSize? ProductSize { get; set; }
    }
}
