namespace FFoodsStore.Models
{
    /// <summary>
    /// Enum representing order status values
    /// </summary>
    public enum OrderStatus
    {
        /// <summary>
        /// Chờ xác nhận
        /// </summary>
        Pending = 1,

        /// <summary>
        /// Đã xác nhận
        /// </summary>
        Confirmed = 2,

        /// <summary>
        /// Đang chuẩn bị
        /// </summary>
        Preparing = 3,

        /// <summary>
        /// Đang giao hàng
        /// </summary>
        Shipping = 4,

        /// <summary>
        /// Giao hàng thành công
        /// </summary>
        Completed = 5,

        /// <summary>
        /// Giao hàng thất bại (Khách không nhận hàng)
        /// </summary>
        Failed = 6
    }

    /// <summary>
    /// Helper methods for OrderStatus
    /// </summary>
    public static class OrderStatusHelper
    {
        /// <summary>
        /// Get status name in Vietnamese
        /// </summary>
        public static string GetStatusName(int? status)
        {
            return status switch
            {
                (int)OrderStatus.Pending => "Chờ xác nhận",
                (int)OrderStatus.Confirmed => "Đã xác nhận",
                (int)OrderStatus.Preparing => "Đang chuẩn bị",
                (int)OrderStatus.Shipping => "Đang giao hàng",
                (int)OrderStatus.Completed => "Giao hàng thành công",
                (int)OrderStatus.Failed => "Giao hàng thất bại",
                _ => "Không xác định"
            };
        }

        /// <summary>
        /// Get status badge CSS class
        /// </summary>
        public static string GetStatusBadgeClass(int? status)
        {
            return status switch
            {
                (int)OrderStatus.Pending => "badge-warning",
                (int)OrderStatus.Confirmed => "badge-info",
                (int)OrderStatus.Preparing => "badge-info",
                (int)OrderStatus.Shipping => "badge-info",
                (int)OrderStatus.Completed => "badge-success",
                (int)OrderStatus.Failed => "badge-danger",
                _ => "badge-secondary"
            };
        }

        /// <summary>
        /// Get status icon class
        /// </summary>
        public static string GetStatusIcon(int? status)
        {
            return status switch
            {
                (int)OrderStatus.Pending => "fas fa-clock",
                (int)OrderStatus.Confirmed => "fas fa-check-circle",
                (int)OrderStatus.Preparing => "fas fa-utensils",
                (int)OrderStatus.Shipping => "fas fa-truck",
                (int)OrderStatus.Completed => "fas fa-check-circle",
                (int)OrderStatus.Failed => "fas fa-times-circle",
                _ => "fas fa-question-circle"
            };
        }

        /// <summary>
        /// Check if status is a final status (Completed or Failed)
        /// </summary>
        public static bool IsFinalStatus(int? status)
        {
            return status == (int)OrderStatus.Completed || status == (int)OrderStatus.Failed;
        }
    }
}

