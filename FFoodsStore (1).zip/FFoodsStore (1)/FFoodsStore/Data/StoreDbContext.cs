﻿using System;
using System.Collections.Generic;
using FFoodsStore.Models;
using Microsoft.EntityFrameworkCore;

namespace FFoodsStore.Data
{
    public partial class StoreDbContext : DbContext
    {
        public StoreDbContext(DbContextOptions<StoreDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Account> Accounts { get; set; }
        public virtual DbSet<Cart> Carts { get; set; }
        public virtual DbSet<CartTopping> CartToppings { get; set; }
        public virtual DbSet<GoodsIssue> GoodsIssues { get; set; }
        public virtual DbSet<GoodsIssueDetail> GoodsIssueDetails { get; set; }
        public virtual DbSet<GoodsIssueFile> GoodsIssueFiles { get; set; }
        public virtual DbSet<GoodsReceipt> GoodsReceipts { get; set; }
        public virtual DbSet<GoodsReceiptDetail> GoodsReceiptDetails { get; set; }
        public virtual DbSet<GoodsReceiptFile> GoodsReceiptFiles { get; set; }
        public virtual DbSet<LinkUrl> LinkUrls { get; set; }
        public virtual DbSet<Material> Materials { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<OrderDetail> OrderDetails { get; set; }
        public virtual DbSet<OrderDetailsTopping> OrderDetailsToppings { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<ProductDetail> ProductDetails { get; set; }
        public virtual DbSet<ProductImage> ProductImages { get; set; }
        public virtual DbSet<ProductSize> ProductSizes { get; set; }
        public virtual DbSet<ProductTopping> ProductToppings { get; set; }
        public virtual DbSet<ProductType> ProductTypes { get; set; }
        public virtual DbSet<Supplier> Suppliers { get; set; }
        public virtual DbSet<Topping> Toppings { get; set; }
        public virtual DbSet<Unit> Units { get; set; }
        public virtual DbSet<Promotion> Promotion { get; set; }
        public virtual DbSet<Contact> Contact { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // ================= ACCOUNT =================
            modelBuilder.Entity<Account>(entity =>
            {
                entity.ToTable("Account");
                entity.Property(e => e.Address).HasMaxLength(250);
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.Email).HasMaxLength(250);
                entity.Property(e => e.FullName).HasMaxLength(250);
                entity.Property(e => e.Password).HasMaxLength(250);
                entity.Property(e => e.PhoneNumber).HasMaxLength(250);
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            // ================= CART =================
            modelBuilder.Entity<Cart>(entity =>
            {
                entity.ToTable("Cart");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<CartTopping>(entity =>
            {
                entity.ToTable("CartTopping");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            // ================= GOODS ISSUE =================
            modelBuilder.Entity<GoodsIssue>(entity =>
            {
                entity.ToTable("GoodsIssue");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.Decription).HasMaxLength(550);
                entity.Property(e => e.GoodIssueCode).HasMaxLength(150);
                entity.Property(e => e.IssueDate).HasColumnType("datetime");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<GoodsIssueDetail>(entity =>
            {
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.Decription).HasMaxLength(550);
                entity.Property(e => e.Quantity).HasColumnType("decimal(18, 2)");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<GoodsIssueFile>(entity =>
            {
                entity.ToTable("GoodsIssueFile");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            // ================= GOODS RECEIPT =================
            modelBuilder.Entity<GoodsReceipt>(entity =>
            {
                entity.ToTable("GoodsReceipt");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.Decription).HasMaxLength(550);
                entity.Property(e => e.GoodsReceiptCode).HasMaxLength(250);
                entity.Property(e => e.ReceiptedDate).HasColumnType("datetime");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<GoodsReceiptDetail>(entity =>
            {
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.Quantity).HasColumnType("decimal(18, 2)");
                entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 2)");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<GoodsReceiptFile>(entity =>
            {
                entity.ToTable("GoodsReceiptFile");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            // ================= LINK URL =================
            modelBuilder.Entity<LinkUrl>(entity =>
            {
                entity.ToTable("LinkUrl");
                entity.Property(e => e.LinkUrl1).HasColumnName("LinkUrl");
                entity.Property(e => e.TypeUrl).HasMaxLength(250);
            });

            // ================= MATERIAL =================
            modelBuilder.Entity<Material>(entity =>
            {
                entity.ToTable("Material");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.MaterialCode).HasMaxLength(250);
                entity.Property(e => e.MaterialName).HasMaxLength(250);
                entity.Property(e => e.MinQuantity).HasColumnType("decimal(18, 2)");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            // ================= ORDER =================
            modelBuilder.Entity<Order>(entity =>
            {
                entity.ToTable("Order");
                entity.Property(e => e.Address).HasMaxLength(250);
                entity.Property(e => e.CreateBy).HasMaxLength(150);
                entity.Property(e => e.CreateDate).HasColumnType("datetime");
                entity.Property(e => e.CustomerName).HasMaxLength(250);
                entity.Property(e => e.OrderCode).HasMaxLength(250);
                entity.Property(e => e.PhoneNumber).HasMaxLength(250);
                entity.Property(e => e.PaymentMethod).HasMaxLength(50);
                entity.Property(e => e.ReasonCancel).HasMaxLength(500);
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<OrderDetail>(entity =>
            {
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.TotalMoney).HasColumnType("decimal(18, 2)");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<OrderDetailsTopping>(entity =>
            {
                entity.ToTable("OrderDetailsTopping");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.ToppingPrice).HasColumnType("decimal(18, 2)");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            // ================= PRODUCT =================
            modelBuilder.Entity<Product>(entity =>
            {
                entity.ToTable("Product");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.Description).HasMaxLength(250);
                entity.Property(e => e.ProductCode).HasMaxLength(250);
                entity.Property(e => e.ProductName).HasMaxLength(250);
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<ProductDetail>(entity =>
            {
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.Price).HasColumnType("decimal(18, 2)");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<ProductImage>(entity =>
            {
                entity.ToTable("ProductImage");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<ProductSize>(entity =>
            {
                entity.ToTable("ProductSize");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.Description).HasMaxLength(250);
                entity.Property(e => e.SizeCode).HasMaxLength(250);
                entity.Property(e => e.SizeName).HasMaxLength(250);
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<ProductTopping>(entity =>
            {
                entity.ToTable("ProductTopping");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<ProductType>(entity =>
            {
                entity.ToTable("ProductType");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.Description).HasMaxLength(250);
                entity.Property(e => e.TypeCode).HasMaxLength(250);
                entity.Property(e => e.TypeName).HasMaxLength(250);
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            // ================= PRODUCT RELATIONSHIPS =================
            modelBuilder.Entity<Product>()
                .HasOne(p => p.ProductType)
                .WithMany(t => t.Products)
                .HasForeignKey(p => p.ProductTypeID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<ProductDetail>()
                .HasOne(d => d.Product)
                .WithMany(p => p.ProductDetails)
                .HasForeignKey(d => d.ProductID)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<ProductDetail>()
                .HasOne(d => d.ProductSize)
                .WithMany(s => s.ProductDetails)
                .HasForeignKey(d => d.ProductSizeID)
                .OnDelete(DeleteBehavior.Restrict);

            // ================= ORDER RELATIONSHIPS =================
            modelBuilder.Entity<OrderDetail>()
                .HasOne(od => od.ProductDetail)
                .WithMany()
                .HasForeignKey(od => od.ProductDetailID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<ProductImage>()
                .HasOne(i => i.Product)
                .WithMany(p => p.ProductImages)
                .HasForeignKey(i => i.ProductID)
                .OnDelete(DeleteBehavior.Cascade);

            // ================= SUPPLIER =================
            modelBuilder.Entity<Supplier>(entity =>
            {
                entity.ToTable("Supplier");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.PhoneNumber).HasMaxLength(250);
                entity.Property(e => e.SupplierCode).HasMaxLength(150);
                entity.Property(e => e.SupplierName).HasMaxLength(250);
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<Topping>(entity =>
            {
                entity.ToTable("Topping");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.ToppingCode).HasMaxLength(150);
                entity.Property(e => e.ToppingName).HasMaxLength(250);
                entity.Property(e => e.ToppingPrice).HasColumnType("decimal(18, 2)");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<Unit>(entity =>
            {
                entity.ToTable("Unit");
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.UnitCode).HasMaxLength(150);
                entity.Property(e => e.UnitName).HasMaxLength(250);
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            // ================= PROMOTION =================
            modelBuilder.Entity<Promotion>(entity =>
            {
                entity.ToTable("Promotion");

                entity.Property(e => e.Name).HasMaxLength(250);
                entity.Property(e => e.Code).HasMaxLength(50);
                entity.Property(e => e.Value).HasColumnType("decimal(18, 2)");
                entity.Property(e => e.MaxDiscount).HasColumnType("decimal(18, 2)");
                entity.Property(e => e.MinOrderValue).HasColumnType("decimal(18, 2)");
                entity.Property(e => e.StartDate).HasColumnType("datetime");
                entity.Property(e => e.EndDate).HasColumnType("datetime");
                entity.Property(e => e.BannerUrl).HasMaxLength(500);
                entity.Property(e => e.Description).HasMaxLength(1000);
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            // ================= CONTACT =================
            modelBuilder.Entity<Contact>(entity =>
            {
                entity.ToTable("Contact");

                entity.Property(e => e.Name).HasMaxLength(250);
                entity.Property(e => e.Email).HasMaxLength(250);
                entity.Property(e => e.PhoneNumber).HasMaxLength(250);
                entity.Property(e => e.Address).HasMaxLength(500);
                entity.Property(e => e.Content).HasMaxLength(2000);
                entity.Property(e => e.CreatedBy).HasMaxLength(150);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.UpdatedBy).HasMaxLength(150);
                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            OnModelCreatingPartial(modelBuilder);
        }
        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
