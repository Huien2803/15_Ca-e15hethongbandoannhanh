// ============================================
// ADMIN JAVASCRIPT
// ============================================

// Toggle sidebar
function toggleSidebar() {
    const sidebar = document.querySelector('.admin-sidebar');
    sidebar.classList.toggle('open');
}

// Load unread contacts count
async function loadUnreadContactsCount() {
    try {
        const response = await fetch('/api/contact/by-status/0');
        if (response.ok) {
            const contacts = await response.json();
            const badge = document.getElementById('unread-count');
            if (badge && contacts.length > 0) {
                badge.textContent = contacts.length;
                badge.style.display = 'inline-block';
            }
        }
    } catch (error) {
        console.error('Error loading unread contacts:', error);
    }
}

// Load admin info
function loadAdminInfo() {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    
    // Kiểm tra đăng nhập và role admin
    if (!user || !user.id) {
        alert('Vui lòng đăng nhập!');
        window.location.href = '/AccountView/Login';
        return;
    }
    
    if (user.role !== 1) {
        alert('Bạn không có quyền truy cập trang admin!');
        window.location.href = '/Home/Index';
        return;
    }
    
    // Load thông tin admin
    const adminNameEl = document.getElementById('admin-name');
    if (adminNameEl && user.fullName) {
        adminNameEl.textContent = user.fullName;
    }
    
    const adminAvatarEl = document.querySelector('.admin-avatar');
    if (adminAvatarEl && user.avatarUrl) {
        adminAvatarEl.src = user.avatarUrl;
    }
}

// Logout
function logout() {
    if (confirm('Bạn có chắc muốn đăng xuất?')) {
        localStorage.removeItem('user');
        localStorage.removeItem('role');
        localStorage.removeItem('accountId');
        window.location.href = '/AccountView/Login';
    }
}

// Update order status
async function updateOrderStatus(orderId, status) {
    if (!confirm('Bạn có chắc muốn cập nhật trạng thái đơn hàng?')) {
        return;
    }

    try {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/Admin/UpdateOrderStatus?id=${orderId}&status=${status}`;
        
        const csrfToken = document.querySelector('input[name="__RequestVerificationToken"]');
        if (csrfToken) {
            form.appendChild(csrfToken.cloneNode(true));
        }
        
        document.body.appendChild(form);
        form.submit();
    } catch (error) {
        console.error('Error updating order status:', error);
        alert('Có lỗi xảy ra khi cập nhật trạng thái đơn hàng');
    }
}

// Update contact status
async function updateContactStatus(contactId, status) {
    try {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/Admin/UpdateContactStatus?id=${contactId}&status=${status}`;
        
        const csrfToken = document.querySelector('input[name="__RequestVerificationToken"]');
        if (csrfToken) {
            form.appendChild(csrfToken.cloneNode(true));
        }
        
        document.body.appendChild(form);
        form.submit();
    } catch (error) {
        console.error('Error updating contact status:', error);
        alert('Có lỗi xảy ra khi cập nhật trạng thái liên hệ');
    }
}

// Delete contact
function deleteContact(contactId) {
    if (!confirm('Bạn có chắc muốn xóa liên hệ này?')) {
        return;
    }

    try {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/Admin/DeleteContact?id=${contactId}`;
        
        const csrfToken = document.querySelector('input[name="__RequestVerificationToken"]');
        if (csrfToken) {
            form.appendChild(csrfToken.cloneNode(true));
        }
        
        document.body.appendChild(form);
        form.submit();
    } catch (error) {
        console.error('Error deleting contact:', error);
        alert('Có lỗi xảy ra khi xóa liên hệ');
    }
}

// Toggle account status
function toggleAccountStatus(accountId) {
    if (!confirm('Bạn có chắc muốn thay đổi trạng thái tài khoản này?')) {
        return;
    }

    try {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/Admin/ToggleAccountStatus?id=${accountId}`;
        
        const csrfToken = document.querySelector('input[name="__RequestVerificationToken"]');
        if (csrfToken) {
            form.appendChild(csrfToken.cloneNode(true));
        }
        
        document.body.appendChild(form);
        form.submit();
    } catch (error) {
        console.error('Error toggling account status:', error);
        alert('Có lỗi xảy ra khi thay đổi trạng thái tài khoản');
    }
}

// Format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(amount || 0);
}

// Format date
function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('vi-VN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    }).format(date);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    loadAdminInfo();
    loadUnreadContactsCount();
    
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});


