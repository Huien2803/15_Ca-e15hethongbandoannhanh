// ===============================
// PROFILE PAGE - JavaScript
// ===============================
(function() {
    'use strict';

    let currentAccountId = null;
    let originalProfileData = null;

    // Initialize
    document.addEventListener('DOMContentLoaded', function() {
        init();
    });

    function init() {
        console.log('[PROFILE] Initializing...');
        
        // Get current account ID - check multiple times if auth.js not loaded yet
        let attempts = 0;
        const maxAttempts = 50; // 5 seconds
        
        const checkAuth = function() {
            attempts++;
            
            if (window.getCurrentAccountId) {
                try {
                    currentAccountId = window.getCurrentAccountId();
                    console.log('[PROFILE] Account ID:', currentAccountId);
                    
                    if (!currentAccountId) {
                        // Redirect to login if not logged in
                        alert('⚠️ Vui lòng đăng nhập để xem hồ sơ!');
                        window.location.href = '/AccountView/Login?returnUrl=' + encodeURIComponent(window.location.pathname);
                        return;
                    }

                    // Setup event listeners
                    setupEventListeners();

                    // Load profile data
                    loadProfile();
                } catch (error) {
                    console.error('[PROFILE] Error getting account ID:', error);
                    if (attempts >= maxAttempts) {
                        alert('⚠️ Lỗi tải trang! Vui lòng thử lại.');
                    } else {
                        setTimeout(checkAuth, 100);
                    }
                }
            } else {
                if (attempts < maxAttempts) {
                    setTimeout(checkAuth, 100);
                } else {
                    console.error('[PROFILE] auth.js not loaded after 5 seconds');
                    alert('⚠️ Lỗi tải trang! Vui lòng thử lại.');
                }
            }
        };
        
        // Start checking
        checkAuth();
    }

    function setupEventListeners() {
        // Avatar upload
        const btnChangeAvatar = document.getElementById('btnChangeAvatar');
        const avatarInput = document.getElementById('avatarInput');
        const btnRemoveAvatar = document.getElementById('btnRemoveAvatar');

        if (btnChangeAvatar && avatarInput) {
            btnChangeAvatar.addEventListener('click', function() {
                avatarInput.click();
            });
        }

        if (avatarInput) {
            avatarInput.addEventListener('change', handleAvatarUpload);
        }

        if (btnRemoveAvatar) {
            btnRemoveAvatar.addEventListener('click', handleRemoveAvatar);
        }

        // Profile form
        const profileForm = document.getElementById('profileForm');
        if (profileForm) {
            profileForm.addEventListener('submit', handleProfileSubmit);
        }

        // Password form
        const passwordForm = document.getElementById('passwordForm');
        if (passwordForm) {
            passwordForm.addEventListener('submit', handlePasswordSubmit);
        }
    }

    // ===============================
    // Load Profile Data
    // ===============================
    async function loadProfile() {
        try {
            if (window.showRatatouilleLoader) {
                window.showRatatouilleLoader('Đang tải thông tin...');
            }

            const response = await fetch(`/api/profile/${currentAccountId}`);
            
            if (window.hideRatatouilleLoader) {
                window.hideRatatouilleLoader();
            }

            if (!response.ok) {
                if (response.status === 404) {
                    throw new Error('Không tìm thấy thông tin tài khoản!');
                }
                throw new Error('Không thể tải thông tin!');
            }

            const data = await response.json();
            
            // Store original data
            originalProfileData = { ...data };

            // Populate form
            document.getElementById('fullName').value = data.fullName || '';
            document.getElementById('email').value = data.email || '';
            document.getElementById('phoneNumber').value = data.phoneNumber || '';
            document.getElementById('address').value = data.address || '';
            document.getElementById('gender').value = data.gender !== null && data.gender !== undefined ? data.gender : '';

            // Load avatar
            if (data.avatarUrl) {
                showAvatar(data.avatarUrl);
            } else {
                hideAvatar();
            }

        } catch (error) {
            console.error('Error loading profile:', error);
            if (window.hideRatatouilleLoader) {
                window.hideRatatouilleLoader();
            }
            showMessage('profileMessage', error.message, 'error');
        }
    }

    // ===============================
    // Avatar Management
    // ===============================
    async function handleAvatarUpload(e) {
        const file = e.target.files?.[0];
        if (!file) return;

        // Validate file
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
        if (!allowedTypes.includes(file.type)) {
            showMessage('profileMessage', 'Chỉ chấp nhận file ảnh (jpg, jpeg, png, gif, webp)!', 'error');
            return;
        }

        if (file.size > 5 * 1024 * 1024) {
            showMessage('profileMessage', 'File ảnh không được vượt quá 5MB!', 'error');
            return;
        }

        try {
            const formData = new FormData();
            formData.append('file', file);

            if (window.showRatatouilleLoader) {
                window.showRatatouilleLoader('Đang tải ảnh lên...');
            }

            const btnChangeAvatar = document.getElementById('btnChangeAvatar');
            if (btnChangeAvatar) {
                btnChangeAvatar.disabled = true;
                btnChangeAvatar.classList.add('loading');
            }

            const response = await fetch(`/api/profile/${currentAccountId}/upload-avatar`, {
                method: 'POST',
                body: formData
            });

            if (window.hideRatatouilleLoader) {
                window.hideRatatouilleLoader();
            }

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText || 'Không thể tải ảnh lên!');
            }

            const data = await response.json();
            
            // Update avatar display
            if (data.avatarUrl) {
                showAvatar(data.avatarUrl);
                // Update localStorage if needed
                const currentUser = window.getCurrentUser?.();
                if (currentUser) {
                    currentUser.avatarUrl = data.avatarUrl;
                    localStorage.setItem('user', JSON.stringify(currentUser));
                    
                    // Update navigation bar to show new avatar
                    if (window.updateNavigationBar) {
                        window.updateNavigationBar();
                    }
                }
            }

            showMessage('profileMessage', data.message || 'Cập nhật ảnh đại diện thành công!', 'success');

        } catch (error) {
            console.error('Error uploading avatar:', error);
            showMessage('profileMessage', error.message || 'Có lỗi xảy ra khi tải ảnh!', 'error');
        } finally {
            const btnChangeAvatar = document.getElementById('btnChangeAvatar');
            if (btnChangeAvatar) {
                btnChangeAvatar.disabled = false;
                btnChangeAvatar.classList.remove('loading');
            }
            // Reset input
            const avatarInput = document.getElementById('avatarInput');
            if (avatarInput) {
                avatarInput.value = '';
            }
        }
    }

    async function handleRemoveAvatar() {
        if (!confirm('Bạn có chắc muốn xóa ảnh đại diện không?')) {
            return;
        }

        // TODO: Implement remove avatar API endpoint if needed
        // For now, just hide the avatar
        hideAvatar();
        
        // Update localStorage to remove avatar
        const currentUser = window.getCurrentUser?.();
        if (currentUser) {
            delete currentUser.avatarUrl;
            localStorage.setItem('user', JSON.stringify(currentUser));
            
            // Update navigation bar to remove avatar icon
            if (window.updateNavigationBar) {
                window.updateNavigationBar();
            }
        }
        
        showMessage('profileMessage', 'Ảnh đại diện đã được xóa!', 'info');
    }

    function showAvatar(url) {
        const avatarImage = document.getElementById('avatarImage');
        const avatarPlaceholder = document.getElementById('avatarPlaceholder');
        const btnRemoveAvatar = document.getElementById('btnRemoveAvatar');

        if (avatarImage && avatarPlaceholder) {
            avatarImage.src = url;
            avatarImage.classList.add('show');
            avatarPlaceholder.classList.add('hidden');
        }

        if (btnRemoveAvatar) {
            btnRemoveAvatar.style.display = 'block';
        }
    }

    function hideAvatar() {
        const avatarImage = document.getElementById('avatarImage');
        const avatarPlaceholder = document.getElementById('avatarPlaceholder');
        const btnRemoveAvatar = document.getElementById('btnRemoveAvatar');

        if (avatarImage && avatarPlaceholder) {
            avatarImage.classList.remove('show');
            avatarPlaceholder.classList.remove('hidden');
            avatarImage.src = '';
        }

        if (btnRemoveAvatar) {
            btnRemoveAvatar.style.display = 'none';
        }
    }

    // ===============================
    // Update Profile
    // ===============================
    async function handleProfileSubmit(e) {
        e.preventDefault();

        const fullName = document.getElementById('fullName')?.value.trim() || '';
        const phoneNumber = document.getElementById('phoneNumber')?.value.trim() || '';
        const address = document.getElementById('address')?.value.trim() || '';
        const gender = document.getElementById('gender')?.value || null;

        try {
            const btnSaveProfile = document.getElementById('btnSaveProfile');
            if (btnSaveProfile) {
                btnSaveProfile.disabled = true;
                btnSaveProfile.classList.add('loading');
            }

            if (window.showRatatouilleLoader) {
                window.showRatatouilleLoader('Đang cập nhật...');
            }

            const response = await fetch(`/api/profile/${currentAccountId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    fullName: fullName || null,
                    phoneNumber: phoneNumber || null,
                    address: address || null,
                    gender: gender ? parseInt(gender) : null
                })
            });

            if (window.hideRatatouilleLoader) {
                window.hideRatatouilleLoader();
            }

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText || 'Không thể cập nhật thông tin!');
            }

            const data = await response.json();
            
            // Update original data
            originalProfileData = { ...data };

            // Update localStorage if needed
            const currentUser = window.getCurrentUser?.();
            if (currentUser && data.fullName) {
                currentUser.fullName = data.fullName;
                localStorage.setItem('user', JSON.stringify(currentUser));
                // Update navigation bar
                if (window.updateNavigationBar) {
                    window.updateNavigationBar();
                }
            }

            showMessage('profileMessage', data.message || 'Cập nhật thông tin thành công!', 'success');

        } catch (error) {
            console.error('Error updating profile:', error);
            showMessage('profileMessage', error.message || 'Có lỗi xảy ra khi cập nhật!', 'error');
        } finally {
            const btnSaveProfile = document.getElementById('btnSaveProfile');
            if (btnSaveProfile) {
                btnSaveProfile.disabled = false;
                btnSaveProfile.classList.remove('loading');
            }
        }
    }

    // ===============================
    // Change Password
    // ===============================
    async function handlePasswordSubmit(e) {
        e.preventDefault();

        const oldPassword = document.getElementById('oldPassword')?.value.trim() || '';
        const newPassword = document.getElementById('newPassword')?.value.trim() || '';
        const confirmPassword = document.getElementById('confirmPassword')?.value.trim() || '';

        // Validation
        if (!oldPassword || !newPassword || !confirmPassword) {
            showMessage('passwordMessage', 'Vui lòng điền đầy đủ thông tin!', 'error');
            return;
        }

        if (newPassword.length < 6) {
            showMessage('passwordMessage', 'Mật khẩu mới phải có ít nhất 6 ký tự!', 'error');
            return;
        }

        if (newPassword !== confirmPassword) {
            showMessage('passwordMessage', 'Mật khẩu mới và xác nhận không khớp!', 'error');
            return;
        }

        if (oldPassword === newPassword) {
            showMessage('passwordMessage', 'Mật khẩu mới phải khác mật khẩu cũ!', 'error');
            return;
        }

        try {
            const btnChangePassword = document.getElementById('btnChangePassword');
            if (btnChangePassword) {
                btnChangePassword.disabled = true;
                btnChangePassword.classList.add('loading');
            }

            if (window.showRatatouilleLoader) {
                window.showRatatouilleLoader('Đang đổi mật khẩu...');
            }

            const response = await fetch(`/api/profile/${currentAccountId}/change-password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    oldPassword: oldPassword,
                    newPassword: newPassword
                })
            });

            if (window.hideRatatouilleLoader) {
                window.hideRatatouilleLoader();
            }

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText || 'Không thể đổi mật khẩu!');
            }

            const data = await response.json();
            
            // Clear password fields
            document.getElementById('oldPassword').value = '';
            document.getElementById('newPassword').value = '';
            document.getElementById('confirmPassword').value = '';

            showMessage('passwordMessage', data.message || 'Đổi mật khẩu thành công!', 'success');

        } catch (error) {
            console.error('Error changing password:', error);
            showMessage('passwordMessage', error.message || 'Có lỗi xảy ra khi đổi mật khẩu!', 'error');
        } finally {
            const btnChangePassword = document.getElementById('btnChangePassword');
            if (btnChangePassword) {
                btnChangePassword.disabled = false;
                btnChangePassword.classList.remove('loading');
            }
        }
    }

    // ===============================
    // Helper Functions
    // ===============================
    function showMessage(elementId, message, type = 'info') {
        const messageEl = document.getElementById(elementId);
        if (!messageEl) return;

        messageEl.textContent = message;
        messageEl.className = `message ${type}`;
        messageEl.style.display = 'block';

        // Auto hide after 5 seconds
        setTimeout(() => {
            messageEl.style.display = 'none';
        }, 5000);

        // Scroll to message
        setTimeout(() => {
            messageEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }, 100);
    }
})();

