// ===============================
// CHECKOUT SUCCESS PAGE
// ===============================

(function() {
    'use strict';
    
    // Helper function để lấy account ID từ auth.js
    function getAccountId() {
        if (window.getCurrentAccountId) {
            return window.getCurrentAccountId();
        }
        return null; // Trả về null nếu chưa login
    }
    let orderData = null;
    let orderDetails = [];
    
    // ===============================
    // Khởi tạo khi trang load
    // ===============================
    function init() {
        console.log('Success page initialized');
        
        // Lấy orderId từ URL
        const urlParts = window.location.pathname.split('/');
        const orderId = parseInt(urlParts[urlParts.length - 1]);
        
        if (!orderId || isNaN(orderId)) {
            console.error('Invalid order ID');
            showError('Không tìm thấy mã đơn hàng!');
            return;
        }
        
        console.log('Loading order ID:', orderId);
        loadOrderData(orderId);
    }
    
    // ===============================
    // Load dữ liệu đơn hàng từ API
    // ===============================
    async function loadOrderData(orderId) {
        try {
            console.log('Fetching order data...');
            
            // Load order info và order details song song
            const [orderRes, detailsRes] = await Promise.all([
                fetch(`/api/order/${orderId}`),
                fetch(`/api/order/${orderId}/details`)
            ]);
            
            // Load order info
            if (orderRes.ok) {
                const contentType = orderRes.headers.get('content-type');
                if (contentType && contentType.includes('application/json')) {
                    const orderJson = await orderRes.json();
                    orderData = orderJson.order || orderJson;
                    console.log('Order data loaded:', orderData);
                } else {
                    console.warn('Order API returned non-JSON, using model data');
                    orderData = window.orderModelData || null;
                }
            } else {
                console.warn('Order API failed, using model data');
                orderData = window.orderModelData || null;
            }
            
            // Load order details
            if (detailsRes.ok) {
                const contentType = detailsRes.headers.get('content-type');
                if (contentType && contentType.includes('application/json')) {
                    const detailsJson = await detailsRes.json();
                    orderDetails = detailsJson.items || detailsJson.details || [];
                    console.log('Order details loaded:', orderDetails);
                }
            }
            
            // Render page
            renderSuccessPage();
            
        } catch (error) {
            console.error('Error loading order data:', error);
            showError('Không thể tải thông tin đơn hàng. Vui lòng thử lại sau.');
        }
    }
    
    // ===============================
    // Render trang thành công
    // ===============================
    function renderSuccessPage() {
        const container = document.getElementById('successContent');
        if (!container) return;
        
        // Nếu không có orderData từ API, dùng model data từ Razor
        if (!orderData && window.orderModelData) {
            orderData = window.orderModelData;
        }
        
        if (!orderData) {
            showError('Không tìm thấy thông tin đơn hàng!');
            return;
        }
        
        const orderCode = orderData.OrderCode || orderData.orderCode || '';
        const customerName = orderData.CustomerName || orderData.customerName || '';
        const phoneNumber = orderData.PhoneNumber || orderData.phoneNumber || '';
        const address = orderData.Address || orderData.address || '';
        const paymentMethod = orderData.PaymentMethod || orderData.paymentMethod || 'cod';
        const createDate = orderData.CreateDate || orderData.createDate || new Date();
        const total = orderData.Total || orderData.total || 0;
        
        // Format date
        let formattedDate = '';
        if (createDate) {
            const date = new Date(createDate);
            formattedDate = date.toLocaleDateString('vi-VN', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit'
            });
        }
        
        // Payment method name
        const paymentMethodName = paymentMethod === 'bank' 
            ? 'Thanh toán qua ngân hàng (QR Code)'
            : 'Thanh toán khi nhận hàng (COD)';
        
        // Build order items HTML
        const itemsHtml = buildOrderItemsHTML();
        
        container.innerHTML = `
            <div class="success-icon">
                <svg viewBox="0 0 24 24">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                </svg>
            </div>

            <h1 class="success-title">🎉 Thanh toán thành công!</h1>
            <p class="success-message">Cảm ơn bạn đã đặt hàng. Đơn hàng của bạn đang được xử lý.</p>

            <!-- Thông tin đơn hàng -->
            <div class="order-info">
                <h3>📦 Thông tin đơn hàng</h3>
                
                <div class="info-item">
                    <span class="info-label">Mã đơn hàng:</span>
                    <span class="info-value" style="color: #e31d14; font-weight: 700;">${escapeHtml(orderCode)}</span>
                </div>

                <div class="info-item">
                    <span class="info-label">Tên khách hàng:</span>
                    <span class="info-value">${escapeHtml(customerName)}</span>
                </div>

                <div class="info-item">
                    <span class="info-label">Số điện thoại:</span>
                    <span class="info-value">${escapeHtml(phoneNumber)}</span>
                </div>

                <div class="info-item">
                    <span class="info-label">Địa chỉ giao hàng:</span>
                    <span class="info-value">${escapeHtml(address)}</span>
                </div>

                <div class="info-item">
                    <span class="info-label">Phương thức thanh toán:</span>
                    <span class="info-value" style="display: flex; align-items: center; gap: 8px; justify-content: flex-end;">
                        ${paymentMethod === 'bank' 
                            ? '<span style="background: linear-gradient(135deg, #1976d2 0%, #1565c0 100%); color: #fff; padding: 6px 14px; border-radius: 8px; font-weight: 700; font-size: 14px; box-shadow: 0 2px 8px rgba(25, 118, 210, 0.3);">🏦 Thanh toán qua ngân hàng (QR Code)</span>' 
                            : '<span style="background: linear-gradient(135deg, #4caf50 0%, #388e3c 100%); color: #fff; padding: 6px 14px; border-radius: 8px; font-weight: 700; font-size: 14px; box-shadow: 0 2px 8px rgba(76, 175, 80, 0.3);">💵 Thanh toán khi nhận hàng (COD)</span>'}
                    </span>
                </div>

                <div class="info-item">
                    <span class="info-label">Trạng thái:</span>
                    <span class="info-value" style="color: #ff9800; font-weight: 600;">
                        ⏳ Chờ xác nhận
                    </span>
                </div>

                <div class="info-item">
                    <span class="info-label">Ngày đặt:</span>
                    <span class="info-value">${escapeHtml(formattedDate)}</span>
                </div>
            </div>

            <!-- Chi tiết đơn hàng -->
            ${orderDetails.length > 0 ? `
            <div class="order-items">
                <h3>🍔 Chi tiết đơn hàng</h3>
                ${itemsHtml}
                <div class="order-total">
                    <span class="total-label">Tổng cộng:</span>
                    <span class="total-amount">${formatPrice(total)}</span>
                </div>
            </div>
            ` : ''}

            <!-- Thông báo tiếp theo -->
            <div class="next-steps">
                ${paymentMethod === 'bank' 
                    ? `
                        <div style="background: #fff; padding: 16px; border-radius: 8px; border-left: 4px solid #1976d2; margin-bottom: 16px;">
                            <p style="margin: 0 0 8px 0; color: #1976d2; font-weight: 700; font-size: 16px;">🏦 Thanh toán qua ngân hàng (QR Code)</p>
                            <p style="margin: 0; color: #333; font-size: 14px; line-height: 1.6;">
                                Bạn đã chọn phương thức thanh toán qua ngân hàng. Vui lòng chuyển khoản đúng số tiền theo thông tin đã cung cấp. 
                                Chúng tôi sẽ liên hệ xác nhận đơn hàng sau khi nhận được thông báo chuyển khoản thành công.
                            </p>
                        </div>
                        <p><strong>📞 Chúng tôi sẽ liên hệ với bạn trong vòng 5-10 phút để xác nhận đơn hàng.</strong></p>
                    `
                    : `
                        <div style="background: #fff; padding: 16px; border-radius: 8px; border-left: 4px solid #4caf50; margin-bottom: 16px;">
                            <p style="margin: 0 0 8px 0; color: #388e3c; font-weight: 700; font-size: 16px;">💵 Thanh toán khi nhận hàng (COD)</p>
                            <p style="margin: 0; color: #333; font-size: 14px; line-height: 1.6;">
                                Bạn đã chọn phương thức thanh toán khi nhận hàng. Vui lòng chuẩn bị đúng số tiền theo tổng giá trị đơn hàng. 
                                Nhân viên giao hàng sẽ thu tiền khi giao sản phẩm đến bạn.
                            </p>
                        </div>
                        <p><strong>📞 Chúng tôi sẽ liên hệ với bạn trong vòng 5-10 phút để xác nhận đơn hàng.</strong></p>
                    `}
                <p>Bạn có thể theo dõi trạng thái đơn hàng tại trang "Đơn hàng của tôi".</p>
            </div>

            <!-- Nút hành động -->
            <div class="success-actions">
                <a href="/Menu" class="btn-action btn-menu">🍔 Quay lại menu</a>
                <a href="/Orders" class="btn-action btn-orders">📋 Đến đơn hàng của tôi</a>
            </div>
        `;
    }
    
    // ===============================
    // Build HTML cho chi tiết đơn hàng
    // ===============================
    function buildOrderItemsHTML() {
        if (!orderDetails || orderDetails.length === 0) {
            return '<p style="color: #666; text-align: center; padding: 20px;">Không có chi tiết đơn hàng.</p>';
        }
        
        return orderDetails.map((item, index) => {
            try {
                const productDetail = item.productDetail || item.ProductDetail;
                const product = productDetail?.product || productDetail?.Product;
                const productName = product?.ProductName || product?.productName || 
                                   product?.Name || product?.name || 'Sản phẩm không tên';
                
                const productSize = productDetail?.productSize || productDetail?.ProductSize;
                const sizeName = productSize?.SizeName || productSize?.sizeName || 
                                productSize?.Name || productSize?.name || 'Không xác định';
                
                const price = parseFloat(productDetail?.Price || productDetail?.price || 0);
                const quantity = item.Quantity || item.quantity || 0;
                const subtotal = parseFloat(item.TotalMoney || item.totalMoney || price * quantity);
                
                // Get image
                const productImages = product?.productImages || product?.ProductImages || [];
                let imageUrl = '';
                if (productImages && productImages.length > 0) {
                    const firstImage = productImages[0];
                    imageUrl = firstImage?.ImageUrl || firstImage?.imageUrl || '';
                }
                if (!imageUrl) {
                    const productId = product?.ID || product?.id || index;
                    imageUrl = `https://picsum.photos/seed/${productId}/150/150`;
                }
                
                return `
                    <div class="order-item">
                        <img src="${escapeHtml(imageUrl)}" alt="${escapeHtml(productName)}" 
                             onerror="this.src='https://picsum.photos/seed/${index}/150/150';" />
                        <div class="item-info">
                            <strong>${escapeHtml(productName)}</strong>
                            <div class="item-meta">
                                <span>Size: ${escapeHtml(sizeName)}</span>
                                <span>× ${quantity}</span>
                            </div>
                        </div>
                        <div class="item-price">${formatPrice(subtotal)}</div>
                    </div>
                `;
            } catch (error) {
                console.error(`Error building item ${index}:`, error);
                return '';
            }
        }).filter(html => html !== '').join('');
    }
    
    // ===============================
    // Show error
    // ===============================
    function showError(message) {
        const container = document.getElementById('successContent');
        if (container) {
            container.innerHTML = `
                <div style="text-align: center; padding: 40px;">
                    <p style="color: red; font-size: 18px; margin-bottom: 20px;">⚠️ ${escapeHtml(message)}</p>
                    <a href="/Orders" class="btn-action btn-orders">Đến đơn hàng của tôi</a>
                </div>
            `;
        }
    }
    
    // ===============================
    // Utility functions
    // ===============================
    function formatPrice(amount) {
        return parseFloat(amount || 0).toLocaleString('vi-VN') + 'đ';
    }
    
    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // ===============================
    // Initialize
    // ===============================
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
})();

