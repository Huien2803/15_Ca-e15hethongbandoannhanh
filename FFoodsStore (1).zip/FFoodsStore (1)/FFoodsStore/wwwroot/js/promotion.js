// =============== Promotion CRUD JS ===============

const api = '/api/promotionapi';

// Kiểm tra user có phải admin không
function isAdminUser() {
    try {
        // Kiểm tra từ window.isAdmin (nếu có)
        if (window.isAdmin && typeof window.isAdmin === 'function') {
            const result = window.isAdmin();
            if (result === true || result === false) {
                return result;
            }
        }
        
        // Fallback: check localStorage trực tiếp
        const userStr = localStorage.getItem('user');
        if (!userStr) {
            console.log('[PROMO] No user in localStorage');
            return false;
        }
        
        const user = JSON.parse(userStr);
        if (!user) {
            console.log('[PROMO] User is null');
            return false;
        }
        
        // Kiểm tra role === 1 (admin)
        const isAdmin = user.role === 1;
        console.log('[PROMO] User role check:', { role: user.role, isAdmin: isAdmin, user: user });
        return isAdmin;
    } catch (error) {
        console.error('[PROMO] Error checking admin:', error);
        return false;
    }
}

// 🟢 Load danh sách khuyến mãi
async function loadPromos() {
    const box = document.getElementById('promoList');
    box.innerHTML = "<p>Đang tải dữ liệu...</p>";

    try {
        const res = await fetch(api);
        if (!res.ok) throw new Error("Không thể tải danh sách khuyến mãi!");
        const promos = await res.json();

        if (!promos || promos.length === 0) {
            box.innerHTML = "<p>Chưa có khuyến mãi nào!</p>";
            return;
        }

        // Kiểm tra admin mỗi lần load
        const isAdmin = isAdminUser();
        console.log('[PROMO] Loading promos, isAdmin:', isAdmin);

        box.innerHTML = promos.map(p => {
            // Chỉ hiển thị nút Edit/Delete nếu là admin
            const adminButtons = isAdmin ? `
              <div style="display: flex; gap: 4px;">
                <button class="btn-small bg-warning" onclick="editPromo(${p.id})" title="Sửa" style="padding: 4px 8px;">✏️</button>
                <button class="btn-small bg-danger" onclick="deletePromo(${p.id})" title="Xóa" style="padding: 4px 8px;">🗑</button>
              </div>
            ` : '';
            
            return `
            <div class="promo-card">
              <img src="${p.bannerUrl || '/images/default.jpg'}" alt="${p.name}" />
              <div class="promo-info">
                <h3>${p.name}</h3>
                <p>${p.description || ''}</p>
                <div class="promo-bottom">
                  <span>${p.type == 1 ? p.value + '%' : p.value + 'đ'}</span>
                  ${adminButtons}
                </div>
              </div>
            </div>
            `;
        }).join('');

    } catch (err) {
        box.innerHTML = "<p class='text-danger'>Không thể tải dữ liệu!</p>";
        console.error(err);
    }
}

// 🟢 Lưu (thêm hoặc cập nhật)
async function savePromo(e) {
    e.preventDefault();
    
    // Kiểm tra quyền admin
    if (!isAdminUser()) {
        alert('❌ Bạn không có quyền thêm/sửa khuyến mãi! Chỉ admin mới có quyền này.');
        closeForm();
        return;
    }

    const promoId = document.getElementById('promoId');
    const promoName = document.getElementById('promoName');
    const promoDesc = document.getElementById('promoDesc');
    const promoValue = document.getElementById('promoValue');
    const promoBanner = document.getElementById('promoBanner');
    const promoStart = document.getElementById('promoStart');
    const promoEnd = document.getElementById('promoEnd');

    const id = promoId.value;
    
    // Xử lý upload banner nếu có file mới
    let bannerUrl = '';
    if (promoBanner && promoBanner.files && promoBanner.files.length > 0) {
        const file = promoBanner.files[0];
        
        // Validate file
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
        if (!allowedTypes.includes(file.type)) {
            alert('❌ Chỉ chấp nhận file ảnh (jpg, jpeg, png, gif, webp)!');
            return;
        }

        if (file.size > 10 * 1024 * 1024) {
            alert('❌ File ảnh không được vượt quá 10MB!');
            return;
        }

        // Upload banner
        const formData = new FormData();
        formData.append('file', file);
        
        try {
            const uploadRes = await fetch('/api/promotionapi/upload-banner', {
                method: 'POST',
                body: formData
            });

            if (!uploadRes.ok) {
                const errorText = await uploadRes.text();
                alert('❌ Không thể tải ảnh lên: ' + errorText);
                return;
            }

            const uploadResult = await uploadRes.json();
            bannerUrl = uploadResult.bannerUrl || '';
        } catch (error) {
            console.error('Upload error:', error);
            alert('❌ Lỗi khi tải ảnh lên!');
            return;
        }
    } else if (id && promoBanner && promoBanner.dataset.currentBannerUrl) {
        // Nếu đang sửa và không có file mới, giữ nguyên banner cũ
        bannerUrl = promoBanner.dataset.currentBannerUrl;
    }

    const promo = {
        id: id ? parseInt(id) : 0,
        name: promoName.value.trim(),
        description: promoDesc.value.trim(),
        value: parseFloat(promoValue.value || 0),
        bannerUrl: bannerUrl,
        startDate: promoStart.value || new Date().toISOString(),
        endDate: promoEnd.value || new Date(Date.now() + 7 * 86400000).toISOString(),
        type: 1,
        isActive: true
    };

    const method = id ? 'PUT' : 'POST';
    const url = id ? `${api}/${id}` : api;

    const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(promo)
    });

    if (!res.ok) {
        const errorText = await res.text();
        if (res.status === 401 || res.status === 403) {
            alert("❌ Bạn không có quyền thực hiện thao tác này! Chỉ admin mới có quyền.");
        } else {
            alert("❌ Lưu thất bại: " + errorText);
        }
        return;
    }

    await loadPromos();
    closeForm();
}

// 🟡 Sửa
async function editPromo(id) {
    // Kiểm tra quyền admin
    if (!isAdminUser()) {
        alert('❌ Bạn không có quyền sửa khuyến mãi! Chỉ admin mới có quyền này.');
        return;
    }

    const res = await fetch(api);
    const data = await res.json();
    const p = data.find(x => x.id === id);
    if (!p) return;

    const promoId = document.getElementById('promoId');
    const promoName = document.getElementById('promoName');
    const promoDesc = document.getElementById('promoDesc');
    const promoValue = document.getElementById('promoValue');
    const promoBanner = document.getElementById('promoBanner');
    const promoStart = document.getElementById('promoStart');
    const promoEnd = document.getElementById('promoEnd');
    const formTitle = document.getElementById('formTitle');
    
    // Lưu bannerUrl hiện tại để giữ lại nếu không upload file mới
    if (promoBanner) {
        promoBanner.dataset.currentBannerUrl = p.bannerUrl || '';
    }

    promoId.value = p.id;
    promoName.value = p.name;
    promoDesc.value = p.description || '';
    promoValue.value = p.value;
    // Reset file input (không hiển thị URL cũ)
    if (promoBanner) {
        promoBanner.value = '';
        // Hiển thị ảnh hiện tại nếu có
        const bannerPreview = document.getElementById('bannerPreview');
        const bannerPreviewImg = document.getElementById('bannerPreviewImg');
        const bannerFileName = document.getElementById('bannerFileName');
        
        if (p.bannerUrl) {
            if (bannerPreviewImg) {
                bannerPreviewImg.src = p.bannerUrl;
            }
            if (bannerPreview) {
                bannerPreview.style.display = 'block';
            }
            if (bannerFileName) {
                bannerFileName.textContent = '📷 Ảnh hiện tại (chọn file mới để thay đổi)';
            }
        } else {
            if (bannerPreview) {
                bannerPreview.style.display = 'none';
            }
            if (bannerFileName) {
                bannerFileName.textContent = '📷 Chọn ảnh banner (tùy chọn)';
            }
        }
    }
    promoStart.value = p.startDate ? p.startDate.split('T')[0] : '';
    promoEnd.value = p.endDate ? p.endDate.split('T')[0] : '';
    formTitle.innerText = 'Cập nhật khuyến mãi';
    openForm();
}

// 🔴 Xóa
async function deletePromo(id) {
    // Kiểm tra quyền admin
    if (!isAdminUser()) {
        alert('❌ Bạn không có quyền xóa khuyến mãi! Chỉ admin mới có quyền này.');
        return;
    }

    if (!confirm('Bạn có chắc muốn xóa khuyến mãi này?')) return;
    
    const res = await fetch(`${api}/${id}`, { method: 'DELETE' });
    
    if (!res.ok) {
        if (res.status === 401 || res.status === 403) {
            alert('❌ Bạn không có quyền xóa khuyến mãi! Chỉ admin mới có quyền.');
        } else {
            alert('❌ Xóa thất bại! Vui lòng thử lại.');
        }
        return;
    }
    
    await loadPromos();
}

// Popup form
function openForm() {
    // Kiểm tra quyền admin trước khi mở form
    const isAdmin = isAdminUser();
    console.log('[PROMO] Opening form, isAdmin:', isAdmin);
    
    if (!isAdmin) {
        alert('❌ Bạn không có quyền thêm khuyến mãi! Chỉ admin mới có quyền này.\n\nVui lòng đăng nhập với tài khoản admin.');
        return;
    }
    
    const promoForm = document.getElementById('promoForm');
    if (promoForm) {
        promoForm.classList.remove('hidden');
        promoForm.style.display = 'flex'; // Ensure it's visible
    }
}
function closeForm() {
    const formPromo = document.getElementById('formPromo');
    const promoId = document.getElementById('promoId');
    const formTitle = document.getElementById('formTitle');
    const promoForm = document.getElementById('promoForm');
    
    if (promoForm) {
        promoForm.classList.add('hidden');
        promoForm.style.display = 'none'; // Ensure it's hidden
    }
    if (formPromo) formPromo.reset();
    if (promoId) promoId.value = '';
    if (formTitle) formTitle.innerText = 'Thêm khuyến mãi';
    
    // Reset banner preview
    const bannerPreview = document.getElementById('bannerPreview');
    const bannerPreviewImg = document.getElementById('bannerPreviewImg');
    const bannerFileName = document.getElementById('bannerFileName');
    if (bannerPreview) bannerPreview.style.display = 'none';
    if (bannerPreviewImg) bannerPreviewImg.src = '';
    if (bannerFileName) bannerFileName.textContent = '📷 Chọn ảnh banner (tùy chọn)';
}

// Khởi tạo
document.addEventListener('DOMContentLoaded', () => {
    // Thêm mới - không thay đổi code gốc
    // Ẩn loading khi trang load xong
    setTimeout(() => {
        if (window.hideRatatouilleLoader) {
            window.hideRatatouilleLoader();
        }
    }, 800);
    
    // Đợi auth.js load xong
    setTimeout(() => {
        const formPromo = document.getElementById('formPromo');
        if (formPromo) {
            formPromo.addEventListener('submit', savePromo);
        }
        
        // Ẩn/hiện nút "Thêm khuyến mãi" dựa vào quyền admin
        updateAdminButtons();
        
        loadPromos();
    }, 200);
});

// Cập nhật trạng thái các nút admin
function updateAdminButtons() {
    const isAdmin = isAdminUser();
    console.log('[PROMO] Updating admin buttons, isAdmin:', isAdmin);
    
    // Nút "Thêm khuyến mãi"
    const addPromoBtn = document.getElementById('addPromoBtn');
    if (addPromoBtn) {
        if (isAdmin) {
            addPromoBtn.style.display = 'inline-block';
        } else {
            addPromoBtn.style.display = 'none';
        }
    }
    
    // Ẩn form nếu không phải admin
    const promoForm = document.getElementById('promoForm');
    if (promoForm && !isAdmin) {
        promoForm.classList.add('hidden');
    }
}
