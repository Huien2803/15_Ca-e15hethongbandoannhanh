// ===============================
// AUTHENTICATION UTILITIES
// ===============================

(function() {
    'use strict';
    
    // ===============================
    // Get current user from localStorage
    // ===============================
    function getCurrentUser() {
        try {
            const userStr = localStorage.getItem('user');
            if (!userStr) return null;
            return JSON.parse(userStr);
        } catch (error) {
            console.error('Error parsing user from localStorage:', error);
            return null;
        }
    }
    
    // ===============================
    // Get current account ID
    // ===============================
    function getCurrentAccountId() {
        const user = getCurrentUser();
        return user ? user.id : null;
    }
    
    // ===============================
    // Check if user is logged in
    // ===============================
    function isLoggedIn() {
        return getCurrentUser() !== null;
    }
    
    // ===============================
    // Check if user is admin
    // ===============================
    function isAdmin() {
        const user = getCurrentUser();
        return user && user.role === 1;
    }
    
    // ===============================
    // Logout
    // ===============================
    function logout() {
        // Clear all auth-related data
        localStorage.removeItem('user');
        localStorage.removeItem('role');
        localStorage.removeItem('accountId');
        
        // Redirect to login page (navigation bar will update on next page load)
        window.location.href = '/AccountView/Login';
    }
    
    // ===============================
    // Show/Hide Admin Panel Button
    // ===============================
    function checkAndShowAdminButton() {
        try {
            const adminBtn = document.getElementById('adminPanelBtn');
            if (!adminBtn) return;
            
            if (isAdmin()) {
                adminBtn.style.display = 'flex';
                adminBtn.style.alignItems = 'center';
                adminBtn.style.justifyContent = 'center';
            } else {
                adminBtn.style.display = 'none';
            }
        } catch (error) {
            console.error('Error in checkAndShowAdminButton:', error);
        }
    }

    // ===============================
    // Update navigation bar based on login status
    // ===============================
    function updateNavigationBar() {
        const userIconBtn = document.getElementById('userIconBtn');
        if (!userIconBtn) return;
        
        const currentUser = getCurrentUser();
        
        // Check và hiển thị admin button
        checkAndShowAdminButton();
        if (currentUser) {
            // User is logged in - create dropdown menu
            const userName = currentUser.fullName || currentUser.email || 'Người dùng';
            
            // Remove old user menu if exists
            const oldMenu = document.getElementById('userMenu');
            if (oldMenu) oldMenu.remove();
            
            // Create user info wrapper
            const userMenu = document.createElement('div');
            userMenu.id = 'userMenu';
            userMenu.className = 'user-menu';
            userMenu.innerHTML = `
                <div class="user-info">
                    <span class="user-name">${escapeHtml(userName)}</span>
                    <span class="user-role">${currentUser.role === 1 ? 'Admin' : 'Khách hàng'}</span>
                </div>
                <div class="user-menu-dropdown">
                    <a href="/Profile" class="menu-item">👤 Hồ sơ của tôi</a>
                    <a href="#" class="menu-item logout-btn">🚪 Đăng xuất</a>
                </div>
            `;
            userIconBtn.parentNode.insertBefore(userMenu, userIconBtn.nextSibling);
            
            // Add click handler for logout
            const logoutBtn = userMenu.querySelector('.logout-btn');
            if (logoutBtn) {
                logoutBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (confirm('Bạn có muốn đăng xuất không?')) {
                        logout();
                    }
                });
            }
            
            // Toggle dropdown on click
            userMenu.addEventListener('click', function(e) {
                if (e.target.closest('.user-info')) {
                    const dropdown = userMenu.querySelector('.user-menu-dropdown');
                    if (dropdown) {
                        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
                    }
                }
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function closeDropdown(e) {
                if (!userMenu.contains(e.target) && !userIconBtn.contains(e.target)) {
                    const dropdown = userMenu.querySelector('.user-menu-dropdown');
                    if (dropdown) dropdown.style.display = 'none';
                }
            });
            
            // Update button to show user icon or avatar
            userIconBtn.href = '#';
            userIconBtn.title = userName;
            userIconBtn.setAttribute('aria-label', 'Tài khoản');
            userIconBtn.onclick = function(e) {
                e.preventDefault();
                const dropdown = userMenu.querySelector('.user-menu-dropdown');
                if (dropdown) {
                    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
                }
            };
            
            // Update icon to show avatar if available, otherwise show default icon
            const avatarUrl = currentUser.avatarUrl;
            const svg = userIconBtn.querySelector('svg');
            
            // Remove existing avatar image if any
            const existingAvatarImg = userIconBtn.querySelector('img.avatar-icon');
            if (existingAvatarImg) {
                existingAvatarImg.remove();
            }
            
            if (avatarUrl) {
                // Hide default SVG icon
                if (svg) {
                    svg.style.display = 'none';
                }
                
                // Create and show avatar image
                const avatarImg = document.createElement('img');
                avatarImg.src = avatarUrl;
                avatarImg.alt = userName;
                avatarImg.className = 'avatar-icon';
                avatarImg.style.cssText = 'width: 36px; height: 36px; border-radius: 50%; object-fit: cover; border: 2px solid #e31d14;';
                
                // Add error handler - fallback to default icon if avatar fails to load
                avatarImg.onerror = function() {
                    this.remove();
                    if (svg) {
                        svg.style.display = 'block';
                        svg.style.fill = '#e31d14';
                    }
                };
                
                // Insert avatar image (before or replace SVG)
                if (svg && svg.parentNode) {
                    svg.parentNode.insertBefore(avatarImg, svg);
                } else {
                    userIconBtn.appendChild(avatarImg);
                }
            } else {
                // Show default SVG icon
                if (svg) {
                    svg.style.display = 'block';
                    svg.style.fill = '#e31d14'; // Red color to indicate logged in
                }
            }
        } else {
            // User is not logged in - show login link
            userIconBtn.href = '/AccountView/Login';
            userIconBtn.title = 'Đăng nhập';
            userIconBtn.setAttribute('aria-label', 'Đăng nhập');
            userIconBtn.onclick = null;
            
            // Remove user menu if exists
            const userMenu = document.getElementById('userMenu');
            if (userMenu) {
                userMenu.remove();
            }
            
            const svg = userIconBtn.querySelector('svg');
            if (svg) {
                svg.style.fill = ''; // Reset color
            }
        }
    }
    
    // Helper function to escape HTML
    function escapeHtml(text) {
        if (!text) return '';
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, m => map[m]);
    }
    
    // ===============================
    // Register function
    // ===============================
    async function register(event) {
        if (event) event.preventDefault();
        
        const form = document.getElementById('registerForm');
        const email = document.getElementById('email')?.value.trim() || '';
        const fullName = document.getElementById('fullname')?.value.trim() || '';
        const password = document.getElementById('password')?.value.trim() || '';
        const confirm = document.getElementById('confirm')?.value.trim() || '';
        const phone = document.getElementById('phone')?.value.trim() || '';
        const msg = document.getElementById('error-msg');
        const submitBtn = form?.querySelector('button[type="submit"]');
        
        // Hide error message initially
        if (msg) {
            msg.style.display = 'none';
            msg.innerText = '';
        }
        
        // Validation
        if (!email || !fullName || !password || !confirm) {
            if (msg) {
                msg.innerText = 'Vui lòng điền đầy đủ thông tin!';
                msg.style.display = 'block';
            }
            return;
        }
        
        if (password !== confirm) {
            if (msg) {
                msg.innerText = 'Mật khẩu nhập lại không khớp!';
                msg.style.display = 'block';
            }
            return;
        }
        
        if (password.length < 6) {
            if (msg) {
                msg.innerText = 'Mật khẩu phải có ít nhất 6 ký tự!';
                msg.style.display = 'block';
            }
            return;
        }
        
        try {
            // Show Ratatouille loader
            if (window.showRatatouilleLoader) {
                window.showRatatouilleLoader('Đang đăng ký...');
            }
            
            // Show button loading
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.classList.add('loading');
                if (window.showButtonLoading) {
                    window.showButtonLoading(submitBtn, 'Đang đăng ký...');
                } else {
                    const btnText = submitBtn.querySelector('.btn-text');
                    if (btnText) btnText.textContent = 'Đang đăng ký...';
                }
            }
            
            const res = await fetch('/api/account/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    email, 
                    fullName, 
                    phoneNumber: phone, 
                    password 
                })
            });
            
            // Hide Ratatouille loader
            if (window.hideRatatouilleLoader) {
                window.hideRatatouilleLoader();
            }
            
            if (!res.ok) {
                let errorText = '';
                try {
                    const contentType = res.headers.get('content-type');
                    if (contentType && contentType.includes('application/json')) {
                        const errorJson = await res.json();
                        errorText = errorJson.message || errorJson.error || JSON.stringify(errorJson);
                    } else {
                        errorText = await res.text();
                    }
                } catch (e) {
                    console.error('Error reading response:', e);
                    errorText = '';
                }
                
                if (!errorText || errorText.trim() === '') {
                    errorText = `Đăng ký thất bại! (Lỗi ${res.status})`;
                }
                
                console.error('Register failed:', res.status, errorText);
                
                if (msg) {
                    msg.innerText = errorText;
                    msg.style.display = 'block';
                    msg.style.color = '#e31d14';
                    setTimeout(() => {
                        msg.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    }, 100);
                }
                
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.classList.remove('loading');
                    if (window.hideButtonLoading) {
                        window.hideButtonLoading(submitBtn, 'Đăng ký');
                    } else {
                        const btnText = submitBtn.querySelector('.btn-text');
                        if (btnText) btnText.textContent = 'Đăng ký';
                    }
                }
                return;
            }
            
            // Success - Parse response (can be text or JSON)
            let successMsg = 'Đăng ký thành công!';
            let responseData = null;
            
            try {
                const contentType = res.headers.get('content-type');
                if (contentType && contentType.includes('application/json')) {
                    responseData = await res.json();
                    successMsg = responseData.message || successMsg;
                    console.log('Register success (JSON):', responseData);
                } else {
                    const textResponse = await res.text();
                    successMsg = textResponse || successMsg;
                    console.log('Register success (text):', successMsg);
                }
            } catch (e) {
                console.error('Error parsing success response:', e);
            }
            
            // Show success message
            if (msg) {
                msg.innerText = successMsg;
                msg.style.display = 'block';
                msg.style.color = '#28a745';
            }
            
            // Success - redirect to login after a short delay
            setTimeout(() => {
                alert(successMsg + '\n\nVui lòng đăng nhập với tài khoản vừa tạo.');
                window.location.href = '/AccountView/Login';
            }, 500);
            
        } catch (error) {
            console.error('Register error:', error);
            // Hide Ratatouille loader on error
            if (window.hideRatatouilleLoader) {
                window.hideRatatouilleLoader();
            }
            if (msg) {
                msg.innerText = 'Có lỗi xảy ra khi đăng ký. Vui lòng thử lại!';
                msg.style.display = 'block';
            }
        } finally {
            // Hide button loading
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.classList.remove('loading');
                if (window.hideButtonLoading) {
                    window.hideButtonLoading(submitBtn, 'Đăng ký');
                } else {
                    const btnText = submitBtn.querySelector('.btn-text');
                    if (btnText) btnText.textContent = 'Đăng ký';
                }
            }
        }
    }
    
    // ===============================
    // Login function
    // ===============================
    async function login(event) {
        if (event) event.preventDefault();
        
        const email = document.getElementById('email')?.value.trim() || '';
        const password = document.getElementById('password')?.value.trim() || '';
        const msg = document.getElementById('error-msg');
        const submitBtn = document.getElementById('loginForm')?.querySelector('button[type="submit"]');
        
        // Hide error message initially
        if (msg) {
            msg.style.display = 'none';
            msg.innerText = '';
        }
        
        // Validation
        if (!email || !password) {
            if (msg) {
                msg.innerText = 'Vui lòng điền đầy đủ thông tin!';
                msg.style.display = 'block';
            }
            return;
        }
        
        try {
            // Show Ratatouille loader
            if (window.showRatatouilleLoader) {
                window.showRatatouilleLoader('Đang đăng nhập...');
            }
            
            // Show button loading
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.classList.add('loading');
                if (window.showButtonLoading) {
                    window.showButtonLoading(submitBtn, 'Đang đăng nhập...');
                } else {
                    const btnText = submitBtn.querySelector('.btn-text');
                    if (btnText) btnText.textContent = 'Đang đăng nhập...';
                }
            }
            
            const response = await fetch('/api/account/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            
            // Hide Ratatouille loader
            if (window.hideRatatouilleLoader) {
                window.hideRatatouilleLoader();
            }
            
            if (!response.ok) {
                let errorText = '';
                
                // Try to read error message from response
                try {
                    const contentType = response.headers.get('content-type');
                    if (contentType && contentType.includes('application/json')) {
                        const errorJson = await response.json();
                        errorText = errorJson.message || errorJson.error || errorJson.toString();
                    } else {
                        errorText = await response.text();
                    }
                } catch (e) {
                    console.error('Error reading response:', e);
                    errorText = '';
                }
                
                // Map status codes to user-friendly messages
                if (response.status === 401) {
                    if (!errorText || errorText.trim() === '') {
                        errorText = 'Email hoặc mật khẩu không đúng!';
                    }
                } else if (response.status === 404) {
                    if (!errorText || errorText.trim() === '') {
                        errorText = 'Tài khoản không tồn tại!';
                    }
                } else {
                    errorText = errorText || `Đăng nhập thất bại! (Lỗi ${response.status})`;
                }
                
                console.error('Login failed:', {
                    status: response.status,
                    statusText: response.statusText,
                    error: errorText,
                    email: email // Log email để debug (không log password)
                });
                
                if (msg) {
                    msg.innerText = errorText;
                    msg.style.display = 'block';
                    // Scroll to error message smoothly
                    setTimeout(() => {
                        msg.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    }, 100);
                }
                
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.classList.remove('loading');
                    if (window.hideButtonLoading) {
                        window.hideButtonLoading(submitBtn, 'Đăng nhập');
                    } else {
                        const btnText = submitBtn.querySelector('.btn-text');
                        if (btnText) btnText.textContent = 'Đăng nhập';
                    }
                }
                return;
            }
            
            const data = await response.json();
            console.log('Login response:', data);
            
            // Lưu thông tin user vào localStorage
            if (data.user) {
                // Hỗ trợ cả camelCase và PascalCase
                const userId = data.user.id || data.user.ID;
                const userRole = data.user.role !== undefined ? data.user.role : data.user.Role;
                const userFullName = data.user.fullName || data.user.FullName;
                const userEmail = data.user.email || data.user.Email;
                const userAvatarUrl = data.user.avatarUrl || data.user.AvatarUrl;
                
                const userData = {
                    id: userId,
                    fullName: userFullName,
                    email: userEmail,
                    role: userRole,
                    avatarUrl: userAvatarUrl
                };
                
                localStorage.setItem('user', JSON.stringify(userData));
                localStorage.setItem('role', userRole ? userRole.toString() : '0');
                localStorage.setItem('accountId', userId ? userId.toString() : '');
                
                console.log('User saved to localStorage:', userData);
                
                // Hiển thị admin button nếu là admin
                if (window.checkAndShowAdminButton) {
                    setTimeout(() => window.checkAndShowAdminButton(), 100);
                }
            }
            
            // Redirect theo backend trả về
            // Navigation bar sẽ được update tự động khi trang mới load
            console.log('Login response data:', data);
            console.log('User role:', data.user?.role);
            
            if (data.redirectUrl) {
                console.log('Redirecting to:', data.redirectUrl);
                // Chờ một chút để localStorage được lưu
                setTimeout(() => {
                    window.location.href = data.redirectUrl;
                }, 100);
            } else {
                // Fallback redirect
                const userRole = data.user?.role || data.user?.Role;
                const redirectUrl = userRole === 1 ? '/Admin/Dashboard' : '/Home/Index';
                console.log('Fallback redirect to:', redirectUrl, 'Role:', userRole);
                setTimeout(() => {
                    window.location.href = redirectUrl;
                }, 100);
            }
            
        } catch (error) {
            console.error('Login error:', error);
            // Hide Ratatouille loader on error
            if (window.hideRatatouilleLoader) {
                window.hideRatatouilleLoader();
            }
            if (msg) {
                msg.innerText = 'Có lỗi xảy ra khi đăng nhập. Vui lòng thử lại!';
                msg.style.display = 'block';
            }
        } finally {
            // Hide button loading
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.classList.remove('loading');
                if (window.hideButtonLoading) {
                    window.hideButtonLoading(submitBtn, 'Đăng nhập');
                } else {
                    const btnText = submitBtn.querySelector('.btn-text');
                    if (btnText) btnText.textContent = 'Đăng nhập';
                }
            }
        }
    }
    
    // ===============================
    // Initialize on page load
    // ===============================
    function init() {
        // Setup register form
        const registerForm = document.getElementById('registerForm');
        if (registerForm) {
            registerForm.addEventListener('submit', register);
        }
        
        // Setup login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', login);
        }
        
        // Update navigation bar (only if not on login/register pages)
        if (!registerForm && !loginForm) {
            updateNavigationBar();
        }
    }
    
    // Auto init when DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    // ===============================
    // Export to window
    // ===============================
    window.getCurrentUser = getCurrentUser;
    window.getCurrentAccountId = getCurrentAccountId;
    window.isLoggedIn = isLoggedIn;
    window.isAdmin = isAdmin;
    window.logout = logout;
    window.login = login;
    window.register = register;
    window.updateNavigationBar = updateNavigationBar;
    window.checkAndShowAdminButton = checkAndShowAdminButton;
    
    // Set accountId to window for backward compatibility
    Object.defineProperty(window, 'accountId', {
        get: function() {
            return getCurrentAccountId() || 1; // Fallback to 1 if not logged in
        },
        configurable: true
    });
    
})();

