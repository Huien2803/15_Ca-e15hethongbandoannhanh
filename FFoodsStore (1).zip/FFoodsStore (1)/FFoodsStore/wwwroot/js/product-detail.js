// ===============================
// PRODUCT DETAIL HANDLERS
// Handles add to cart and buy now buttons directly without modal
// ===============================

(function() {
    'use strict';

    // Get account ID helper
    function getAccountId() {
        if (window.getCurrentAccountId) {
            return window.getCurrentAccountId();
        }
        return null;
    }

    // Show cart notification helper
    function showCartNotification(message, isError = false) {
        if (typeof window.showCartNotification === 'function') {
            window.showCartNotification(message, isError);
        } else {
            // Fallback alert
            if (isError) {
                alert('❌ ' + message);
            } else {
                alert('✅ ' + message);
            }
        }
    }

    // Format VND currency
    function formatVND(amount) {
        return Number(amount).toLocaleString('vi-VN') + '₫';
    }

    // Add to cart directly
    async function addToCartDirect(productDetailId, productId) {
        console.log('✅ addToCartDirect called:', { productDetailId, productId });

        if (!productDetailId || productDetailId <= 0) {
            console.error('Invalid productDetailId:', productDetailId);
            showCartNotification('Lỗi: Không tìm thấy sản phẩm!', true);
            return;
        }

        const accountId = getAccountId();
        if (!accountId) {
            alert('⚠️ Vui lòng đăng nhập để thêm sản phẩm vào giỏ hàng!');
            const returnUrl = encodeURIComponent(window.location.pathname);
            window.location.href = `/AccountView/Login?returnUrl=${returnUrl}`;
            return;
        }

        try {
            // Call API to add to cart
            const response = await fetch('/api/cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    accountId: accountId,
                    productDetailId: productDetailId
                })
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error('API error:', { status: response.status, errorText });
                throw new Error(errorText || `API lỗi: ${response.status} ${response.statusText}`);
            }

            const data = await response.json();
            console.log('✅ Add to cart success:', data);

            // Update cart badge
            if (typeof window.loadCartCount === 'function') {
                await window.loadCartCount();
            }
            if (typeof window.refreshCartBadge === 'function') {
                window.refreshCartBadge();
            }

            // Show success notification
            showCartNotification('✅ Đã thêm vào giỏ hàng!', false);

        } catch (error) {
            console.error('❌ Error in addToCartDirect:', error);
            const errorMsg = error.message || 'Không thể thêm sản phẩm vào giỏ hàng!';
            showCartNotification(errorMsg, true);
        }
    }

    // Buy now - add to cart and redirect to checkout
    async function buyNowDirect(productDetailId, productId) {
        console.log('✅ buyNowDirect called:', { productDetailId, productId });

        if (!productDetailId || productDetailId <= 0) {
            console.error('Invalid productDetailId:', productDetailId);
            showCartNotification('Lỗi: Không tìm thấy sản phẩm!', true);
            return;
        }

        const accountId = getAccountId();
        if (!accountId) {
            alert('⚠️ Vui lòng đăng nhập để mua hàng!');
            const returnUrl = encodeURIComponent(window.location.pathname);
            window.location.href = `/AccountView/Login?returnUrl=${returnUrl}`;
            return;
        }

        try {
            // Call API to add to cart
            const response = await fetch('/api/cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    accountId: accountId,
                    productDetailId: productDetailId
                })
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error('API error:', { status: response.status, errorText });
                throw new Error(errorText || `API lỗi: ${response.status} ${response.statusText}`);
            }

            const data = await response.json();
            console.log('✅ Buy now - Add to cart success:', data);

            // Update cart badge
            if (typeof window.loadCartCount === 'function') {
                await window.loadCartCount();
            }
            if (typeof window.refreshCartBadge === 'function') {
                window.refreshCartBadge();
            }

            // Show success notification briefly
            showCartNotification('✅ Đã thêm vào giỏ hàng!', false);

            // Redirect to checkout after short delay
            setTimeout(() => {
                window.location.href = '/Checkout';
            }, 500);

        } catch (error) {
            console.error('❌ Error in buyNowDirect:', error);
            const errorMsg = error.message || 'Không thể thêm sản phẩm vào giỏ hàng!';
            showCartNotification(errorMsg, true);
        }
    }

    // Setup event delegation for buttons
    function setupProductDetailHandlers() {
        console.log('✅ Setting up product detail handlers');

        // Event delegation for add-to-cart buttons
        document.addEventListener('click', function(e) {
            let target = e.target;
            
            // Find button or parent button
            while (target && target !== document.body) {
                if (target.classList && target.classList.contains('btn-add-cart')) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    const productId = parseInt(target.getAttribute('data-product-id') || '0');
                    const productDetailId = parseInt(target.getAttribute('data-product-detail-id') || '0');
                    
                    console.log('✅ Add to cart clicked:', { productId, productDetailId });
                    
                    if (productDetailId > 0) {
                        addToCartDirect(productDetailId, productId);
                    } else {
                        console.error('Missing productDetailId');
                        showCartNotification('Lỗi: Không tìm thấy chi tiết sản phẩm!', true);
                    }
                    
                    return false;
                }
                
                if (target.classList && target.classList.contains('btn-buy-now')) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    const productId = parseInt(target.getAttribute('data-product-id') || '0');
                    const productDetailId = parseInt(target.getAttribute('data-product-detail-id') || '0');
                    
                    console.log('✅ Buy now clicked:', { productId, productDetailId });
                    
                    if (productDetailId > 0) {
                        buyNowDirect(productDetailId, productId);
                    } else {
                        console.error('Missing productDetailId');
                        showCartNotification('Lỗi: Không tìm thấy chi tiết sản phẩm!', true);
                    }
                    
                    return false;
                }
                
                target = target.parentElement;
            }
        }, true); // Use capture phase for early handling
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setupProductDetailHandlers);
    } else {
        setupProductDetailHandlers();
    }

    // Export functions to window for global access
    window.addToCartDirect = addToCartDirect;
    window.buyNowDirect = buyNowDirect;
    window.setupProductDetailHandlers = setupProductDetailHandlers;

})();

