// ============================================
// GROQ AI CHATBOT - Llama 3.1 70B Versatile
// ============================================

(function() {
    'use strict';

    // Chat history (preserved across messages)
    let messages = [];
    
    // Store product context (loaded once)
    let productContext = null;

    // ============================================
    // Load Products from Database
    // ============================================
    async function loadProductContext() {
        if (productContext) return productContext; // Cache loaded products
        
        try {
            const response = await fetch("/api/menu/items?pageSize=100"); // Get all products
            if (!response.ok) {
                console.warn('Failed to load products for chatbot context');
                return null;
            }
            
            const data = await response.json();
            const products = data.items || [];
            
            if (products.length === 0) {
                return null;
            }
            
            // Build product context string
            let contextText = "=== DANH SÁCH SẢN PHẨM CỦA CỬA HÀNG ===\n\n";
            products.forEach(product => {
                contextText += `- ${product.name} (${product.typeName}): ${product.price?.toLocaleString('vi-VN') || 0}đ\n`;
            });
            contextText += "\nKhi khách hỏi về menu, hãy liệt kê các món ăn từ danh sách trên.";
            
            productContext = contextText;
            console.log(`✅ Loaded ${products.length} products for chatbot context`);
            return contextText;
        } catch (error) {
            console.error('Error loading products:', error);
            return null;
        }
    }

    // ============================================
    // Send message to Groq API
    // ============================================
    async function sendToGroq(message) {
        const apiKey = "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";

        // Load product context if not loaded
        if (!productContext) {
            await loadProductContext();
        }

        // Add user message to history
        messages.push({ role: "user", content: message });

        // Build system prompt with product context
        let systemPrompt = "Bạn là trợ lý AI của cửa hàng thức ăn nhanh FastFood. Trả lời ngắn gọn, thân thiện, hữu ích. Luôn trả lời bằng tiếng Việt.\n\n";
        if (productContext) {
            systemPrompt += productContext + "\n\n";
        }
        systemPrompt += "Khi khách hỏi về menu hoặc món ăn, hãy gợi ý các món từ danh sách trên. Nếu khách hỏi về giá, hãy tham khảo giá trong danh sách.";

        // Try multiple models in order of preference (updated 2024)
        const models = [
            "llama-3.1-8b-instant",     // Fast and reliable
            "llama-3.1-70b-versatile",  // More capable if available
            "mixtral-8x7b-32768"        // Backup model
        ];

        let lastError = null;
        
        for (const model of models) {
            try {
                const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${apiKey}`
                    },
                    body: JSON.stringify({
                        model: model,
                        messages: [
                            { role: "system", content: systemPrompt },
                            ...messages
                        ],
                        temperature: 0.7,
                        max_tokens: 1024
                    })
                });

                if (response.ok) {
                    const data = await response.json();
                    console.log('GROQ API Response:', data);
                    
                    if (!data.choices || !data.choices[0] || !data.choices[0].message) {
                        throw new Error('Invalid response from GROQ API');
                    }
                    
                    const reply = data.choices[0].message.content;

                    // Add assistant reply to history
                    messages.push({ role: "assistant", content: reply });

                    // Keep only last 20 messages (10 exchanges) to avoid token limit
                    if (messages.length > 20) {
                        messages = messages.slice(-20);
                    }

                    console.log('✅ Successfully used model:', model);
                    return reply;
                } else {
                    const errorText = await response.text();
                    console.warn(`Model ${model} failed:`, response.status, errorText);
                    lastError = new Error(`API Error: ${response.status} - ${errorText}`);
                    
                    // If model is deprecated, try next model
                    if (response.status === 400) {
                        const errorData = JSON.parse(errorText);
                        if (errorData.error?.code === 'model_decommissioned') {
                            console.log(`⚠️ Model ${model} is deprecated, trying next model...`);
                            continue; // Try next model
                        }
                    }
                    
                    // For other errors, throw immediately
                    throw lastError;
                }
            } catch (error) {
                lastError = error;
                // If it's a network error or non-deprecated error, stop trying
                if (!error.message?.includes('model_decommissioned') && !error.message?.includes('400')) {
                    throw error;
                }
                // Otherwise continue to next model
                console.log(`⚠️ Trying next model after error with ${model}...`);
            }
        }

        // If all models failed, throw last error
        if (lastError) {
            throw lastError;
        }

        throw new Error('All models failed');
    }

    // ============================================
    // Show Loading Indicator
    // ============================================
    function showLoading() {
        return `
            <div class="typing-indicator">
                <span></span><span></span><span></span>
            </div>
        `;
    }

    // ============================================
    // Typing Effect
    // ============================================
    async function typeText(el, text) {
        el.innerHTML = '';
        for (let i = 0; i < text.length; i++) {
            el.innerHTML += text.charAt(i);
            await new Promise(res => setTimeout(res, 8));
            // Auto-scroll while typing
            scrollToBottom();
        }
    }

    // ============================================
    // Append User Message
    // ============================================
    function appendUserMessage(text) {
        const messagesContainer = document.getElementById("chatMessages");
        if (!messagesContainer) return;

        // Remove welcome message if exists
        const welcomeMsg = messagesContainer.querySelector('.welcome-message');
        if (welcomeMsg) welcomeMsg.remove();

        const time = new Date().toLocaleTimeString('vi-VN', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });

        const messageDiv = document.createElement('div');
        messageDiv.className = 'message user';
        messageDiv.innerHTML = `
            <div class="message-avatar user-avatar">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                </svg>
            </div>
            <div class="message-content">
                <div class="message-text">${escapeHtml(text)}</div>
                <div class="message-time">${time}</div>
            </div>
        `;

        messagesContainer.appendChild(messageDiv);
        scrollToBottom();
    }

    // ============================================
    // Append Bot Message
    // ============================================
    function appendBotMessage(text) {
        const messagesContainer = document.getElementById("chatMessages");
        if (!messagesContainer) return;

        // Remove welcome message if exists
        const welcomeMsg = messagesContainer.querySelector('.welcome-message');
        if (welcomeMsg) welcomeMsg.remove();

        const time = new Date().toLocaleTimeString('vi-VN', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });

        const messageDiv = document.createElement('div');
        messageDiv.className = 'message bot';
        const messageId = 'bot-msg-' + Date.now();
        messageDiv.innerHTML = `
            <div class="message-avatar ai-avatar">
                🤖
            </div>
            <div class="message-content">
                <div class="message-text" id="${messageId}">${text ? escapeHtml(text) : ''}</div>
                <div class="message-time">${time}</div>
            </div>
        `;

        messagesContainer.appendChild(messageDiv);
        scrollToBottom();

        return document.getElementById(messageId);
    }

    // ============================================
    // Append Bot Loading Indicator
    // ============================================
    function appendBotLoading() {
        const messagesContainer = document.getElementById("chatMessages");
        if (!messagesContainer) return null;

        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'message bot typing-message';
        loadingDiv.id = 'botLoading';
        loadingDiv.innerHTML = `
            <div class="message-avatar ai-avatar">
                🤖
            </div>
            <div class="message-content">
                ${showLoading()}
            </div>
        `;

        messagesContainer.appendChild(loadingDiv);
        scrollToBottom();

        return 'botLoading';
    }

    // ============================================
    // Remove Loading Indicator
    // ============================================
    function removeLoading(loadingId) {
        const loadingEl = document.getElementById(loadingId);
        if (loadingEl) {
            loadingEl.remove();
        }
    }

    // ============================================
    // Handle User Send Message
    // ============================================
    async function handleUserSend() {
        const input = document.getElementById("chatInput");
        if (!input) return;

        const text = input.value.trim();
        if (!text) return;

        appendUserMessage(text);
        input.value = "";

        const loadingId = appendBotLoading(); // show typing

        try {
            const reply = await sendToGroq(text);

            removeLoading(loadingId);

            const botMsgEl = appendBotMessage("");
            typeText(botMsgEl, reply);
        } catch (error) {
            console.error('Chatbot error:', error);
            console.error('Error details:', {
                message: error.message,
                stack: error.stack,
                name: error.name
            });
            removeLoading(loadingId);
            
            // Show detailed error message
            let errorMsg = "Xin lỗi, hệ thống đang quá tải. Vui lòng thử lại sau.";
            if (error.message && error.message.includes('401')) {
                errorMsg = "Lỗi xác thực API. Vui lòng kiểm tra API key.";
            } else if (error.message && error.message.includes('429')) {
                errorMsg = "Quá nhiều yêu cầu. Vui lòng đợi vài giây rồi thử lại.";
            }
            
            appendBotMessage(errorMsg);
        }
    }

    // ============================================
    // Auto-scroll to Bottom
    // ============================================
    function scrollToBottom() {
        const messagesContainer = document.getElementById("chatMessages");
        if (messagesContainer) {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    }

    // ============================================
    // Escape HTML
    // ============================================
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // ============================================
    // Initialize Chatbot
    // ============================================
    function initChatbot() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                attachEventListeners();
                // Preload products for faster response
                setTimeout(() => loadProductContext(), 500);
            });
        } else {
            attachEventListeners();
            // Preload products for faster response
            setTimeout(() => loadProductContext(), 500);
        }
    }

    // ============================================
    // Attach Event Listeners
    // ============================================
    function attachEventListeners() {
        // Wait for chat elements to be available
        let attempts = 0;
        const maxAttempts = 30;

        const tryAttach = setInterval(() => {
            attempts++;
            const chatInput = document.getElementById("chatInput");
            const chatSend = document.getElementById("chatSend");
            const suggestionChips = document.querySelectorAll('.suggestion-chip');

            if (chatInput && chatSend) {
                clearInterval(tryAttach);

                // Prevent multiple listeners
                if (chatSend.dataset.listenerAdded === 'true') return;
                chatSend.dataset.listenerAdded = 'true';

                // Send button click
                chatSend.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    handleUserSend();
                    return false;
                }, true);

                // Enter key press
                chatInput.addEventListener('keypress', function(e) {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        e.stopPropagation();
                        e.stopImmediatePropagation();
                        handleUserSend();
                        return false;
                    }
                }, true);

                // Suggestion chips
                suggestionChips.forEach((chip, index) => {
                    if (chip.dataset.listenerAdded === 'true') return;
                    chip.dataset.listenerAdded = 'true';
                    
                    chip.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        e.stopImmediatePropagation();
                        const message = this.getAttribute('data-message');
                        if (message && chatInput) {
                            chatInput.value = message;
                            handleUserSend();
                        }
                        return false;
                    }, true);
                });

                console.log('✅ GROQ Chatbot initialized successfully!');
            } else if (attempts >= maxAttempts) {
                clearInterval(tryAttach);
                console.warn('⚠️ Chatbot: Could not find chat elements after', maxAttempts, 'attempts');
            }
        }, 200);
    }

    // Export functions for global access
    window.Chatbot = {
        sendToGroq: sendToGroq,
        handleUserSend: handleUserSend,
        appendUserMessage: appendUserMessage,
        appendBotMessage: appendBotMessage,
        typeText: typeText,
        showLoading: showLoading
    };

    // Initialize on load
    initChatbot();

})();

