// ============================================
// CHAT BOX AI - JavaScript
// ============================================

(function() {
    'use strict';

    const API_ENDPOINT = '/api/aichat/send'; // Updated to use new Gemini 1.5 Flash endpoint
    let isOpen = false;
    let messageHistory = [];

    // Initialize chat box
    function init() {
        createChatWidget();
        loadMessageHistory();
        attachEventListeners();
    }

    // Create chat widget HTML
    function createChatWidget() {
        const widget = document.createElement('div');
        widget.className = 'chat-widget';
        widget.innerHTML = `
            <div class="chat-button" id="chatToggle" title="Chat với trợ lý AI">
                <svg viewBox="0 0 24 24">
                    <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/>
                </svg>
            </div>
            
            <div class="chat-window" id="chatWindow">
                <div class="chat-header">
                    <div>
                        <h3>
                            <span>🤖</span>
                            Trợ lý AI FastFood
                        </h3>
                        <div class="status">
                            <span class="status-dot"></span>
                            <span>Đang trực tuyến</span>
                        </div>
                    </div>
                    <button class="chat-close" id="chatClose" title="Đóng chat">×</button>
                </div>
                
                <div class="chat-messages" id="chatMessages">
                    <div class="welcome-message">
                        <h4>👋 Xin chào!</h4>
                        <p>Tôi là trợ lý ảo của FastFood</p>
                        <p>Tôi có thể giúp bạn tìm hiểu về menu, đặt hàng, khuyến mãi và nhiều hơn nữa!</p>
                    </div>
                </div>
                
                <div class="quick-suggestions" id="quickSuggestions">
                    <div class="suggestion-chip" data-message="Xin chào">👋 Chào hỏi</div>
                    <div class="suggestion-chip" data-message="Xem menu">🍔 Menu</div>
                    <div class="suggestion-chip" data-message="Khuyến mãi">🎉 Khuyến mãi</div>
                    <div class="suggestion-chip" data-message="Đặt hàng">🛒 Đặt hàng</div>
                </div>
                
                <div class="chat-input-area">
                    <input 
                        type="text" 
                        class="chat-input" 
                        id="chatInput" 
                        placeholder="Nhập tin nhắn của bạn..."
                        maxlength="500"
                    />
                    <button class="chat-send" id="chatSend" title="Gửi tin nhắn">
                        <svg viewBox="0 0 24 24">
                            <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                        </svg>
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(widget);
    }

    // Attach event listeners
    function attachEventListeners() {
        const toggleBtn = document.getElementById('chatToggle');
        const closeBtn = document.getElementById('chatClose');
        const sendBtn = document.getElementById('chatSend');
        const input = document.getElementById('chatInput');
        const suggestions = document.getElementById('quickSuggestions');

        // Toggle chat window
        toggleBtn.addEventListener('click', () => {
            toggleChat();
        });

        closeBtn.addEventListener('click', () => {
            closeChat();
        });

        // Send message on button click
        sendBtn.addEventListener('click', () => {
            sendMessage();
        });

        // Send message on Enter key
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        // Quick suggestions
        suggestions.addEventListener('click', (e) => {
            if (e.target.classList.contains('suggestion-chip')) {
                const message = e.target.getAttribute('data-message');
                input.value = message;
                sendMessage();
            }
        });

        // Auto focus input when chat opens
        document.getElementById('chatWindow').addEventListener('transitionend', () => {
            if (isOpen) {
                input.focus();
            }
        });
    }

    // Toggle chat window
    function toggleChat() {
        const chatWindow = document.getElementById('chatWindow');
        isOpen = !isOpen;
        
        if (isOpen) {
            chatWindow.classList.add('active');
            document.getElementById('chatInput').focus();
        } else {
            chatWindow.classList.remove('active');
        }
    }

    // Close chat window
    function closeChat() {
        isOpen = false;
        document.getElementById('chatWindow').classList.remove('active');
    }

    // Send message
    async function sendMessage() {
        const input = document.getElementById('chatInput');
        const message = input.value.trim();

        if (!message) return;

        // Clear input
        input.value = '';

        // Add user message
        appendUserMessage(message);

        // Show typing indicator with rat GIF
        showTypingIndicator();

        try {
            // Send to new Gemini 1.5 Flash API endpoint
            const response = await fetch(API_ENDPOINT, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    message: message
                })
            });

            hideTypingIndicator();

            if (!response.ok) {
                throw new Error('Không thể gửi tin nhắn');
            }

            const data = await response.json();
            const reply = data.reply || 'Xin lỗi, tôi không thể trả lời câu hỏi này.';
            
            // Add bot message with typing effect
            appendBotMessage(reply, true);

            // Save to history
            saveMessageToHistory(message, reply);
        } catch (error) {
            console.error('Chat error:', error);
            hideTypingIndicator();
            appendBotMessage('Xin lỗi, đã xảy ra lỗi. Vui lòng thử lại sau! 😔', false);
        }
    }

    // Add message to chat
    function addMessage(type, content) {
        const messagesContainer = document.getElementById('chatMessages');
        
        // Remove welcome message if exists
        const welcomeMsg = messagesContainer.querySelector('.welcome-message');
        if (welcomeMsg) {
            welcomeMsg.remove();
        }

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;

        const time = new Date().toLocaleTimeString('vi-VN', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });

        // Use SVG avatars if AIChat is available, otherwise use emoji
        const avatarHtml = type === 'user' 
            ? `<div class="message-avatar user-avatar">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                </svg>
               </div>`
            : `<div class="message-avatar ai-avatar">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z"/>
                </svg>
               </div>`;

        messageDiv.innerHTML = `
            ${avatarHtml}
            <div class="message-content">
                <div class="message-text">${formatMessage(content)}</div>
                <div class="message-time">${time}</div>
            </div>
        `;

        messagesContainer.appendChild(messageDiv);

        // Scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // Format message (convert newlines, links)
    function formatMessage(text) {
        // Convert newlines to <br>
        text = text.replace(/\n/g, '<br>');
        
        // Already contains HTML (from AI response with links)
        return text;
    }

    // Show typing indicator with rat GIF
    function showTypingIndicator() {
        const messagesContainer = document.getElementById('chatMessages');
        if (!messagesContainer) return;
        
        // Remove existing typing indicator
        const existing = document.getElementById('aiTyping');
        if (existing) existing.remove();
        
        const ratGifPath = '/images/thanksgiving rat GIF by Disney Pixar.gif';
        const typingDiv = document.createElement('div');
        typingDiv.className = 'ai-typing';
        typingDiv.id = 'aiTyping';
        typingDiv.innerHTML = `
            <img src="${ratGifPath}" alt="Loading" style="width: 40px; height: 40px; object-fit: contain;" />
            <span>Đang trả lời...</span>
        `;
        messagesContainer.appendChild(typingDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // Hide typing indicator
    function hideTypingIndicator() {
        const typingIndicator = document.getElementById('aiTyping');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }
    
    // Simple typing effect function (as requested)
    function typeText(element, text, speed = 20) {
        element.innerHTML = '';
        let i = 0;
        let timer = setInterval(() => {
            if (i < text.length) {
                element.innerHTML += text.charAt(i);
                i++;
                // Auto scroll while typing
                const messagesContainer = document.getElementById('chatMessages');
                if (messagesContainer) {
                    messagesContainer.scrollTop = messagesContainer.scrollHeight;
                }
            } else {
                clearInterval(timer);
            }
        }, speed);
    }
    
    // Append user message (alias for addMessage with user type)
    function appendUserMessage(text) {
        addMessage('user', text);
    }
    
    // Append bot message with typing effect
    function appendBotMessage(text, useTyping = true) {
        if (useTyping) {
            // Use typing effect for bot messages
            addBotMessageWithTyping(text);
        } else {
            addMessage('bot', text);
        }
    }
    
    // Add bot message with typing effect
    function addBotMessageWithTyping(text) {
        const messagesContainer = document.getElementById('chatMessages');
        if (!messagesContainer) return;
        
        // Remove welcome message if exists
        const welcomeMsg = messagesContainer.querySelector('.welcome-message');
        if (welcomeMsg) welcomeMsg.remove();
        
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message bot';
        
        const time = new Date().toLocaleTimeString('vi-VN', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        const avatarHtml = `<div class="message-avatar ai-avatar">
            <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z"/>
            </svg>
        </div>`;
        
        const msgId = 'msg-' + Date.now();
        messageDiv.innerHTML = `
            ${avatarHtml}
            <div class="message-content">
                <div class="message-text" id="${msgId}"></div>
                <div class="message-time">${time}</div>
            </div>
        `;
        
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Apply typing effect
        const messageText = document.getElementById(msgId);
        if (messageText) {
            // Convert HTML to plain text for typing effect
            const plainText = text.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
            typeText(messageText, plainText, 20);
            
            // After typing completes, format as markdown/HTML
            setTimeout(() => {
                if (messageText) {
                    messageText.innerHTML = formatMessage(text);
                }
            }, plainText.length * 20 + 100);
        }
    }

    // Get user ID from localStorage
    function getUserId() {
        try {
            const user = JSON.parse(localStorage.getItem('user') || '{}');
            return user.id || null;
        } catch {
            return null;
        }
    }

    // Save message to history
    function saveMessageToHistory(userMessage, botMessage) {
        messageHistory.push({
            user: userMessage,
            bot: botMessage,
            timestamp: new Date().toISOString()
        });

        // Keep only last 50 messages
        if (messageHistory.length > 50) {
            messageHistory = messageHistory.slice(-50);
        }

        // Save to localStorage
        try {
            localStorage.setItem('chatHistory', JSON.stringify(messageHistory));
        } catch (e) {
            console.error('Cannot save chat history:', e);
        }
    }

    // Load message history
    function loadMessageHistory() {
        try {
            const saved = localStorage.getItem('chatHistory');
            if (saved) {
                messageHistory = JSON.parse(saved);
            }
        } catch (e) {
            console.error('Cannot load chat history:', e);
        }
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Export for global access
    window.toggleChat = toggleChat;
})();


