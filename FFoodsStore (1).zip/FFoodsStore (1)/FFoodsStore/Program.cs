using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using Microsoft.OpenApi.Models;
using FFoodsStore.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        // Cấu hình JSON để hỗ trợ camelCase (từ frontend) map sang PascalCase (C# model)
        options.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
    });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "FFoodsStore API",
        Version = "v1",
        Description = "API cho hệ thống đặt món ăn nhanh FastFood Store"
    });
});

builder.Services.AddCors(o =>
    o.AddPolicy("AllowAll", p => p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

builder.Services.AddHttpClient();

builder.Services.AddDbContext<StoreDbContext>(opts =>
    opts.UseSqlServer(builder.Configuration.GetConnectionString("FFoodsStoreConnection")));

var app = builder.Build();

// Seed admin account if not exists
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        var context = services.GetRequiredService<StoreDbContext>();
        
        // Check if admin account exists (Role = 1)
        var adminExists = await context.Accounts
            .AnyAsync(a => a.Email == "admin@fastfood.vn" && a.Role == 1 && !a.IsDelete);
        
        if (!adminExists)
        {
            // Create admin account
            var admin = new FFoodsStore.Models.Account
            {
                Email = "admin@fastfood.vn",
                Password = "123456", // Plain text password - consider hashing in production
                Role = 1, // Admin
                FullName = "Administrator",
                IsActive = 1, // Active
                CreatedDate = DateTime.Now,
                CreatedBy = "System",
                IsDelete = false
            };
            
            context.Accounts.Add(admin);
            await context.SaveChangesAsync();
            Console.WriteLine("✅ Admin account seeded successfully: admin@fastfood.vn / 123456");
        }
        else
        {
            Console.WriteLine("ℹ️ Admin account already exists.");
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"⚠️ Error seeding admin account: {ex.Message}");
    }
}

app.UseStaticFiles();
app.UseRouting();
app.UseCors("AllowAll");

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "FFoodsStore API v1");
        c.RoutePrefix = "swagger";
    });
}

app.MapControllers();
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
