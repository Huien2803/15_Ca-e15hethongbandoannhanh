using FastFood.Models;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Data
{
    public static class DbSeeder
    {
        public static async Task SeedAsync(StoreDbContext db)
        {
            await db.Database.MigrateAsync();

            if (!await db.ProductSizes.AnyAsync())
            {
                db.ProductSizes.AddRange(
                    new ProductSize { SizeName = "S" },
                    new ProductSize { SizeName = "M" },
                    new ProductSize { SizeName = "L" }
                );
            }

            if (!await db.Products.AnyAsync())
            {
                var burger = new Product { ProductName = "Burger Bò", ProductTypeId = 1, Description = "Burger bò phô mai" };
                db.Products.Add(burger);
                await db.SaveChangesAsync();

                db.ProductImages.Add(new ProductImage { ProductId = burger.Id, ImageUrl = "burger1.jpg" });

                var sizes = await db.ProductSizes.ToListAsync();
                db.ProductDetails.AddRange(
                    new ProductDetail { ProductId = burger.Id, ProductSizeId = sizes[0].Id, Price = 45000 },
                    new ProductDetail { ProductId = burger.Id, ProductSizeId = sizes[1].Id, Price = 55000 },
                    new ProductDetail { ProductId = burger.Id, ProductSizeId = sizes[2].Id, Price = 65000 }
                );

                db.Toppings.AddRange(
                    new Topping { ToppingName = "Phô mai" },
                    new Topping { ToppingName = "Trứng" }
                );
                await db.SaveChangesAsync();

                var cheese = await db.Toppings.FirstAsync(t => t.ToppingName == "Phô mai");
                var egg = await db.Toppings.FirstAsync(t => t.ToppingName == "Trứng");
                db.ProductToppings.AddRange(
                    new ProductTopping { ProductId = burger.Id, ToppingId = cheese.Id },
                    new ProductTopping { ProductId = burger.Id, ToppingId = egg.Id }
                );
            }

            await db.SaveChangesAsync();
        }
    }
}
