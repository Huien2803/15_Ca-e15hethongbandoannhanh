using FastFood.Models;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Data
{
    public class StoreDbContext : DbContext
    {
        public StoreDbContext(DbContextOptions<StoreDbContext> options) : base(options) { }

        // Product domain
        public DbSet<Product> Products => Set<Product>();
        public DbSet<ProductImage> ProductImages => Set<ProductImage>();
        public DbSet<ProductDetail> ProductDetails => Set<ProductDetail>();
        public DbSet<ProductSize> ProductSizes => Set<ProductSize>();
        public DbSet<Topping> Toppings => Set<Topping>();
        public DbSet<ProductTopping> ProductToppings => Set<ProductTopping>();

        // Order domain (THÊM)
        public DbSet<Order> Orders => Set<Order>();
        public DbSet<OrderItem> OrderItems => Set<OrderItem>();

        protected override void OnModelCreating(ModelBuilder mb)
        {
            // ===== Product =====
            mb.Entity<Product>().ToTable("Product");
            mb.Entity<ProductImage>().ToTable("ProductImage");
            mb.Entity<ProductDetail>().ToTable("ProductDetails");
            mb.Entity<ProductSize>().ToTable("ProductSize");
            mb.Entity<Topping>().ToTable("Topping");
            mb.Entity<ProductTopping>().ToTable("ProductTopping");

            mb.Entity<ProductImage>()
              .HasOne(x => x.Product).WithMany(p => p.Images).HasForeignKey(x => x.ProductId);

            mb.Entity<ProductDetail>()
              .HasOne(x => x.Product).WithMany(p => p.Details).HasForeignKey(x => x.ProductId);

            mb.Entity<ProductDetail>()
              .HasOne(x => x.ProductSize).WithMany(s => s.ProductDetails).HasForeignKey(x => x.ProductSizeId);

            mb.Entity<ProductTopping>()
              .HasOne(x => x.Product).WithMany(p => p.ProductToppings).HasForeignKey(x => x.ProductId);

            mb.Entity<ProductTopping>()
              .HasOne(x => x.Topping).WithMany(t => t.ProductToppings).HasForeignKey(x => x.ToppingId);

            // FIX cảnh báo decimal
            mb.Entity<ProductDetail>().Property(p => p.Price).HasPrecision(18, 2);

            // ===== Orders =====
            mb.Entity<Order>().ToTable("Orders");
            mb.Entity<OrderItem>().ToTable("OrderItem");

            mb.Entity<Order>().Property(o => o.OrderCode).HasMaxLength(20).IsRequired();
            mb.Entity<Order>().Property(o => o.CustomerName).HasMaxLength(200).IsRequired();
            mb.Entity<Order>().Property(o => o.Phone).HasMaxLength(20).IsRequired();
            mb.Entity<Order>().Property(o => o.Address).HasMaxLength(500);
            mb.Entity<Order>().Property(o => o.Total).HasPrecision(18, 2);
            mb.Entity<Order>().Property(o => o.CreatedAt).HasDefaultValueSql("GETDATE()");

            mb.Entity<OrderItem>()
              .HasOne(i => i.Order).WithMany(o => o.Items)
              .HasForeignKey(i => i.OrderId)
              .OnDelete(DeleteBehavior.Cascade);

            mb.Entity<OrderItem>().Property(i => i.ProductName).HasMaxLength(200).IsRequired();
            mb.Entity<OrderItem>().Property(i => i.SizeName).HasMaxLength(20);
            mb.Entity<OrderItem>().Property(i => i.UnitPrice).HasPrecision(18, 2);
            mb.Entity<OrderItem>().Property(i => i.Subtotal).HasPrecision(18, 2);
        }
    }
}
