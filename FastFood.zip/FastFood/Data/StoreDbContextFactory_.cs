using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace FastFood.Data
{
    public class StoreDbContextFactory : IDesignTimeDbContextFactory<StoreDbContext>
    {
        public StoreDbContext CreateDbContext(string[] args)
        {
            var options = new DbContextOptionsBuilder<StoreDbContext>()
                .UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=FastFoodDb;Integrated Security=True;MultipleActiveResultSets=True;TrustServerCertificate=True")

                .Options;

            return new StoreDbContext(options);
        }
    }
}
