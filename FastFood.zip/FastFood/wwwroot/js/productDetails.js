var ProductDetailsId = 0;

$(function () {
  // tự chọn size đầu tiên khi mở trang
  var $first = $("#lst-product-size a").first();
  if ($first.length) $first.trigger("click");
});

function ChangeSize(event) {
  event.preventDefault();
  const $el = $(event.currentTarget);

  const priceVal = Number($el.attr("price") || "0");
  ProductDetailsId = parseInt($el.attr("ProductDetailsId") || "0", 10);

  // highlight size đang chọn
  $("#lst-product-size a").removeClass("active");
  $el.addClass("active");

  // cập nhật giá hiển thị
  $("#Price").text(priceVal.toLocaleString("vi-VN") + " VNĐ");
}

function AddCart(event) {
  if (!ProductDetailsId) {
    alert("Vui lòng chọn size trước khi thêm giỏ.");
    return;
  }

  const qty = Math.max(1, parseInt($("#qty").val() || "1", 10));
  const toppingIds = $(".topping:checked")
    .map(function () { return parseInt(this.value, 10); })
    .get();

  // (tuỳ chọn) khóa nút trong lúc gửi
  const $btn = $(event?.currentTarget);
  if ($btn && $btn.prop) $btn.prop("disabled", true);

  $.ajax({
    url: "/Cart/Add",
    type: "POST",
    data: {
      productDetailsId: ProductDetailsId,
      qty: qty,
      toppingIds: toppingIds
    },
    success: function (res) {
      if (res && res.ok) {
        // chuyển sang trang giỏ
        window.location.href = "/Cart";
      } else {
        alert("Không thêm được giỏ. Vui lòng thử lại.");
      }
    },
    error: function (xhr) {
      alert("Lỗi khi thêm vào giỏ: " + (xhr.responseText || xhr.status));
    },
    complete: function () {
      if ($btn && $btn.prop) $btn.prop("disabled", false);
    }
  });
}
