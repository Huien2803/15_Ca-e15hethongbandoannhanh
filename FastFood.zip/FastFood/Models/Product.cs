using System.Collections.Generic;

namespace FastFood.Models
{
    public class Product
    {
        public int Id { get; set; }
        public int ProductTypeId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string? Description { get; set; }

        public ICollection<ProductImage> Images { get; set; } = new List<ProductImage>();
        public ICollection<ProductDetail> Details { get; set; } = new List<ProductDetail>();
        public ICollection<ProductTopping> ProductToppings { get; set; } = new List<ProductTopping>();
    }

    public class ProductImage
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public string ImageUrl { get; set; } = string.Empty; // chỉ tên file (vd: burger1.jpg)
        public Product Product { get; set; } = null!;
    }

    public class ProductSize
    {
        public int Id { get; set; }
        public string SizeName { get; set; } = string.Empty; // S, M, L...
        public ICollection<ProductDetail> ProductDetails { get; set; } = new List<ProductDetail>();
    }

    public class ProductDetail
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public int ProductSizeId { get; set; }
        public decimal Price { get; set; }

        public Product Product { get; set; } = null!;
        public ProductSize ProductSize { get; set; } = null!;
    }

    public class Topping
    {
        public int Id { get; set; }
        public string ToppingName { get; set; } = string.Empty;
        public ICollection<ProductTopping> ProductToppings { get; set; } = new List<ProductTopping>();
    }

    public class ProductTopping
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public int ToppingId { get; set; }

        public Product Product { get; set; } = null!;
        public Topping Topping { get; set; } = null!;
    }
}
