using FastFood.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Controllers
{
    public class ShopController : Controller
    {
        private readonly StoreDbContext _db;
        private readonly string _productImgBase;

        public ShopController(StoreDbContext db, IConfiguration cfg)
        {
            _db = db;
            var baseUrl = cfg.GetSection("App")["BaseUrl"] ?? "https://localhost:7116/";
            _productImgBase = $"{baseUrl}Images/Product/";
        }

        public async Task<IActionResult> Index()
        {
            var list = await _db.Products
                                .Include(p => p.Images)
                                .OrderBy(p => p.Id)
                                .Take(30)
                                .ToListAsync();

            foreach (var p in list)
                foreach (var img in p.Images)
                    img.ImageUrl = _productImgBase + img.ImageUrl;

            return View(list);
        }

        public async Task<IActionResult> Details(int id)
        {
            var product = await _db.Products
                                   .Include(p => p.Images)
                                   .Include(p => p.Details).ThenInclude(d => d.ProductSize)
                                   .Include(p => p.ProductToppings).ThenInclude(pt => pt.Topping)
                                   .FirstOrDefaultAsync(p => p.Id == id);

            if (product == null) return NotFound();

            foreach (var img in product.Images)
                img.ImageUrl = _productImgBase + img.ImageUrl;

            var related = await _db.Products
                                   .Where(p => p.ProductTypeId == product.ProductTypeId && p.Id != product.Id)
                                   .Take(8)
                                   .ToListAsync();

            ViewBag.Related = related;
            return View(product);
        }
    }
}
