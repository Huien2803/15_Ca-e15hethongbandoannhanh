using System.Threading.Tasks;
using FastFood.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Controllers
{
    [Route("admin/orders")]
    public class OrdersController : Controller
    {
        private readonly StoreDbContext _db;
        public OrdersController(StoreDbContext db) => _db = db;

        [HttpGet("{id:int}")]
        public async Task<IActionResult> Details(int id)
        {
            var o = await _db.Orders.Include(x => x.Items).FirstOrDefaultAsync(x => x.Id == id);
            if (o == null) return NotFound();
            return View(o);
        }
    }
}
