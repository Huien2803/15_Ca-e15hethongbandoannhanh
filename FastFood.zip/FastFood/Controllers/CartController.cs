using System;
using System.Linq;
using System.Threading.Tasks;
using FastFood.Data;
using FastFood.Extensions;
using FastFood.Models;
using FastFood.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Controllers
{
    [Route("Cart")]
    public class CartController : Controller
    {
        private const string CART_KEY = "CART";
        private readonly StoreDbContext _db;
        public CartController(StoreDbContext db) => _db = db;

        private CartVm GetCart()
            => HttpContext.Session.GetObject<CartVm>(CART_KEY) ?? new CartVm();

        private void SaveCart(CartVm cart)
            => HttpContext.Session.SetObject(CART_KEY, cart);

        // POST /Cart/Add
        [HttpPost("Add")]
        public async Task<IActionResult> Add(int productDetailsId, int qty = 1, int[]? toppingIds = null)
        {
            if (qty < 1) qty = 1;

            var pd = await _db.ProductDetails
                              .Include(x => x.Product).ThenInclude(p => p.Details)
                              .Include(x => x.ProductSize)
                              .FirstOrDefaultAsync(x => x.Id == productDetailsId);

            if (pd == null) return NotFound();

            var cart = GetCart();
            var exist = cart.Items.FirstOrDefault(i => i.ProductDetailsId == productDetailsId);

            if (exist == null)
            {
                cart.Items.Add(new CartItemVm
                {
                    ProductDetailsId = productDetailsId,
                    ProductId = pd.ProductId,
                    ProductName = pd.Product.ProductName,
                    SizeName = pd.ProductSize.SizeName,
                    UnitPrice = pd.Price,
                    Qty = qty
                });
            }
            else
            {
                exist.Qty += qty;
            }

            SaveCart(cart);
            return Json(new { ok = true, total = cart.Total });
        }

        // GET /Cart
        [HttpGet("")]
        public IActionResult Index()
        {
            var cart = GetCart();
            return View(cart);
        }

        // POST /Cart/UpdateQty
        [HttpPost("UpdateQty")]
        public IActionResult UpdateQty(int productDetailsId, int qty)
        {
            var cart = GetCart();
            var item = cart.Items.FirstOrDefault(i => i.ProductDetailsId == productDetailsId);
            if (item != null)
            {
                item.Qty = Math.Max(1, qty);
                SaveCart(cart);
            }
            return RedirectToAction(nameof(Index));
        }

        // POST /Cart/Remove
        [HttpPost("Remove")]
        public IActionResult Remove(int productDetailsId)
        {
            var cart = GetCart();
            cart.Items.RemoveAll(i => i.ProductDetailsId == productDetailsId);
            SaveCart(cart);
            return RedirectToAction(nameof(Index));
        }

        // GET /Cart/Checkout
        [HttpGet("Checkout")]
        public IActionResult Checkout()
        {
            var cart = GetCart();
            if (!cart.Items.Any()) return RedirectToAction(nameof(Index));
            return View(new CheckoutVm());
        }

        // POST /Cart/Checkout
        [HttpPost("Checkout")]
        public async Task<IActionResult> Checkout(CheckoutVm model)
        {
            var cart = GetCart();
            if (!cart.Items.Any()) return RedirectToAction(nameof(Index));
            if (!ModelState.IsValid) return View(model);

            var order = new Order
            {
                OrderCode = "FD" + DateTime.Now.ToString("yyMMddHHmmss"),
                CustomerName = model.CustomerName,
                Phone = model.Phone,
                Address = model.Address,
                Status = OrderStatus.New,
                CreatedAt = DateTime.Now
            };

            foreach (var i in cart.Items)
            {
                order.Items.Add(new OrderItem
                {
                    ProductId = i.ProductId,
                    ProductName = i.ProductName,
                    SizeName = i.SizeName,
                    UnitPrice = i.UnitPrice,
                    Quantity = i.Qty,
                    Subtotal = i.UnitPrice * i.Qty
                });
            }
            order.Total = order.Items.Sum(x => x.Subtotal);

            _db.Orders.Add(order);
            await _db.SaveChangesAsync();

            // clear cart
            SaveCart(new CartVm());

            return RedirectToAction("Details", "Orders", new { id = order.Id });
        }

        // POST /Cart/Clear
        [HttpPost("Clear")]
        public IActionResult Clear()
        {
            SaveCart(new CartVm());
            return RedirectToAction(nameof(Index));
        }
    }
}
