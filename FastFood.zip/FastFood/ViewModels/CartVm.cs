using System.Collections.Generic;
using System.Linq;

namespace FastFood.ViewModels
{
    public class CartVm
    {
        public List<CartItemVm> Items { get; set; } = new();
        public decimal Total => Items.Sum(i => i.Subtotal);
    }
}
