namespace FastFood.ViewModels
{
    public class CartItemVm
    {
        public int ProductDetailsId { get; set; }  // khóa của ProductDetails
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string? SizeName { get; set; }
        public decimal UnitPrice { get; set; }
        public int Qty { get; set; }
        public decimal Subtotal => UnitPrice * Qty;
    }
}
