namespace FFoodsStore.ViewModels
{
    public class MenuVM
    {
        public string? Q { get; set; }
        public string? Cat { get; set; }
        public List<MenuItemVM> Items { get; set; } = new();
    }

    public class MenuItemVM
{
    public int ProductDetailId { get; set; }  // ✅ thêm dòng này
    public int ProductId { get; set; }        // giữ lại nếu cần
    public string Name { get; set; } = "";
    public string TypeName { get; set; } = "";
    public string TypeSlug { get; set; } = "other";
    public decimal Price { get; set; }
    public string? ImageUrl { get; set; }
}

}
