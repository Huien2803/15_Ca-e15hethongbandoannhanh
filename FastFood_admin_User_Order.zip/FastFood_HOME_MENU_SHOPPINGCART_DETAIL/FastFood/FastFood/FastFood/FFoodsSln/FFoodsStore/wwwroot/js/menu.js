// ===============================
// Ẩn/hiện theo TAB loại
// ===============================
function filterCategory(cat, btn) {
  const sections = document.querySelectorAll('section.category');

  document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');

  const box = document.getElementById('searchBox');
  if (box) box.value = '';

  sections.forEach(sec => {
    if (cat === 'all') {
      sec.style.display = 'block';
      sec.querySelectorAll('.card').forEach(c => c.style.display = 'block');
    } else {
      sec.style.display = (sec.dataset.cat === cat) ? 'block' : 'none';
    }
  });
}

// ===============================
// Tìm kiếm theo tên + ẩn section rỗng
// ===============================
function filterMenu() {
  const q = (document.getElementById('searchBox')?.value || '').trim().toLowerCase();

  document.querySelectorAll('section.category').forEach(sec => {
    let visible = 0;
    sec.querySelectorAll('.card').forEach(card => {
      const name = card.querySelector('h3')?.innerText.toLowerCase() || '';
      const show = name.includes(q);
      card.style.display = show ? 'block' : 'none';
      if (show) visible++;
    });
    sec.style.display = visible ? 'block' : 'none';
  });

  document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
}

// ===============================
// Gọi API thêm sản phẩm vào giỏ hàng
// ===============================
async function addToCart(productDetailId) {
  const accountId = 1; // 🔒 tạm cố định, sau này dùng user login

  try {
    const res = await fetch("http://localhost:5000/api/cart/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ accountId, productDetailId })
    });

    if (!res.ok) throw new Error("API lỗi");
    const data = await res.json();

    // 🛒 Cập nhật số lượng trên icon giỏ hàng
    const count = document.getElementById("cartCount");
    if (count) count.innerText = data.totalItems ?? 0;

    showCartNotification("Đã thêm món vào giỏ hàng!");
  } catch (err) {
    console.error(err);
    showCartNotification("Không thể thêm vào giỏ hàng!", true);
  }
}

// ===============================
// Thông báo nhỏ khi thêm vào giỏ
// ===============================
function showCartNotification(message, isError = false) {
  let note = document.createElement("div");
  note.className = "cart-toast";
  note.innerText = message;
  Object.assign(note.style, {
    position: "fixed",
    bottom: "20px",
    right: "20px",
    padding: "10px 18px",
    borderRadius: "10px",
    background: isError ? "#dc3545" : "#28a745",
    color: "#fff",
    fontSize: "14px",
    boxShadow: "0 3px 10px rgba(0,0,0,0.2)",
    zIndex: 9999
  });
  document.body.appendChild(note);
  setTimeout(() => note.remove(), 2000);
}
