async function loadCart() {
  const container = document.getElementById("cartList");
  const totalEl = document.getElementById("totalPrice");
  container.innerHTML = "<p>Đang tải dữ liệu...</p>";

  try {
    const res = await fetch(`${apiBase}/by-account/${accountId}`);
    if (!res.ok) throw new Error("API lỗi");
    const result = await res.json();
    cartData = result.items || [];

    if (!cartData.length) {
      container.innerHTML = "<p>Giỏ hàng trống!</p>";
      totalEl.textContent = "0đ";
      return;
    }

    renderCart(result.total);
  } catch (err) {
    console.error(err);
    container.innerHTML = "<p style='color:red;'>Không thể tải dữ liệu!</p>";
  }
}

function renderCart(total) {
  const container = document.getElementById("cartList");
  const totalEl = document.getElementById("totalPrice");

  const html = cartData.map(item => {
    const prod = item.productDetail?.product;
    const name = prod?.productName || "Sản phẩm";
    const price = item.productDetail?.price || 0;
    const qty = item.quantity || 0;

    // Lấy size của sản phẩm
    const size = item.productDetail?.productSize?.sizeName || "Không xác định";

    const img =
      prod?.productImages?.[0]?.imageUrl ||
      `https://picsum.photos/seed/${item.productDetail?.productID}/640/420`;

    return `
      <div class="cart-item" data-id="${item.id}">
        <img src="${img}" alt="${name}" class="cart-thumb" />
        <div class="cart-info">
          <h4>${name}</h4>
          <p class="pd-size">Size: <b>${size}</b></p>
          <p>Giá: ${price.toLocaleString()}đ</p>
          <div class="qty-control">
            <button onclick="changeQty(${item.id}, -1)">-</button>
            <span>${qty}</span>
            <button onclick="changeQty(${item.id}, 1)">+</button>
          </div>
        </div>
        <button class="btn-remove" onclick="removeItem(${item.id})">🗑 Xóa</button>
      </div>
    `;
  }).join("");

  container.innerHTML = html;
  totalEl.textContent = (total || 0).toLocaleString() + "đ";
}
