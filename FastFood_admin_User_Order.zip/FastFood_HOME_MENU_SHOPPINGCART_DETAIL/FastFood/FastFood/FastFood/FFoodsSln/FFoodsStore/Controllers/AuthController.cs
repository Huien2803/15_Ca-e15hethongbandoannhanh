using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;

namespace FFoodsStore.Controllers
{
    public class AuthController : Controller
    {
        private readonly StoreDbContext _db;
        public AuthController(StoreDbContext db) => _db = db;

        [HttpGet("/auth/login")]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        [HttpPost("/auth/login")]
        public async Task<IActionResult> LoginPost(string email, string password, string? returnUrl = null)
        {
            var acc = await _db.Accounts.AsNoTracking()
                .FirstOrDefaultAsync(a => !a.IsDelete && a.Email == email && a.Password == password && a.IsActive == 1);

            if (acc == null)
            {
                ModelState.AddModelError("", "Email hoặc mật khẩu không đúng.");
                ViewBag.ReturnUrl = returnUrl;
                return View("Login");
            }

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, acc.ID.ToString()),
                new Claim(ClaimTypes.Email, acc.Email),
                new Claim("display_name", acc.FullName ?? acc.Email),
                new Claim("role", acc.Role == 1 ? "Admin" : "User")
            };

            var identity = new ClaimsIdentity(claims, "ff_cookie");
            var principal = new ClaimsPrincipal(identity);
            await HttpContext.SignInAsync("ff_cookie", principal);

            if (!string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            return Redirect(acc.Role == 1 ? "/Admin/Dashboard" : "/");
        }

        [HttpGet("/auth/logout")]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync("ff_cookie");
            return Redirect("/");
        }

        [HttpGet("/auth/denied")]
        public IActionResult Denied() => View();
    }
}
