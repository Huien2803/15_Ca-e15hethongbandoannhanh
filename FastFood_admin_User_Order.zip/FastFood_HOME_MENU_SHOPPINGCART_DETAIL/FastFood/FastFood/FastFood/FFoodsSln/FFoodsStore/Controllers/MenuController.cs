using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.ViewModels;

namespace FFoodsStore.Controllers
{
    public class MenuController : Controller
    {
        private readonly StoreDbContext _db;
        public MenuController(StoreDbContext db) => _db = db;

        public async Task<IActionResult> Index(string? q, string? cat)
        {
            // ===== Lấy ID loại theo slug =====
            List<int> filterTypeIds = new();
            if (!string.IsNullOrWhiteSpace(cat))
            {
                var typeRows = await _db.Set<ProductType>()
                    .Where(t => t.IsDelete == null || t.IsDelete == false)
                    .Select(t => new { t.ID, t.TypeCode, t.TypeName })
                    .ToListAsync();

                filterTypeIds = typeRows
                    .Select(t => new { t.ID, Slug = Slug(t.TypeCode ?? t.TypeName ?? "other") })
                    .Where(x => x.Slug == cat)
                    .Select(x => x.ID)
                    .ToList();
            }

            // ===== JOIN Product + Type + Detail + Image =====
            var baseQuery =
                from p in _db.Set<Product>()
                join pt in _db.Set<ProductType>() on p.ProductTypeID equals pt.ID
                join pd in _db.Set<ProductDetail>() on p.ID equals pd.ProductID
                join pi in _db.Set<ProductImage>() on p.ID equals pi.ProductID into imgGroup
                from pi in imgGroup.DefaultIfEmpty()
                where (p.IsDeleted == null || p.IsDeleted == false)
                      && (pd.IsDelete == null || pd.IsDelete == false)
                      && (pt.IsDelete == null || pt.IsDelete == false)
                select new
                {
                    Product = p,
                    Type = pt,
                    Detail = pd,
                    Image = pi
                };

            // ===== Lọc theo tên =====
            if (!string.IsNullOrWhiteSpace(q))
            {
                baseQuery = baseQuery.Where(x => EF.Functions.Like(x.Product.ProductName ?? "", $"%{q}%"));
            }

            // ===== Lọc theo loại =====
            if (filterTypeIds.Count > 0)
            {
                baseQuery = baseQuery.Where(x => filterTypeIds.Contains(x.Type.ID));
            }
            else if (!string.IsNullOrWhiteSpace(cat))
            {
                baseQuery = baseQuery.Where(x => false);
            }

            // ===== Chuyển sang LINQ thuần (fix lỗi EF Core không dịch GroupBy) =====
            var list = await baseQuery.ToListAsync();

            var items = list
                .GroupBy(x => new { x.Product, x.Type, x.Image })
                .Select(g => new MenuItemVM
                {
                    ProductDetailId = g.Min(x => x.Detail.ID),
                    ProductId = g.Key.Product.ID,
                    Name = g.Key.Product.ProductName ?? "",
                    TypeName = g.Key.Type.TypeName ?? "Khác",
                    TypeSlug = Slug(g.Key.Type.TypeCode ?? g.Key.Type.TypeName ?? "other"),
                    Price = g.Min(x => x.Detail.Price) ?? 0,
                    ImageUrl = FixImage(g.Key.Image?.ImageUrl, $"https://picsum.photos/seed/p-{g.Key.Product.ID}/800/450")
                })
                .OrderBy(x => x.Name)
                .ToList();

            var vm = new MenuVM { Q = q, Cat = cat, Items = items };
            return View(vm);
        }

        // ===== Helper tạo slug tiếng Việt =====
        private static string Slug(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "other";
            s = s.ToLowerInvariant();
            var repl = new Dictionary<string, string> {
                { " ", "-" }, { "/", "-" }, { "\\", "-" }, { "_", "-" },
                { "ă","a" }, { "â","a" }, { "á","a" }, { "à","a" }, { "ả","a" }, { "ã","a" }, { "ạ","a" },
                { "ê","e" }, { "é","e" }, { "è","e" }, { "ẻ","e" }, { "ẽ","e" }, { "ẹ","e" },
                { "ô","o" }, { "ơ","o" }, { "ó","o" }, { "ò","o" }, { "ỏ","o" }, { "õ","o" }, { "ọ","o" },
                { "ư","u" }, { "ú","u" }, { "ù","u" }, { "ủ","u" }, { "ũ","u" }, { "ụ","u" },
                { "í","i" }, { "ì","i" }, { "ỉ","i" }, { "ĩ","i" }, { "ị","i" },
                { "ý","y" }, { "ỳ","y" }, { "ỷ","y" }, { "ỹ","y" }, { "ỵ","y" },
                { "đ","d" }
            };
            foreach (var kv in repl) s = s.Replace(kv.Key, kv.Value);
            return s;
        }

        // ✅ FIX ẢNH (local, null, hoặc sai định dạng)
        private static string FixImage(string? img, string fallback)
        {
            if (string.IsNullOrWhiteSpace(img))
                return fallback;

            img = img.Trim();

            if (img.StartsWith("~/"))
                return img.Replace("~", "");
            if (img.StartsWith("img/"))
                return "/" + img;
            if (img.StartsWith("http"))
                return img;

            return fallback;
        }
    }
}
