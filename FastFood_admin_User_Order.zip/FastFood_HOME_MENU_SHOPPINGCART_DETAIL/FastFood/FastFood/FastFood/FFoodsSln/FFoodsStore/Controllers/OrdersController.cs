using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.Models.Dtos;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly StoreDbContext _db;
        public OrdersController(StoreDbContext db) => _db = db;

        private static string NewOrderCode()
        {
            var now = DateTime.UtcNow;
            return $"ORD{now:yyyyMMddHHmmssfff}";
        }

        // GET: api/orders?accountId=1
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderDto>>> GetOrders([FromQuery] int? accountId)
        {
            var q = _db.Set<Order>().AsNoTracking().Where(o => o.IsDeleted == null || o.IsDeleted == false);
            if (accountId.HasValue) q = q.Where(o => o.AccountID == accountId.Value);

            var orders = await q.OrderByDescending(o => o.ID).ToListAsync();
            var result = new List<OrderDto>();

            foreach (var o in orders)
            {
                var items = await (
                    from d in _db.Set<OrderDetail>().AsNoTracking()
                    join pd in _db.Set<ProductDetail>().AsNoTracking() on d.ProductDetailID equals pd.ID
                    join p in _db.Set<Product>().AsNoTracking() on pd.ProductID equals p.ID
                    join s in _db.Set<ProductSize>().AsNoTracking() on pd.ProductSizeID equals s.ID into sizeG
                    from s in sizeG.DefaultIfEmpty()
                    where d.OrderID == o.ID && (d.IsDelete == null || d.IsDelete == false)
                    select new OrderDetailDto
                    {
                        Id = d.ID,
                        ProductDetailId = pd.ID,
                        ProductName = p.ProductName ?? "",
                        SizeName = s.SizeName,
                        Quantity = d.Quantity ?? 0,
                        UnitPrice = pd.Price ?? 0,
                        LineTotal = (pd.Price ?? 0) * (d.Quantity ?? 0)
                    }
                ).ToListAsync();

                result.Add(new OrderDto
                {
                    Id = o.ID,
                    OrderCode = o.OrderCode ?? "",
                    AccountId = o.AccountID,
                    CustomerName = o.CustomerName,
                    PhoneNumber = o.PhoneNumber,
                    Address = o.Address,
                    Status = o.Status,
                    ReasonCancel = o.ReasonCancel,
                    CreateDate = o.CreateDate,
                    GrandTotal = items.Sum(x => x.LineTotal),
                    Items = items
                });
            }

            return Ok(result);
        }

        // GET: api/orders/5
        [HttpGet("{id:int}")]
        public async Task<ActionResult<OrderDto>> GetById(int id)
        {
            var o = await _db.Set<Order>().AsNoTracking()
                .FirstOrDefaultAsync(x => x.ID == id && (x.IsDeleted == null || x.IsDeleted == false));
            if (o == null) return NotFound();

            var items = await (
                from d in _db.Set<OrderDetail>().AsNoTracking()
                join pd in _db.Set<ProductDetail>().AsNoTracking() on d.ProductDetailID equals pd.ID
                join p in _db.Set<Product>().AsNoTracking() on pd.ProductID equals p.ID
                join s in _db.Set<ProductSize>().AsNoTracking() on pd.ProductSizeID equals s.ID into sizeG
                from s in sizeG.DefaultIfEmpty()
                where d.OrderID == o.ID && (d.IsDelete == null || d.IsDelete == false)
                select new OrderDetailDto
                {
                    Id = d.ID,
                    ProductDetailId = pd.ID,
                    ProductName = p.ProductName ?? "",
                    SizeName = s.SizeName,
                    Quantity = d.Quantity ?? 0,
                    UnitPrice = pd.Price ?? 0,
                    LineTotal = (pd.Price ?? 0) * (d.Quantity ?? 0)
                }
            ).ToListAsync();

            var dto = new OrderDto
            {
                Id = o.ID,
                OrderCode = o.OrderCode ?? "",
                AccountId = o.AccountID,
                CustomerName = o.CustomerName,
                PhoneNumber = o.PhoneNumber,
                Address = o.Address,
                Status = o.Status,
                ReasonCancel = o.ReasonCancel,
                CreateDate = o.CreateDate,
                GrandTotal = items.Sum(x => x.LineTotal),
                Items = items
            };

            return Ok(dto);
        }

        // POST: api/orders  (tạo đơn)
        [HttpPost]
        public async Task<ActionResult<OrderDto>> Create([FromBody] OrderCreateDto dto)
        {
            if (dto.Items == null || dto.Items.Count == 0) return BadRequest("Order must have at least one item.");

            var now = DateTime.UtcNow;
            var order = new Order
            {
                AccountID = dto.AccountId,
                OrderCode = NewOrderCode(),
                CustomerName = dto.CustomerName,
                PhoneNumber = dto.PhoneNumber,
                Address = dto.Address,
                Status = 0,
                CreateDate = now,
                CreateBy = "api",
                UpdatedDate = now,
                UpdatedBy = "api",
                IsDeleted = false
            };

            _db.Add(order);
            await _db.SaveChangesAsync();

            var details = new List<OrderDetailDto>();

            foreach (var it in dto.Items)
            {
                var pd = await _db.Set<ProductDetail>().AsNoTracking().FirstOrDefaultAsync(x => x.ID == it.ProductDetailId && (x.IsDelete == null || x.IsDelete == false));
                if (pd == null) return BadRequest($"ProductDetail {it.ProductDetailId} not found.");

                var od = new OrderDetail
                {
                    OrderID = order.ID,
                    ProductDetailID = it.ProductDetailId,
                    Quantity = it.Quantity,
                    TotalMoney = (pd.Price ?? 0) * it.Quantity,
                    CreatedDate = now,
                    CreatedBy = "api",
                    UpdatedDate = now,
                    UpdatedBy = "api",
                    IsDelete = false
                };
                _db.Add(od);
                await _db.SaveChangesAsync();

                var p = await _db.Set<Product>().AsNoTracking().FirstOrDefaultAsync(x => x.ID == pd.ProductID);
                var size = await _db.Set<ProductSize>().AsNoTracking().FirstOrDefaultAsync(x => x.ID == pd.ProductSizeID);

                details.Add(new OrderDetailDto
                {
                    Id = od.ID,
                    ProductDetailId = pd.ID,
                    ProductName = p?.ProductName ?? "",
                    SizeName = size?.SizeName,
                    Quantity = it.Quantity,
                    UnitPrice = pd.Price ?? 0,
                    LineTotal = (pd.Price ?? 0) * it.Quantity
                });
            }

            var result = new OrderDto
            {
                Id = order.ID,
                OrderCode = order.OrderCode ?? "",
                AccountId = order.AccountID,
                CustomerName = order.CustomerName,
                PhoneNumber = order.PhoneNumber,
                Address = order.Address,
                Status = order.Status,
                ReasonCancel = order.ReasonCancel,
                CreateDate = order.CreateDate,
                GrandTotal = details.Sum(x => x.LineTotal),
                Items = details
            };

            return CreatedAtAction(nameof(GetById), new { id = order.ID }, result);
        }

        // PUT: api/orders/5/status?status=2&reasonCancel=...
        [HttpPut("{id:int}/status")]
        public async Task<IActionResult> ChangeStatus(int id, [FromQuery] int status, [FromQuery] string? reasonCancel)
        {
            var o = await _db.Set<Order>().FirstOrDefaultAsync(x => x.ID == id && (x.IsDeleted == null || x.IsDeleted == false));
            if (o == null) return NotFound();

            o.Status = status;
            o.ReasonCancel = reasonCancel;
            o.UpdatedDate = DateTime.UtcNow;
            o.UpdatedBy = "api";
            await _db.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/orders/5 (xóa mềm)
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var o = await _db.Set<Order>().FirstOrDefaultAsync(x => x.ID == id && (x.IsDeleted == null || x.IsDeleted == false));
            if (o == null) return NotFound();

            o.IsDeleted = true;
            o.UpdatedDate = DateTime.UtcNow;
            o.UpdatedBy = "api";
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
