using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.Models.Dtos;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountsController : ControllerBase
    {
        private readonly StoreDbContext _db;
        public AccountsController(StoreDbContext db) => _db = db;

        // GET: api/accounts?keyword=abc
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AccountDto>>> GetAccounts([FromQuery] string? keyword)
        {
            var q = _db.Set<Account>().AsNoTracking().Where(a => !a.IsDelete);
            if (!string.IsNullOrWhiteSpace(keyword))
            {
                var like = $"%{keyword}%";
                q = q.Where(a => EF.Functions.Like(a.Email, like) || EF.Functions.Like(a.FullName ?? "", like));
            }

            var data = await q
                .OrderByDescending(a => a.ID)
                .Select(a => new AccountDto
                {
                    Id = a.ID, Email = a.Email, Role = a.Role, FullName = a.FullName,
                    Gender = a.Gender, PhoneNumber = a.PhoneNumber, Address = a.Address,
                    AvatarUrl = a.AvatarUrl, IsActive = a.IsActive
                })
                .ToListAsync();

            return Ok(data);
        }

        // GET: api/accounts/5
        [HttpGet("{id:int}")]
        public async Task<ActionResult<AccountDto>> GetAccount(int id)
        {
            var a = await _db.Set<Account>().AsNoTracking().FirstOrDefaultAsync(x => x.ID == id && !x.IsDelete);
            if (a == null) return NotFound();

            return Ok(new AccountDto
            {
                Id = a.ID, Email = a.Email, Role = a.Role, FullName = a.FullName,
                Gender = a.Gender, PhoneNumber = a.PhoneNumber, Address = a.Address,
                AvatarUrl = a.AvatarUrl, IsActive = a.IsActive
            });
        }

        // POST: api/accounts
        [HttpPost]
        public async Task<ActionResult<AccountDto>> Create([FromBody] AccountCreateDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            // (DEMO) Password chưa băm. Production nên dùng BCrypt/Argon2.
            if (await _db.Set<Account>().AnyAsync(a => a.Email == dto.Email && !a.IsDelete))
                return Conflict("Email already exists.");

            var now = DateTime.UtcNow;
            var acc = new Account
            {
                Email = dto.Email,
                Password = dto.Password,
                Role = dto.Role,
                FullName = dto.FullName,
                Gender = dto.Gender,
                PhoneNumber = dto.PhoneNumber,
                Address = dto.Address,
                AvatarUrl = dto.AvatarUrl,
                IsActive = dto.IsActive,
                CreatedDate = now,
                CreatedBy = "api",
                UpdatedDate = now,
                UpdatedBy = "api",
                IsDelete = false
            };

            _db.Add(acc);
            await _db.SaveChangesAsync();

            var result = new AccountDto
            {
                Id = acc.ID, Email = acc.Email, Role = acc.Role, FullName = acc.FullName,
                Gender = acc.Gender, PhoneNumber = acc.PhoneNumber, Address = acc.Address,
                AvatarUrl = acc.AvatarUrl, IsActive = acc.IsActive
            };
            return CreatedAtAction(nameof(GetAccount), new { id = acc.ID }, result);
        }

        // POST: api/accounts/login
        [HttpPost("login")]
        public async Task<ActionResult<AccountDto>> Login([FromBody] LoginDto dto)
        {
            var a = await _db.Set<Account>().AsNoTracking()
                .FirstOrDefaultAsync(x => x.Email == dto.Email && x.Password == dto.Password && !x.IsDelete);

            if (a == null) return Unauthorized("Invalid email or password.");

            return Ok(new AccountDto
            {
                Id = a.ID, Email = a.Email, Role = a.Role, FullName = a.FullName,
                Gender = a.Gender, PhoneNumber = a.PhoneNumber, Address = a.Address,
                AvatarUrl = a.AvatarUrl, IsActive = a.IsActive
            });
        }

        // PUT: api/accounts/5
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] AccountUpdateDto dto)
        {
            var a = await _db.Set<Account>().FirstOrDefaultAsync(x => x.ID == id && !x.IsDelete);
            if (a == null) return NotFound();

            if (dto.FullName != null) a.FullName = dto.FullName;
            if (dto.Gender.HasValue) a.Gender = dto.Gender;
            if (dto.PhoneNumber != null) a.PhoneNumber = dto.PhoneNumber;
            if (dto.Address != null) a.Address = dto.Address;
            if (dto.AvatarUrl != null) a.AvatarUrl = dto.AvatarUrl;
            if (dto.IsActive.HasValue) a.IsActive = dto.IsActive.Value;
            if (dto.Role.HasValue) a.Role = dto.Role.Value;
            if (!string.IsNullOrWhiteSpace(dto.Password)) a.Password = dto.Password; // demo

            a.UpdatedDate = DateTime.UtcNow;
            a.UpdatedBy = "api";
            await _db.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/accounts/5
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var a = await _db.Set<Account>().FirstOrDefaultAsync(x => x.ID == id && !x.IsDelete);
            if (a == null) return NotFound();

            a.IsDelete = true;
            a.UpdatedDate = DateTime.UtcNow;
            a.UpdatedBy = "api";
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
