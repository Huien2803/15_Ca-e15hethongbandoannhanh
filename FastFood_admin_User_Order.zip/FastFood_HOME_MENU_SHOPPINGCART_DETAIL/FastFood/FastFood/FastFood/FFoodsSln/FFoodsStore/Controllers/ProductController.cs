using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;

namespace FFoodsStore.Controllers
{
    [Route("Product")]
    public class ProductController : Controller
    {
        private readonly StoreDbContext _db;
        public ProductController(StoreDbContext db) => _db = db;

        // GET: /Product/Detail/5
        [HttpGet("Detail/{id}")]
        public async Task<IActionResult> Detail(int id)
        {
            var product = await _db.Products
                .Include(p => p.ProductType)
                .Include(p => p.ProductDetails)
                .Include(p => p.ProductImages)
                .FirstOrDefaultAsync(p => p.ID == id && (p.IsDeleted == null || p.IsDeleted == false));

            if (product == null)
                return NotFound(); // Nếu không tìm thấy sản phẩm

            var img = product.ProductImages?.FirstOrDefault()?.ImageUrl
                      ?? $"https://picsum.photos/seed/p-{id}/800/450";

            ViewData["ImageUrl"] = img;
            ViewData["TypeName"] = product.ProductType?.TypeName ?? "Khác"; // Hiển thị loại sản phẩm
            ViewData["Ingredients"] = product.Ingredients ?? "Đang cập nhật..."; // Hiển thị Nguyên liệu
            ViewData["Flavor"] = product.Flavor ?? "Hấp dẫn, thơm ngon khó cưỡng";  // Hương vị

            return View(product); // Trả về View với thông tin sản phẩm
        }
    }
}
