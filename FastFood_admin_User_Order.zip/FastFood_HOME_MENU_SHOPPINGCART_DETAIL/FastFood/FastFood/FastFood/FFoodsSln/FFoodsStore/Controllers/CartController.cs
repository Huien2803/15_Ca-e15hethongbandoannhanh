using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.Models.Dtos; // Đảm bảo thêm dòng này

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CartController : ControllerBase
    {
        private readonly StoreDbContext _db;
        public CartController(StoreDbContext db) => _db = db;

        // GET: api/cart/by-account/1
        [HttpGet("by-account/{accountId}")]
        public async Task<IActionResult> GetCart(int accountId)
        {
            // Truy vấn tất cả sản phẩm trong giỏ của tài khoản
            var items = await _db.Carts
                .Include(c => c.ProductDetail!)
                    .ThenInclude(pd => pd.Product!)
                        .ThenInclude(p => p.ProductImages)
                .Include(c => c.ProductDetail!)
                    .ThenInclude(pd => pd.ProductSize) // Thêm size sản phẩm
                .Where(c => c.AccountId == accountId)
                .ToListAsync();

            var total = items.Sum(i => (i.ProductDetail?.Price ?? 0m) * (i.Quantity ?? 0));
            var count = items.Sum(i => i.Quantity ?? 0);

            return Ok(new
            {
                total,
                count,
                items = items.Select(i => new
                {
                    i.ID,
                    i.AccountId,
                    i.ProductDetailId,
                    i.Quantity,
                    productDetail = i.ProductDetail == null ? null : new
                    {
                        i.ProductDetail.ID,
                        i.ProductDetail.ProductID,
                        i.ProductDetail.ProductSizeID,
                        i.ProductDetail.Price,
                        productSize = i.ProductDetail.ProductSize == null ? null : new
                        {
                            i.ProductDetail.ProductSize.SizeName, // Lấy size của sản phẩm
                            i.ProductDetail.ProductSize.SizeCode
                        },
                        product = i.ProductDetail.Product == null ? null : new
                        {
                            i.ProductDetail.Product.ID,
                            i.ProductDetail.Product.ProductName,
                            i.ProductDetail.Product.ProductCode,
                            productImages = i.ProductDetail.Product.ProductImages?
                                .Where(img => img.IsDelete != true)
                                .Select(img => new { img.ImageUrl, img.ImageName })
                        }
                    }
                })
            });
        }

        // POST: api/cart/add
        [HttpPost("add")]
        public async Task<IActionResult> Add([FromBody] CartDto dto)
        {
            var exist = await _db.Carts
                .FirstOrDefaultAsync(x => x.AccountId == dto.AccountId && x.ProductDetailId == dto.ProductDetailId);

            if (exist == null)
            {
                _db.Carts.Add(new Cart
                {
                    AccountId = dto.AccountId,
                    ProductDetailId = dto.ProductDetailId,
                    Quantity = 1,
                    CreatedDate = DateTime.Now
                });
            }
            else
            {
                exist.Quantity = (exist.Quantity ?? 0) + 1;
                exist.UpdatedDate = DateTime.Now;
            }

            await _db.SaveChangesAsync();

            var count = await _db.Carts.Where(c => c.AccountId == dto.AccountId)
                                       .SumAsync(c => c.Quantity ?? 0);

            return Ok(new { totalItems = count });
        }

        // PUT: api/cart/update-qty/5
        [HttpPut("update-qty/{id}")]
        public async Task<IActionResult> UpdateQty(int id, [FromQuery] int qty)
        {
            var item = await _db.Carts.FindAsync(id);
            if (item == null) return NotFound();
            if (qty < 1) qty = 1;

            item.Quantity = qty;
            item.UpdatedDate = DateTime.Now;
            await _db.SaveChangesAsync();
            return Ok();
        }

        // DELETE: api/cart/delete/5
        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _db.Carts.FindAsync(id);
            if (item == null) return NotFound();

            _db.Carts.Remove(item);
            await _db.SaveChangesAsync();
            return Ok();
        }
    }
}
