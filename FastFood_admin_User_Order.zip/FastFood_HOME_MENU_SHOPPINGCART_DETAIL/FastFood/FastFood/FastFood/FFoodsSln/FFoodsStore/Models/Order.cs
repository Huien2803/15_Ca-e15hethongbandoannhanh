﻿using System;
using System.Collections.Generic;

namespace FFoodsStore.Models;

public partial class Order
{
    public int ID { get; set; }

    public int? AccountID { get; set; }

    public string? OrderCode { get; set; }

    public string? CustomerName { get; set; }

    public string? PhoneNumber { get; set; }

    public string? Address { get; set; }

    public int? Status { get; set; }

    public string? ReasonCancel { get; set; }

    public DateTime? CreateDate { get; set; }

    public string? CreateBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public bool? IsDeleted { get; set; }
}
