namespace FFoodsStore.Models.Dtos
{
    public class AccountCreateDto
    {
        public string Email { get; set; } = "";
        public string Password { get; set; } = ""; // demo: plain text; production: hash
        public int Role { get; set; } = 0;         // 0=user, 1=admin (tuỳ quy ước)
        public string? FullName { get; set; }
        public int? Gender { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Address { get; set; }
        public string? AvatarUrl { get; set; }
        public int IsActive { get; set; } = 1;
    }
}
