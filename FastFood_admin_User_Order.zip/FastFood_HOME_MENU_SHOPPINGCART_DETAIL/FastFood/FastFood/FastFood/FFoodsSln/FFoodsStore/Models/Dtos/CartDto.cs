namespace FFoodsStore.Models.Dtos
{
    public class CartDto
    {
        public int AccountId { get; set; }
        public int ProductDetailId { get; set; }
    }
}
