using System;
using System.Collections.Generic;

namespace FFoodsStore.Models.Dtos
{
    public class OrderDto
    {
        public int Id { get; set; }
        public string OrderCode { get; set; } = "";
        public int? AccountId { get; set; }
        public string? CustomerName { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Address { get; set; }
        public int? Status { get; set; }
        public string? ReasonCancel { get; set; }
        public DateTime? CreateDate { get; set; }
        public decimal GrandTotal { get; set; }
        public List<OrderDetailDto> Items { get; set; } = new();
    }
}
