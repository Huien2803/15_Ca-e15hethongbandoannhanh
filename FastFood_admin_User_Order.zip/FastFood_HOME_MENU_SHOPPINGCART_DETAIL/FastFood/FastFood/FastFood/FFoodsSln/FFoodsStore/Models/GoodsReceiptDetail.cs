﻿using System;
using System.Collections.Generic;

namespace FFoodsStore.Models;

public partial class GoodsReceiptDetail
{
    public int ID { get; set; }

    public int GoodsReceiptID { get; set; }

    public int MaterialID { get; set; }

    public decimal Quantity { get; set; }

    public decimal UnitPrice { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public bool IsDelete { get; set; }
}
