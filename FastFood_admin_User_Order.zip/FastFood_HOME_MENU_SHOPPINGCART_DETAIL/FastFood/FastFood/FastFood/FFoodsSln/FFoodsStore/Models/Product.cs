﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace FFoodsStore.Models
{
    public class Product
    {
        public int ID { get; set; }
        public string? ProductCode { get; set; }
        public string? ProductName { get; set; }
        public bool? IsActive { get; set; }
        public string? Description { get; set; }
        public int? ProductTypeID { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string? UpdatedBy { get; set; }
        public bool? IsDeleted { get; set; }

        // 🔗 Navigation
        [ForeignKey("ProductTypeID")]
        public virtual ProductType? ProductType { get; set; }

        public virtual ICollection<ProductDetail>? ProductDetails { get; set; }
        public virtual ICollection<ProductImage>? ProductImages { get; set; }

        // 🧩 Extra fields for UI detail page
        public string? Ingredients { get; set; }
        public string? Flavor { get; set; }
    }
}
