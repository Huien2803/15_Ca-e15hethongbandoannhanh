using System.Collections.Generic;

namespace FFoodsStore.Models.Dtos
{
    public class OrderCreateDto
    {
        public int? AccountId { get; set; }
        public string? CustomerName { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Address { get; set; }
        public List<OrderItemCreateDto> Items { get; set; } = new();
    }
}
