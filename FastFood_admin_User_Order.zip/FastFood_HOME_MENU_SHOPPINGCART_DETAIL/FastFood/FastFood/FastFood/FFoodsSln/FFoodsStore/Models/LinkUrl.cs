﻿using System;
using System.Collections.Generic;

namespace FFoodsStore.Models;

public partial class LinkUrl
{
    public int ID { get; set; }

    public string? TypeUrl { get; set; }

    public string? LinkUrl1 { get; set; }
}
