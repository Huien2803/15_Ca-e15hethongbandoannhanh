namespace FFoodsStore.Models.Dtos
{
    public class OrderItemCreateDto
    {
        public int ProductDetailId { get; set; }
        public int Quantity { get; set; }
    }
}
