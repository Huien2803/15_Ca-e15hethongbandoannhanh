using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;

namespace FFoodsStore.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Policy = "AdminOnly")]
    public class OrdersController : Controller
    {
        private readonly StoreDbContext _db;
        public OrdersController(StoreDbContext db) => _db = db;

        public async Task<IActionResult> Index(int? status)
        {
            var q = _db.Orders.Where(o => o.IsDeleted == null || o.IsDeleted == false);
            if (status.HasValue) q = q.Where(o => o.Status == status.Value);
            var list = await q.OrderByDescending(o => o.ID).ToListAsync();
            return View(list);
        }

        public async Task<IActionResult> Details(int id)
        {
            var o = await _db.Orders.FirstOrDefaultAsync(x => x.ID == id);
            if (o == null) return NotFound();

            var items = await (
                from d in _db.OrderDetails
                join pd in _db.ProductDetails on d.ProductDetailID equals pd.ID
                join p in _db.Products on pd.ProductID equals p.ID
                join s in _db.ProductSizes on pd.ProductSizeID equals s.ID into g
                from s in g.DefaultIfEmpty()
                where d.OrderID == id && (d.IsDelete == null || d.IsDelete == false)
                select new {
                    d.ID, p.ProductName, SizeName = s.SizeName, d.Quantity, Price = pd.Price
                }
            ).ToListAsync();

            ViewBag.Items = items;
            return View(o);
        }

        [HttpPost]
        public async Task<IActionResult> ChangeStatus(int id, int status, string? reasonCancel)
        {
            var o = await _db.Orders.FirstOrDefaultAsync(x => x.ID == id);
            if (o == null) return NotFound();
            o.Status = status;
            o.ReasonCancel = reasonCancel;
            o.UpdatedDate = DateTime.UtcNow;
            o.UpdatedBy = "admin";
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Details), new { id });
        }
    }
}
