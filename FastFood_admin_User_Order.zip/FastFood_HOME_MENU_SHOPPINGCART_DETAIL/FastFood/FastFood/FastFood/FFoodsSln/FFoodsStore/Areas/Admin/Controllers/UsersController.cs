using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;

namespace FFoodsStore.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Policy = "AdminOnly")]
    public class UsersController : Controller
    {
        private readonly StoreDbContext _db;
        public UsersController(StoreDbContext db) => _db = db;

        public async Task<IActionResult> Index(string? q)
        {
            var query = _db.Accounts.Where(a => !a.IsDelete);
            if (!string.IsNullOrWhiteSpace(q))
            {
                var like = $"%{q}%";
                query = query.Where(a => EF.Functions.Like(a.Email, like) || EF.Functions.Like(a.FullName ?? "", like));
            }
            var list = await query.OrderByDescending(a => a.ID).ToListAsync();
            return View(list);
        }

        [HttpPost]
        public async Task<IActionResult> ToggleActive(int id)
        {
            var a = await _db.Accounts.FirstOrDefaultAsync(x => x.ID == id && !x.IsDelete);
            if (a == null) return NotFound();
            a.IsActive = a.IsActive == 1 ? 0 : 1;
            a.UpdatedDate = DateTime.UtcNow;
            a.UpdatedBy = "admin";
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> ToggleRole(int id)
        {
            var a = await _db.Accounts.FirstOrDefaultAsync(x => x.ID == id && !x.IsDelete);
            if (a == null) return NotFound();
            a.Role = (a.Role == 1) ? 0 : 1;
            a.UpdatedDate = DateTime.UtcNow;
            a.UpdatedBy = "admin";
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
